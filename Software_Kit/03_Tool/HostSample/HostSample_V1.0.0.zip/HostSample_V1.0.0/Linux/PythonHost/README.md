# Linux-PythonHost

Linux环境下的雷达数据采集和可视化工具，使用Python编写，需要Linux平台支持Python3.8或以上版本。

## 一、目录概览

* res                                                                                    README.md文档使用的资源
* Scripts
  * MRS6240_mmWave_radar_spi_collect_data_linux-master        数据采集脚本
  - site-packages
    - gpio                                                                                              GPIO功能库
    - PointCloudDisplay                                                                     点云可视化库
    - install.sh                                                                                      依赖库的安装脚本
    - requirements.txt                                                                        部分依赖库表单
- README.md                                                                                              本文件

数据采集脚本会调用site-packages/gpio和Python库spidev实现SPI数据采集，并通过site-packages/PointCloudDisplay实现数据可视化。

## 二、安装与移植

### 2.1 检查开发板软件环境

首先检查开发板是否具有Python环境，输入以下命令

```
python -V
```

如果有类似下面的回复，说明具有Python环境

```
Python 3.8.5
```

注意，需要Python版本大于等于 `3.8` 。

### 2.2 检查开发板网络环境

然后检查网络连接，这一步确保能够从网络下载依赖库，输入以下指令

```
ping www.baidu.com -c 4
```

如果有类似下面的回复，说明网络连接有效

```
PING www.baidu.com (183.240.99.224): 56 data bytes
64 bytes from 183.240.99.224: seq=0 ttl=53 time=14.206 ms
64 bytes from 183.240.99.224: seq=1 ttl=53 time=14.335 ms
64 bytes from 183.240.99.224: seq=2 ttl=53 time=15.012 ms
64 bytes from 183.240.99.224: seq=3 ttl=53 time=14.564 ms
```

下一步是检查查看实时点云的设备是否能ping通开发板，假设开发板IP是192.168.137.100，在查看实时点云的设备上ping开发板，如果是Windows设备，首先按 `Win+r` 打开窗口，在窗口内输入 `cmd` 并按回车键，在打开的命令行窗口中输入

```
ping 192.168.137.100
```

如果出现类似下面的回复，说明设备能够ping通开发板

```
正在 Ping 192.168.137.100 具有 32 字节的数据:
来自 192.168.137.100 的回复: 字节=32 时间<1ms TTL=64
来自 192.168.137.100 的回复: 字节=32 时间<1ms TTL=64
来自 192.168.137.100 的回复: 字节=32 时间<1ms TTL=64
来自 192.168.137.100 的回复: 字节=32 时间<1ms TTL=64

192.168.137.100 的 Ping 统计信息:
    数据包: 已发送 = 4，已接收 = 4，丢失 = 0 (0% 丢失)，
往返行程的估计时间(以毫秒为单位):
    最短 = 0ms，最长 = 0ms，平均 = 0ms
```

### 2.3 检查开发板SPI配置

通常，Linux设备树的SPI使用的IO会设置默认状态和低功耗状态，为了方便移植，推荐在低功耗状态下保留引脚配置，避免开发板进入低功耗状态时改变IO电平而导致通讯异常，以正点原子的STM32MP157-Mini开发板为例，其默认SPI引脚低功耗配置如下

```
spi1_sleep_pins_a: spi1-sleep-0 {
    pins {
        pinmux = <STM32_PINMUX('Z', 0, ANALOG)>,  /* SPI1_SCK */
            <STM32_PINMUX('Z', 1, ANALOG)>,  /* SPI1_MISO */
            <STM32_PINMUX('Z', 2, ANALOG)>;  /* SPI1_MOSI */
    }
}
```

需修改 `SPI1_SCK` 的配置为

```
<STM32_PINMUX('Z', 0, AF5)>
```

同时还需要修改SCK和MOSI的压摆率为0，避免毛刺过多影响通讯

修改

```
spi1_pins_a: spi1-0 {
    pins1 {
        ...
        slew-rate = <1>
    }
    ...
}
```

为

```
spi1_pins_a: spi1-0 {
    pins1 {
        ...
        slew-rate = <0>
    }
    ...
}
```

### 2.4 检查雷达底板硬件

#### 2.4.1 焊接 R1、R4、R6、R8 电阻

这 4 个 0Ω 电阻连通雷达芯片的 SPI 引脚（PA0–PA3）到 18pin 排针。出厂未焊接，需自行补上（焊锡短接即可，0Ω 本质是导线）。

#### 2.4.2 给 18pin 排针孔焊接排针

方便杜邦线连接信号。

#### 2.4.3 断开 CH347 USB 连接

开发板上的 CH347 USB-SPI 桥与 18pin 排针共享 PA0–PA3。**USB 必须断开**，否则 CH347 与主机争抢 SPI 总线，导致 MISO 全 0xFF。

#### 2.4.4 拔下 VDD3V3 和 VCC 跳线帽

改用外部 3.3V 供电时，需断开板载 LDO。

#### 2.4.5 Linux 开发板 3.3V 引脚给雷达供电

Linux 开发板的 3.3V 引脚（Pin 1 或 Pin 17）→ 雷达 18pin 排针的 VCC（Pin 12）。

### 2.5 为开发板安装依赖库

将压缩包解压并发送至开发板，然后进入解压后的目录下，此目录能看见文件夹Scripts和文件README.md。

输入命令进入安装脚本所在目录

```
cd Scripts/site-packages/
```

输入命令安装依赖库

```
./install.sh
```

### 2.6 数据采集脚本移植到开发板

回到解压后的目录，此目录能看见文件夹Scripts和文件README.md。

输入命令进入数据采集脚本所在目录

```
cd Scripts/MRS6240_mmWave_radar_spi_collect_data_linux-master/scripts/
```

此目录下，存在一个文件 `collect_Tracking.py` ，修改以下内容进行移植

```
# ═══════════════════════════════════════════════════════════════
# SPI / GPIO 硬件接口（STM32MP157）
# ═══════════════════════════════════════════════════════════════
GPIO_CHIP, INT_GPIO = 2, 0                      # gpiochip2, GPIO0 (中断引脚)
SPI_BUS, SPI_DEV, SPI_HZ = 0, 0, 10_000_000     # SPI1(devspi0), CS0, 10MHz
```

`GPIO_CHIP` 和 `INT_GPIO` 选择与雷达的PA6连接的GPIO，其中 `GPIO_CHIP` 会在 `Radar` 类的 `__init__` 方法中被格式化为

```
f"/dev/gpiochip{GPIO_CHIP}"
```

该字符串格式遵循periphery库的风格。

`SPI_BUG` 、 `SPI_DEV` 和 `SPI_HZ` 分别设置使用的SPI总线、SPI设备号和默认的SPI频率。

脚本会开启Web服务器用于数据可视化，修改以下内容的IP地址为开发板的IP地址

```
ser = PCDServer('cartesian', '192.168.137.100', 5000)
```

## 三、开发板使用数据采集脚本

回到解压后的目录，此目录能看见文件夹Scripts和文件README.md。

输入命令进入数据采集脚本所在目录

```
cd Scripts/MRS6240_mmWave_radar_spi_collect_data_linux-master/scripts/
```

此目录下，存在一个文件 `collect_Tracking.py` ，输入命令运行脚本

```
python collect_Tracking.py --speed 10000000
```

上述命令设置SPI速率为10MHz，可修改命令中的 `10000000` 来修改SPI速率，前提是开发板及其固件支持所设置的速率。

运行脚本后，会开启Web服务器并开始采集数据，Web服务器用于对数据进行可视化，目前只支持可视化点云数据（MsgID=0xC3），脚本运行后会打印如下日志

```
  10.0 MHz  burst=256  按 Ctrl+C 停止

 * Serving Flask app 'PointCloudDisplay.server'
 * Debug mode: off
WARNING: This is a development server. Do not use it in a production deployment. Use a production WSGI server instead.
 * Running on http://192.168.137.100:5000
Press CTRL+C to quit
```

日志中的网址 `http://192.168.137.100:5000` 可在浏览器中打开，打开之前确保打开网址的设备能够ping通开发板。打开网址后，会显示实时点云数据。

## 四、可视化界面

数据可视化的计算和渲染完全在Web Client，开发板只是将原始数据按照特定格式上报，因此可视化不会对开发板的产生较大影响。

可视化界面左侧是功能选择区域，可开启SNR颜色显示、显示坐标轴名称、切换高度轴等，下图是人体站在雷达前方轻微晃动的图像，绿色代表SNR值较小，红色、黄色代表SNR值较大，红色、黄色区域即人体位置处的点云。

![](./res/可视化界面.png)

SNR颜色可点击左下角 `SNR 颜色配置` 打开配置窗口，窗口内支持设置颜色分段数、最大SNR值、各个区段的颜色及SNR值分界点，也可以导出SNR配置并在下次打开时导入。

![](./res/配置SNR颜色.png)

例如，需要配置6个SNR区段，最大SNR为30，只需要将颜色分段数设置成6，然后设置最大SNR值为30，点击 `等间距` ，将会自动为各个区段设置SNR值分界点，最后点击 `应用` 。如果需要自定义分界点，只需要单独设置各个区段的分界点。

![](./res/配置SNR颜色6分段30dB.png)

## 五、数据发布格式

脚本向Web Client发布数据时采用如下格式

```
{
    "Type" : 4,
    "Flag" : ,
    "TotalLength" : ,
    "Point" : ,
}
```

`Type` 的值固定为4；

`Flag` 的值，0表示坐标系为极坐标，1表示坐标系为笛卡尔坐标；

`TotalLength` 的值，表示点云数据长度，单位为Byte，计算方式是 `点数*12` ；

`Point` 是字典组成的列表，即 `[{}, {}, ...]` ，每个字典的格式如下

```
{
    "range_or_x" : ,
    "azimath_or_y" : ,
    "elevation_or_z" : ,
    "velocity" : ,
    "snr" : ,
}
```

`range_or_x` 的值表示x坐标或距离，单位为米；

`azimath_or_y` 的值表示y坐标或方位角，单位为米或度；

`elevation_or_z` 的值表示z坐标或俯仰角，单位为米或度；

`velocity` 的值表示速度，可以使用3种格式，列表、字典、单个标量，具体如下

```
列表形式：
[vx, vy, vz]

字典形式：
{
    "velocity_x" : vx ,
    "velocity_y" : vy ,
    "velocity_z" : vz ,
}

标量形式：
v
```

`snr` 的值表示SNR，单位为dB。

## 六、问题与说明

### 6.1 为什么可视化界面不显示实时点云

这是多方面因素影响的，首先需要确认开发板能否正确使用SPI，可连接逻辑分析仪观察是否有数据交互，是否存在毛刺。如果没有数据交互，首先确认开发板的驱动和设备树是否开启Python脚本中选择的SPI总线和设备。如果存在毛刺，可以降低SPI速率或PIN的压摆率。

还有一种情况是，SPI的时钟源仅为设置的SPI速率的2倍，可以将时钟源设置为设置的SPI速率的4倍。

如果SPI通讯没有问题，需要确认脚本能否采集数据，将main函数中调用data_handle的地方

```
data_handle(ser, frames)
```

修改为直接打印

```
print(frames)
```

修改完成后观察脚本运行时打印的点云数据是否正常。

最后是确认打开Web网址的设备能否ping通开发板。

## 开源代码声明

| 开源代码目录                                             | 作者       |
| -------------------------------------------------- | -------- |
| MRS6240_mmWave_radar_spi_collect_data_linux-master | WinWin   |
| gpio                                               | nayooooo |
| PointCloudDisplay                                  | nayooooo |
