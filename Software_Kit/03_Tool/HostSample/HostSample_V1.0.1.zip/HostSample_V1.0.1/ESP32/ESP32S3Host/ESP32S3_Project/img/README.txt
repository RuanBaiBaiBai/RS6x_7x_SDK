ESP32S3_Project/img/ - 从机固件预置目录
==========================================

此目录下的所有文件会在编译时由 spiffs_create_partition_image
打包进 SPIFFS 分区（5MB），烧录后出现在 /spiffs/img/ 下，
文件名保持原样，例如：

    img/a.img   ->  /spiffs/img/a.img
    img/v2.bin  ->  /spiffs/img/v2.bin

使用方式：
    1. 把从机固件文件放到本目录（文件名随意，按实际文件为准）
    2. 重新编译烧录 ESP32 固件（spiffs.bin 会一并烧入）
    3. 串口 console：setdev 0x<handle> + burn enter + burn image /spiffs/img/<文件名> + burn exit

注意：
    - 本目录内容总量不能超过 SPIFFS 分区 5MB
    - 出厂预置固件不会被 HTTP 覆盖/删除（在线固件放 /spiffs/img_online/）
    - 本 README.txt 只是占位说明，可删除
