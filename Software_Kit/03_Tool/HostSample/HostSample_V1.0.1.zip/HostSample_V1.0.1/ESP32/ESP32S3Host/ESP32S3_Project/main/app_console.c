/**
 * @file    app_console.c
 * @brief   ESP32S3_Project 串口命令行控制台：通过 esp_console REPL 交互控制。
 *
 * 可用命令（help 查看）：
 *   wifi <ssid> <pass> | wifi status | wifi disconnect | wifi default [<ssid> <pass>]
 *   viz status | viz on | viz off
 *   setdev status | setdev 0x<handle> | setdev clear   （设置 mmwcfg/cmd/burn 使用的设备句柄）
 *   bus status | bus spi|i2c|uart [<speed>] | bus default   （切换总线预设，NVS 持久化）
 *   mmwcfg start on|off | mimo 1T1R|...|1T2R | frame 1d|2d | sfreq|range|rangeres|vel|velres|period <值>  （雷达常规参数配置）
 *   cmd ver customer|sdk | cmd reboot restart|burn     （版本查询 / 设备重启）
 *   burn enter | burn exit | burn image <path>          （烧录模式进入/退出/烧录镜像）
 *   free [ram|psram|flash|all]   （free 查看 SRAM+PSRAM；free ram 同上；
 *                                free psram 查看 PSRAM；free flash 查看 Flash；
 *                                free all 查看 SRAM+PSRAM+Flash）
 *   startup                （显示设备启动次数，0xFF 启动上报累计）
 *   ls                     （显示 SPIFFS 文件结构，/spiffs 文件树）
 *   reboot                 （重启 ESP32 主机，esp_restart）
 *   ps / help
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/idf_additions.h"   /* xTaskGetAffinity */

#include "esp_console.h"
#include "esp_system.h"
#include "esp_heap_caps.h"
#include "esp_flash.h"
#include "esp_partition.h"
#include "nvs.h"

#include "host_driver.h"
#include "host_mmw_api.h"
#include "app_console.h"
#include "app_wifi.h"
#include "app_spiffs.h"
#include "viz_server.h"

/* 设备启动次数获取接口（实现在 main.c，0xFF 启动上报计数） */
extern uint32_t app_startup_count_get(void);

/* 硬件配置 NVS 持久化接口（实现在 main.c，`bus` 命令使用） */
extern int  app_hwcfg_count(void);
extern const char *app_hwcfg_name(int idx);
extern uint32_t app_hwcfg_get(int idx);
extern int  app_hwcfg_preset_count(void);
extern const char *app_hwcfg_preset_name(int idx);
extern int  app_hwcfg_apply_preset(int idx, uint32_t speed_override);
extern int  app_hwcfg_reset(void);

/* ---------------- 设备句柄（由 setdev 命令设置） ---------------- */

static DEV_HANDLE s_dev = NULL;

/* ---- 距离/速度单位换算 ----
 * 协议侧为 16 位整数，单位 mm / mm/s；应用层输入 m / m/s（标准库 strtof 解析
 * 浮点）后换算成 mm / mm/s 下发：如 "10.5" m → ×1000 = 10500 mm。
 * 注意：sfreq 协议单位是 MHz，直接传整数，不走本换算。 */
#define MMW_CFG_MM_SCALE    1000

/* 解析无符号整数：支持十进制与 0x 前缀十六进制；成功返回 0 */
static int parse_uint(const char *s, uint32_t *out)
{
    char *end = NULL;
    unsigned long v;

    if ((s == NULL) || (s[0] == '\0')) {
        return -1;
    }
    if ((s[0] == '0') && ((s[1] == 'x') || (s[1] == 'X'))) {
        v = strtoul(s + 2, &end, 16);
    } else {
        v = strtoul(s, &end, 10);
    }
    if ((end == s) || (*end != '\0')) {
        return -1;
    }
    *out = (uint32_t)v;
    return 0;
}

/* 字符串转小写（用于语义化参数匹配） */
static void str_lower(char *dst, size_t dst_len, const char *src)
{
    size_t i;
    for (i = 0; (src[i] != '\0') && (i + 1 < dst_len); i++) {
        char c = src[i];
        dst[i] = ((c >= 'A') && (c <= 'Z')) ? (char)(c - 'A' + 'a') : c;
    }
    dst[i] = '\0';
}

/* 开关类参数：on/off/start/stop，兼容 0/1 */
static int parse_onoff(const char *s, uint32_t *out)
{
    char buf[8];
    str_lower(buf, sizeof(buf), s);
    if ((strcmp(buf, "on") == 0) || (strcmp(buf, "start") == 0) || (strcmp(buf, "1") == 0)) {
        *out = 1;
        return 0;
    }
    if ((strcmp(buf, "off") == 0) || (strcmp(buf, "stop") == 0) || (strcmp(buf, "0") == 0)) {
        *out = 0;
        return 0;
    }
    return -1;
}

/* MIMO 模式：1T1R/1T3R/2T3R/1T4R/2T4R/1T2R，兼容 0-5 */
static int parse_mimo(const char *s, uint32_t *out)
{
    char buf[8];
    str_lower(buf, sizeof(buf), s);
    if (strcmp(buf, "1t1r") == 0) { *out = 0; return 0; }
    if (strcmp(buf, "1t3r") == 0) { *out = 1; return 0; }
    if (strcmp(buf, "2t3r") == 0) { *out = 2; return 0; }
    if (strcmp(buf, "1t4r") == 0) { *out = 3; return 0; }
    if (strcmp(buf, "2t4r") == 0) { *out = 4; return 0; }
    if (strcmp(buf, "1t2r") == 0) { *out = 5; return 0; }
    return parse_uint(s, out);   /* 兼容数字 */
}

/* 帧类型：1d/2d，兼容 0/1 */
static int parse_frametype(const char *s, uint32_t *out)
{
    char buf[8];
    str_lower(buf, sizeof(buf), s);
    if (strcmp(buf, "1d") == 0) { *out = 0; return 0; }
    if (strcmp(buf, "2d") == 0) { *out = 1; return 0; }
    return parse_uint(s, out);   /* 兼容数字 */
}

/* 版本类型：customer 客户版本 / sdk 代码版本，兼容 1/0 */
static int parse_vertype(const char *s, uint32_t *out)
{
    char buf[16];
    str_lower(buf, sizeof(buf), s);
    if ((strcmp(buf, "customer") == 0) || (strcmp(buf, "custom") == 0) ||
        (strcmp(buf, "user") == 0) || (strcmp(buf, "1") == 0)) {
        *out = 1;
        return 0;
    }
    if ((strcmp(buf, "sdk") == 0) || (strcmp(buf, "code") == 0) || (strcmp(buf, "0") == 0)) {
        *out = 0;
        return 0;
    }
    return -1;
}

/* 设备重启模式：restart 重启 / burn 进入烧录模式，兼容 1/2 */
static int parse_rebootmode(const char *s, uint32_t *out)
{
    char buf[16];
    str_lower(buf, sizeof(buf), s);
    if ((strcmp(buf, "restart") == 0) || (strcmp(buf, "reboot") == 0) ||
        (strcmp(buf, "reset") == 0) || (strcmp(buf, "1") == 0)) {
        *out = 1;
        return 0;
    }
    if ((strcmp(buf, "burn") == 0) || (strcmp(buf, "download") == 0) ||
        (strcmp(buf, "boot") == 0) || (strcmp(buf, "2") == 0)) {
        *out = 2;
        return 0;
    }
    return -1;
}

/* 设置设备句柄：setdev status | setdev 0x<handle> | setdev clear */
static int cmd_setdev(int argc, char **argv)
{
    if (argc < 2) {
        printf("usage: %s status | %s 0x<handle> | %s clear\n", argv[0], argv[0], argv[0]);
        return HOST_ERRCODE_INVALID_PARAM;
    }
    if (strcmp(argv[1], "status") == 0) {
        if (s_dev == NULL) {
            printf("%s: null\n", argv[0]);
        } else {
            printf("%s: 0x%08x\n", argv[0], (unsigned)(uintptr_t)s_dev);
        }
        return 0;
    }
    if (strcmp(argv[1], "clear") == 0) {
        s_dev = NULL;
        printf("%s: cleared (null)\n", argv[0]);
        return 0;
    }
    /* 0x... 设置设备句柄地址 */
    uint32_t addr;
    if (parse_uint(argv[1], &addr) != 0) {
        printf("%s: invalid handle '%s' (usage: %s 0x3fc5xxxx)\n", argv[0], argv[1], argv[0]);
        return HOST_ERRCODE_INVALID_PARAM;
    }
    s_dev = (DEV_HANDLE)(uintptr_t)addr;
    printf("%s: device = 0x%08x\n", argv[0], (unsigned)(uintptr_t)s_dev);
    return 0;
}

/* bus_type 值 -> 名称（LLC_BUS_TYPE_*，host_llc.h） */
static const char *bus_type_str(uint32_t v)
{
    switch (v) {
    case LLC_BUS_TYPE_SPI:  return "SPI";
    case LLC_BUS_TYPE_I2C:  return "I2C";
    case LLC_BUS_TYPE_UART: return "UART";
    default:                return "?";
    }
}

/* bus_param 值 -> 名称（LLC_BUS_PARAM_*，host_llc.h） */
static const char *bus_param_str(uint32_t v)
{
    switch (v) {
    case LLC_BUS_PARAM_SPI:  return "SPI";
    case LLC_BUS_PARAM_DSPI: return "DSPI";
    case LLC_BUS_PARAM_QSPI: return "QSPI";
    default:                 return "?";
    }
}

/* 查看/切换总线预设（NVS 持久化，实现在 main.c）：
 *   bus                     或 bus status   -> 显示当前参数与可用预设
 *   bus spi [<speed>]                        -> 套用 SPI 预设，可选覆盖总线时钟
 *   bus i2c [<speed>]                        -> 套用 I2C 预设
 *   bus uart [<speed>]                       -> 套用 UART 预设
 *   bus default                              -> 恢复默认预设（spi）
 * 修改即持久化，重启后生效。 */
static int cmd_bus(int argc, char **argv)
{
    if ((argc >= 2) && (strcmp(argv[1], "default") == 0)) {
        int ret = app_hwcfg_reset();
        printf("bus: restored to default preset (spi), ret=%d (reboot 后生效)\n", ret);
        return (ret == HOST_ERRCODE_SUCCESS) ? 0 : ret;
    }

    if ((argc < 2) || (strcmp(argv[1], "status") == 0)) {
        int n = app_hwcfg_count();
        int pn = app_hwcfg_preset_count();

        printf("--- current bus hw params ---\n");
        for (int i = 0; i < n; i++) {
            const char *name = app_hwcfg_name(i);
            unsigned long val = (unsigned long)app_hwcfg_get(i);
            if (strcmp(name, "bus_type") == 0) {
                printf("  %-12s %lu (%s)\n", name, val, bus_type_str((uint32_t)val));
            } else if (strcmp(name, "bus_param") == 0) {
                printf("  %-12s %lu (%s)\n", name, val, bus_param_str((uint32_t)val));
            } else {
                printf("  %-12s %lu\n", name, val);
            }
        }
        printf("--- presets: ");
        for (int i = 0; i < pn; i++) {
            printf("%s%s", (i > 0) ? " / " : "", app_hwcfg_preset_name(i));
        }
        printf("\n(bus <spi|i2c|uart> [<speed>] 切换预设并持久化, reboot 后生效; bus default 恢复默认)\n");
        return 0;
    }

    /* bus <preset> [<speed>] */
    {
        int pn = app_hwcfg_preset_count();
        int idx = -1;
        uint32_t speed = 0;

        for (int i = 0; i < pn; i++) {
            if (strcmp(app_hwcfg_preset_name(i), argv[1]) == 0) {
                idx = i;
                break;
            }
        }
        if (idx < 0) {
            printf("bus: unknown preset '%s' (可用: ", argv[1]);
            for (int i = 0; i < pn; i++) {
                printf("%s%s", (i > 0) ? "/" : "", app_hwcfg_preset_name(i));
            }
            printf(")\n");
            return HOST_ERRCODE_INVALID_PARAM;
        }
        if (argc >= 3) {
            if ((parse_uint(argv[2], &speed) != 0) || (speed == 0)) {
                printf("bus: invalid speed '%s'\n", argv[2]);
                return HOST_ERRCODE_INVALID_PARAM;
            }
        }
        int ret = app_hwcfg_apply_preset(idx, speed);
        if (ret != HOST_ERRCODE_SUCCESS) {
            printf("bus: apply preset '%s' fail(%d)\n", argv[1], ret);
            return ret;
        }
        printf("bus: preset '%s' applied%s (saved, reboot 后生效)\n", argv[1],
               (speed != 0) ? " (speed 已覆盖)" : "");
        return 0;
    }
}

/* 检查设备句柄，未设置返回 -1 */
static int dev_check(const char *cmd_name)
{
    if (s_dev == NULL) {
        printf("%s: no device (use `setdev 0x<handle>` first)\n", cmd_name);
        return -1;
    }
    return 0;
}

/* ---------------- 命令处理 ---------------- */

/* WiFi 连接：wifi <ssid> <pass> | wifi status | wifi disconnect */
static int cmd_wifi(int argc, char **argv)
{
    char ip[32];
    int ret;

    if (argc >= 2 && strcmp(argv[1], "status") == 0) {
        if (app_wifi_status(ip, sizeof(ip))) {
            printf("wifi: connected, ip=%s\n", ip);
        } else {
            printf("wifi: not connected\n");
        }
        return 0;
    }
    if (argc >= 2 && strcmp(argv[1], "disconnect") == 0) {
        app_wifi_disconnect();
        printf("wifi: disconnected\n");
        return 0;
    }
    if (argc >= 2 && strcmp(argv[1], "default") == 0) {
        /* wifi default <ssid> <pass>：保存默认 WiFi（上电自动连接） */
        if (argc >= 4) {
            ret = app_wifi_set_default(argv[2], argv[3]);
            printf("wifi: default saved (%s), 上电自动连接\n",
                   (ret == HOST_ERRCODE_SUCCESS) ? argv[2] : "fail");
            return (ret == HOST_ERRCODE_SUCCESS) ? 0 : ret;
        } else {
            char ds[33], dp[65];
            if (app_wifi_get_default(ds, sizeof(ds), dp, sizeof(dp)) == HOST_ERRCODE_SUCCESS) {
                printf("wifi: default = %s / %s\n", ds, dp);
            } else {
                printf("wifi: no default set (usage: %s default <ssid> <pass>)\n", argv[0]);
            }
        }
        return 0;
    }
    if (argc < 3) {
        printf("usage: %s <ssid> <pass> | %s status | %s disconnect | %s default [<ssid> <pass>]\n",
               argv[0], argv[0], argv[0], argv[0]);
        return HOST_ERRCODE_INVALID_PARAM;
    }

    printf("wifi: connecting \"%s\"", argv[1]);
    fflush(stdout);
    ret = app_wifi_connect(argv[1], argv[2], 15000);
    if (ret == HOST_ERRCODE_SUCCESS) {
        app_wifi_status(ip, sizeof(ip));
        printf("wifi: connected, ip=%s (浏览器访问 http://%s/)\n", ip, ip);
        return 0;
    } else if (ret == HOST_ERRCODE_TIMEOUT) {
        printf("wifi: connect timeout\n");
    } else {
        printf("wifi: connect fail(%d)\n", ret);
    }
    return ret;   /* 失败返回 app_wifi_connect 的错误码 */
}

/* 可视化控制：viz status | viz on | viz off */
static int cmd_viz(int argc, char **argv)
{
    int clients = 0;

    if (argc >= 2 && strcmp(argv[1], "status") == 0) {
        char ip[32];

        printf("viz: server=%s push=%s clients=%d\n",
               viz_server_info(&clients) ? "running" : "stopped",
               viz_server_get_enable() ? "on" : "off", clients);
        /* 打印访问网址：http://<esp32-ip>/ */
        if (app_wifi_status(ip, sizeof(ip))) {
            printf("viz: 浏览器访问 http://%s/\n", ip);
        } else {
            printf("viz: 未连接 WiFi（用 `wifi <ssid> <pass>` 连接后获取网址）\n");
        }
        return 0;
    }
    if (argc >= 2 && (strcmp(argv[1], "on") == 0 || strcmp(argv[1], "1") == 0)) {
        viz_server_set_enable(1);
        printf("viz: push on\n");
        return 0;
    }
    if (argc >= 2 && (strcmp(argv[1], "off") == 0 || strcmp(argv[1], "0") == 0)) {
        viz_server_set_enable(0);
        printf("viz: push off\n");
        return 0;
    }
    printf("usage: %s status | %s on | %s off\n", argv[0], argv[0], argv[0]);
    return 0;
}

/* 雷达常规参数配置（对应 MmwCmd_General_*，均需已设置设备句柄）：
 *   mmwcfg start on|off            -> MmwCmd_General_StartCtrl_Cfg（开始/停止工作）
 *   mmwcfg mimo 1T1R|1T3R|2T3R|1T4R|2T4R|1T2R  -> MmwCmd_General_MimoMode_Cfg
 *   mmwcfg frame 1d|2d             -> MmwCmd_General_FrameType_Cfg
 *   mmwcfg sfreq <MHz>             -> MmwCmd_General_StartFreq_Cfg（起始频率，单位 MHz）
 *   mmwcfg range <m>               -> MmwCmd_General_TriggerRange_Cfg（最大量程）
 *   mmwcfg rangeres <m>            -> MmwCmd_General_RangeResolution_Cfg（距离分辨率）
 *   mmwcfg vel <m/s>               -> MmwCmd_General_MaxVelocity_Cfg（最大速度）
 *   mmwcfg velres <m/s>            -> MmwCmd_General_VelResolution_Cfg（速度分辨率）
 *   mmwcfg period <ms>             -> MmwCmd_General_FramePeriod_Cfg（帧周期） */
static int cmd_mmwcfg(int argc, char **argv)
{
    static const char usage[] =
        "usage: mmwcfg start on|off | mimo 1T1R|1T3R|2T3R|1T4R|2T4R|1T2R | frame 1d|2d | "
        "sfreq <MHz> | range <m> | rangeres <m> | vel <m/s> | velres <m/s> | period <ms>\n";
    uint32_t v;
    int ret;

    if (dev_check(argv[0]) != 0) {
        return HOST_ERRCODE_INVALID_HANDLE;
    }
    if (argc < 2) {
        printf("%s", usage);
        return HOST_ERRCODE_INVALID_PARAM;
    }

    if (strcmp(argv[1], "start") == 0) {
        if ((argc < 3) || (parse_onoff(argv[2], &v) != 0)) { printf("usage: mmwcfg start on|off\n"); return HOST_ERRCODE_INVALID_PARAM; }
        ret = MmwCmd_General_StartCtrl_Cfg(s_dev, v);
        printf("mmwcfg start: %s (%s), ret=%d%s\n", v ? "on" : "off", v ? "开始工作" : "停止", ret,
               (ret == HOST_ERRCODE_SUCCESS) ? " (ok)" : "");
        return (ret == HOST_ERRCODE_SUCCESS) ? 0 : ret;
    } else if (strcmp(argv[1], "mimo") == 0) {
        static const char *mimo_names[6] = { "1T1R", "1T3R", "2T3R", "1T4R", "2T4R", "1T2R" };
        if ((argc < 3) || (parse_mimo(argv[2], &v) != 0) || (v > 5)) {
            printf("usage: mmwcfg mimo 1T1R|1T3R|2T3R|1T4R|2T4R|1T2R\n");
            return HOST_ERRCODE_INVALID_PARAM;
        }
        ret = MmwCmd_General_MimoMode_Cfg(s_dev, v);
        printf("mmwcfg mimo: %s, ret=%d%s\n", mimo_names[v], ret,
               (ret == HOST_ERRCODE_SUCCESS) ? " (ok)" : "");
        return (ret == HOST_ERRCODE_SUCCESS) ? 0 : ret;
    } else if (strcmp(argv[1], "frame") == 0) {
        if ((argc < 3) || (parse_frametype(argv[2], &v) != 0) || (v > 1)) {
            printf("usage: mmwcfg frame 1d|2d\n");
            return HOST_ERRCODE_INVALID_PARAM;
        }
        ret = MmwCmd_General_FrameType_Cfg(s_dev, v);
        printf("mmwcfg frame: %s, ret=%d%s\n", v ? "2D" : "1D", ret,
               (ret == HOST_ERRCODE_SUCCESS) ? " (ok)" : "");
        return (ret == HOST_ERRCODE_SUCCESS) ? 0 : ret;
    } else if (strcmp(argv[1], "sfreq") == 0) {
        if ((argc < 3) || (parse_uint(argv[2], &v) != 0)) { printf("usage: mmwcfg sfreq <MHz>\n"); return HOST_ERRCODE_INVALID_PARAM; }
        ret = MmwCmd_General_StartFreq_Cfg(s_dev, v);
        printf("mmwcfg sfreq: %lu MHz, ret=%d%s\n", (unsigned long)v, ret,
               (ret == HOST_ERRCODE_SUCCESS) ? " (ok)" : "");
        return (ret == HOST_ERRCODE_SUCCESS) ? 0 : ret;
    } else if (strcmp(argv[1], "range") == 0) {
        char *end = NULL;
        float fv;
        if (argc < 3) { printf("usage: mmwcfg range <m>(支持小数)\n"); return HOST_ERRCODE_INVALID_PARAM; }
        fv = strtof(argv[2], &end);
        if ((end == argv[2]) || (*end != '\0') || (fv < 0.0f) || (fv * MMW_CFG_MM_SCALE > 0xFFFF)) {
            printf("usage: mmwcfg range <m>(支持小数)\n");
            return HOST_ERRCODE_INVALID_PARAM;
        }
        v = (uint32_t)(fv * MMW_CFG_MM_SCALE + 0.5f);
        ret = MmwCmd_General_TriggerRange_Cfg(s_dev, v);
        printf("mmwcfg range: %lu.%03lu m (val=%lu), ret=%d%s\n",
               (unsigned long)(v / MMW_CFG_MM_SCALE), (unsigned long)(v % MMW_CFG_MM_SCALE),
               (unsigned long)v, ret,
               (ret == HOST_ERRCODE_SUCCESS) ? " (ok)" : "");
        return (ret == HOST_ERRCODE_SUCCESS) ? 0 : ret;
    } else if (strcmp(argv[1], "rangeres") == 0) {
        char *end = NULL;
        float fv;
        if (argc < 3) { printf("usage: mmwcfg rangeres <m>(支持小数)\n"); return HOST_ERRCODE_INVALID_PARAM; }
        fv = strtof(argv[2], &end);
        if ((end == argv[2]) || (*end != '\0') || (fv < 0.0f) || (fv * MMW_CFG_MM_SCALE > 0xFFFF)) {
            printf("usage: mmwcfg rangeres <m>(支持小数)\n");
            return HOST_ERRCODE_INVALID_PARAM;
        }
        v = (uint32_t)(fv * MMW_CFG_MM_SCALE + 0.5f);
        ret = MmwCmd_General_RangeResolution_Cfg(s_dev, v);
        printf("mmwcfg rangeres: %lu.%03lu m (val=%lu), ret=%d%s\n",
               (unsigned long)(v / MMW_CFG_MM_SCALE), (unsigned long)(v % MMW_CFG_MM_SCALE),
               (unsigned long)v, ret,
               (ret == HOST_ERRCODE_SUCCESS) ? " (ok)" : "");
        return (ret == HOST_ERRCODE_SUCCESS) ? 0 : ret;
    } else if (strcmp(argv[1], "vel") == 0) {
        char *end = NULL;
        float fv;
        if (argc < 3) { printf("usage: mmwcfg vel <m/s>(支持小数)\n"); return HOST_ERRCODE_INVALID_PARAM; }
        fv = strtof(argv[2], &end);
        if ((end == argv[2]) || (*end != '\0') || (fv < 0.0f) || (fv * MMW_CFG_MM_SCALE > 0xFFFF)) {
            printf("usage: mmwcfg vel <m/s>(支持小数)\n");
            return HOST_ERRCODE_INVALID_PARAM;
        }
        v = (uint32_t)(fv * MMW_CFG_MM_SCALE + 0.5f);
        ret = MmwCmd_General_MaxVelocity_Cfg(s_dev, v);
        printf("mmwcfg vel: %lu.%03lu m/s (val=%lu), ret=%d%s\n",
               (unsigned long)(v / MMW_CFG_MM_SCALE), (unsigned long)(v % MMW_CFG_MM_SCALE),
               (unsigned long)v, ret,
               (ret == HOST_ERRCODE_SUCCESS) ? " (ok)" : "");
        return (ret == HOST_ERRCODE_SUCCESS) ? 0 : ret;
    } else if (strcmp(argv[1], "velres") == 0) {
        char *end = NULL;
        float fv;
        if (argc < 3) { printf("usage: mmwcfg velres <m/s>(支持小数)\n"); return HOST_ERRCODE_INVALID_PARAM; }
        fv = strtof(argv[2], &end);
        if ((end == argv[2]) || (*end != '\0') || (fv < 0.0f) || (fv * MMW_CFG_MM_SCALE > 0xFFFF)) {
            printf("usage: mmwcfg velres <m/s>(支持小数)\n");
            return HOST_ERRCODE_INVALID_PARAM;
        }
        v = (uint32_t)(fv * MMW_CFG_MM_SCALE + 0.5f);
        ret = MmwCmd_General_VelResolution_Cfg(s_dev, v);
        printf("mmwcfg velres: %lu.%03lu m/s (val=%lu), ret=%d%s\n",
               (unsigned long)(v / MMW_CFG_MM_SCALE), (unsigned long)(v % MMW_CFG_MM_SCALE),
               (unsigned long)v, ret,
               (ret == HOST_ERRCODE_SUCCESS) ? " (ok)" : "");
        return (ret == HOST_ERRCODE_SUCCESS) ? 0 : ret;
    } else if (strcmp(argv[1], "period") == 0) {
        if ((argc < 3) || (parse_uint(argv[2], &v) != 0)) { printf("usage: mmwcfg period <ms>\n"); return HOST_ERRCODE_INVALID_PARAM; }
        ret = MmwCmd_General_FramePeriod_Cfg(s_dev, v);
        printf("mmwcfg period: %lu ms, ret=%d%s\n", (unsigned long)v, ret,
               (ret == HOST_ERRCODE_SUCCESS) ? " (ok)" : "");
        return (ret == HOST_ERRCODE_SUCCESS) ? 0 : ret;
    } else {
        printf("mmwcfg: unknown subcmd '%s'\n", argv[1]);
        printf("%s", usage);
        return HOST_ERRCODE_INVALID_PARAM;
    }
}

/* 通用设备命令（HostCmd_*）：
 *   cmd ver customer|sdk  -> HostCmd_Version_Get（customer=客户版本，sdk=代码版本）
 *   cmd reboot restart|burn -> HostCmd_Device_Reboot（restart=重启，burn=进入烧录模式） */
static int cmd_cmd(int argc, char **argv)
{
    uint32_t v;
    int ret;

    if (dev_check(argv[0]) != 0) {
        return HOST_ERRCODE_INVALID_HANDLE;
    }
    if (argc < 2) {
        printf("usage: cmd ver customer|sdk | cmd reboot restart|burn\n");
        return HOST_ERRCODE_INVALID_PARAM;
    }

    if (strcmp(argv[1], "ver") == 0) {
        if (argc < 3) {
            printf("usage: cmd ver customer|sdk\n");
            return HOST_ERRCODE_INVALID_PARAM;
        }
        if (parse_vertype(argv[2], &v) != 0) {
            printf("usage: cmd ver customer|sdk\n");
            return HOST_ERRCODE_INVALID_PARAM;
        }
        ret = HostCmd_Version_Get(s_dev, v);
        printf("cmd ver: %s (%s), ret=%d%s\n", v ? "customer" : "sdk",
               v ? "客户版本" : "代码版本", ret,
               (ret == HOST_ERRCODE_SUCCESS) ? " (ok)" : "");
        return (ret == HOST_ERRCODE_SUCCESS) ? 0 : ret;
    } else if (strcmp(argv[1], "reboot") == 0) {
        if (argc < 3) {
            printf("usage: cmd reboot restart|burn\n");
            return HOST_ERRCODE_INVALID_PARAM;
        }
        if (parse_rebootmode(argv[2], &v) != 0) {
            printf("usage: cmd reboot restart|burn\n");
            return HOST_ERRCODE_INVALID_PARAM;
        }
        ret = HostCmd_Device_Reboot(s_dev, v);
        printf("cmd reboot: %s (%s), ret=%d%s\n", (v == 2) ? "burn" : "restart",
               (v == 2) ? "进入烧录模式" : "重启设备", ret,
               (ret == HOST_ERRCODE_SUCCESS) ? " (ok)" : "");
        return (ret == HOST_ERRCODE_SUCCESS) ? 0 : ret;
    } else {
        printf("cmd: unknown subcmd '%s'\n", argv[1]);
        printf("usage: cmd ver customer|sdk | cmd reboot restart|burn\n");
        return HOST_ERRCODE_INVALID_PARAM;
    }
}

/* 烧录命令（Host_BurnMode_Enter / Host_BurnMode_Exit / Host_Burn_Image）：
 *   burn enter             -> Host_BurnMode_Enter（进入烧录模式）
 *   burn exit              -> Host_BurnMode_Exit（退出烧录模式）
 *   burn image <path>      -> Host_Burn_Image（烧录镜像） */
static int cmd_burn(int argc, char **argv)
{
    int ret;

    if (dev_check(argv[0]) != 0) {
        return HOST_ERRCODE_INVALID_HANDLE;
    }
    if (argc < 2) {
        printf("usage: burn enter | burn exit | burn image <path>\n");
        return HOST_ERRCODE_INVALID_PARAM;
    }

    if (strcmp(argv[1], "enter") == 0) {
        ret = Host_BurnMode_Enter(s_dev);
        printf("burn enter: ret=%d%s\n", ret,
               (ret == HOST_ERRCODE_SUCCESS) ? " (ok)" : "");
        return (ret == HOST_ERRCODE_SUCCESS) ? 0 : ret;
    } else if (strcmp(argv[1], "exit") == 0) {
        Host_BurnMode_Exit(s_dev);
        printf("burn exit: done\n");
        return 0;
    } else if (strcmp(argv[1], "image") == 0) {
        if (argc < 3) {
            printf("usage: burn image <path>\n");
            return HOST_ERRCODE_INVALID_PARAM;
        }
        ret = Host_Burn_Image(s_dev, argv[2]);
        printf("burn image: ret=%d%s\n", ret,
               (ret == HOST_ERRCODE_SUCCESS) ? " (ok)" : "");
        return (ret == HOST_ERRCODE_SUCCESS) ? 0 : ret;
    } else {
        printf("burn: unknown subcmd '%s'\n", argv[1]);
        printf("usage: burn enter | burn exit | burn image <path>\n");
        return HOST_ERRCODE_INVALID_PARAM;
    }
}

/* 查看所有线程（任务）的状态：名称/状态/优先级/栈高水位线/编号/运行时间
 *
 * 依赖 CONFIG_FREERTOS_USE_TRACE_FACILITY 与
 * CONFIG_FREERTOS_GENERATE_RUN_TIME_STATS（sdkconfig.defaults 已启用）。
 * 用 uxTaskGetSystemState 直接取 TaskStatus_t 数组并按固定列宽格式化输出。
 *
 * 运行时间统计时钟源为 ESP Timer（1MHz）：
 *   - Time(us)  = ulRunTimeCounter（累计运行微秒，ESP Timer 原生单位）
 *   - %CPU      = 任务运行时间 / 总运行时间（双核下各任务之和可 >100%）
 * 注意：SMP 双核下 counter 为 32 位，ESP Timer 约 71.6 分钟后溢出，
 * 溢出后 Time/%CPU 不再可信（FreeRTOS SMP 限制，无法选 64 位）。 */
static int cmd_ps(int argc, char **argv)
{
    UBaseType_t task_num = uxTaskGetNumberOfTasks();
    TaskStatus_t *arr = NULL;
    UBaseType_t real_num;
    uint32_t total_run_time = 0;
    UBaseType_t i;
    int core_filter = -1;       /* -1: 不过滤；0/1: 只显示绑定到该核的任务 */

    /* 子命令：ps | ps core <0|1> */
    if (argc >= 2) {
        if ((argc == 3) && (strcmp(argv[1], "core") == 0)) {
            char *end = NULL;
            long v = strtol(argv[2], &end, 10);
            if ((end == argv[2]) || (*end != '\0') || (v < 0) || (v > 1)) {
                printf("ps: invalid core '%s' (0 or 1)\n", argv[2]);
                printf("usage: ps | ps core <0|1>\n");
                return HOST_ERRCODE_INVALID_PARAM;
            }
            core_filter = (int)v;
        } else {
            printf("usage: ps | ps core <0|1>\n");
            return HOST_ERRCODE_INVALID_PARAM;
        }
    }

    if (task_num == 0) {
        printf("ps: no task\n");
        return HOST_ERRCODE_SYSERR;
    }
    arr = (TaskStatus_t *)malloc(task_num * sizeof(TaskStatus_t));
    if (arr == NULL) {
        printf("ps: no memory\n");
        return HOST_ERRCODE_NO_BUFFER;
    }
    real_num = uxTaskGetSystemState(arr, task_num, &total_run_time);

    printf("%-16s %-6s %4s %5s %5s %4s %10s %5s\n",
           "Name", "State", "Prio", "Stack", "Num", "Core", "Time(us)", "%CPU");
    printf("---------------- ------ ---- ----- ----- ---- ---------- -----\n");

    for (i = 0; i < real_num; i++) {
        const char *st_str;
        uint32_t cpu_pct;
        char core_str[8];
        TaskHandle_t h;
        int core = -1;

        switch (arr[i].eCurrentState) {
        case eRunning:   st_str = "Run";   break;
        case eReady:     st_str = "Ready"; break;
        case eBlocked:   st_str = "Block"; break;
        case eSuspended: st_str = "Susp";  break;
        case eDeleted:   st_str = "Del";   break;
        case eInvalid:   st_str = "Inv";   break;
        default:         st_str = "?";     break;
        }

        /* 绑定的 Core：xTaskGetHandle 按名取句柄，xTaskGetCoreID 返回核号
         * （ESP-IDF 5.5 起 xTaskGetAffinity 已弃用，6.0 移除；两者语义一致：
         *  SMP 模式下未固定到单一核的任务返回 tskNO_AFFINITY） */
        h = xTaskGetHandle(arr[i].pcTaskName);
        if (h == NULL) {
            snprintf(core_str, sizeof(core_str), "?");
        } else if (xTaskGetCoreID(h) == tskNO_AFFINITY) {
            snprintf(core_str, sizeof(core_str), "any");
        } else {
            core = (int)xTaskGetCoreID(h);
            snprintf(core_str, sizeof(core_str), "%d", core);
        }

        /* ps core <num>: 只打印绑定到指定核的任务（未绑定 "any" 不显示） */
        if ((core_filter >= 0) && (core != core_filter)) {
            continue;
        }

        cpu_pct = (total_run_time > 0)
                  ? (uint32_t)((uint64_t)arr[i].ulRunTimeCounter * 100 / total_run_time)
                  : 0;

        /* pcTaskName 在 FreeRTOS 内部最长 16 字节（含 '\0'），
         * 超过 16 字符的名字会被截断；%-16s 保证列对齐。 */
        printf("%-16s %-6s %4u %5u %5u %4s %10lu %4lu%%\n",
               arr[i].pcTaskName,
               st_str,
               (unsigned)arr[i].uxCurrentPriority,
               (unsigned)arr[i].usStackHighWaterMark,  /* 最小剩余栈空间（字节） */
               (unsigned)arr[i].xTaskNumber,
               core_str,
               (unsigned long)arr[i].ulRunTimeCounter,
               (unsigned long)cpu_pct);
    }

    free(arr);
    return 0;
}


/* ---------------- 内存 / Flash 使用统计 ---------------- */

/* 字节数 -> "x.x KB" 或 "x.x MB" */
static void fmt_size(char *out, size_t out_len, uint32_t bytes)
{
    if (bytes >= (1024u * 1024u)) {
        snprintf(out, out_len, "%lu.%lu MB",
                 (unsigned long)(bytes / (1024u * 1024u)),
                 (unsigned long)((bytes % (1024u * 1024u)) * 10u / (1024u * 1024u)));
    } else {
        snprintf(out, out_len, "%lu.%lu KB",
                 (unsigned long)(bytes / 1024u),
                 (unsigned long)((bytes % 1024u) * 10u / 1024u));
    }
}

/* 打印单个 heap 区域统计（total / free / max used，含百分比）。
 * caps 为 MALLOC_CAP_INTERNAL(SRAM) 或 MALLOC_CAP_SPIRAM(PSRAM)；
 * total==0 表示该区域未启用（如 PSRAM 未开启），跳过。 */
static void free_print_heap_region(const char *name, uint32_t caps)
{
    uint32_t total = heap_caps_get_total_size(caps);
    if (total == 0) {
        printf("%s: not available\n", name);
        return;
    }
    uint32_t free     = heap_caps_get_free_size(caps);
    uint32_t min_free = heap_caps_get_minimum_free_size(caps);
    uint32_t max_used = (total > min_free) ? (total - min_free) : 0;
    char s_total[24], s_free[24], s_max[24];
    uint32_t p_free10 = (uint32_t)((uint64_t)free * 1000u / total);
    uint32_t p_max10  = (uint32_t)((uint64_t)max_used * 1000u / total);

    fmt_size(s_total, sizeof(s_total), total);
    fmt_size(s_free,  sizeof(s_free),  free);
    fmt_size(s_max,   sizeof(s_max),   max_used);

    printf("%s: total %s | free %s (%lu.%lu%%) | max used %s (%lu.%lu%%)\n",
           name, s_total, s_free,
           (unsigned long)(p_free10 / 10), (unsigned long)(p_free10 % 10),
           s_max,
           (unsigned long)(p_max10 / 10), (unsigned long)(p_max10 % 10));
}

/* SRAM 统计：内部 RAM（MALLOC_CAP_INTERNAL）的 total/free/max used */
static void free_print_sram(void)
{
    printf("--- SRAM ---\n");
    free_print_heap_region("SRAM", MALLOC_CAP_INTERNAL);
}

/* PSRAM 统计：外部 SPI RAM（MALLOC_CAP_SPIRAM）的 total/free/max used */
static void free_print_psram(void)
{
    printf("--- PSRAM ---\n");
    free_print_heap_region("PSRAM", MALLOC_CAP_SPIRAM);
}

/* RAM 统计：SRAM + PSRAM 合并显示 */
static void free_print_ram(void)
{
    free_print_sram();
    free_print_psram();
    printf("(max used = total - 历史最低剩余, 自启动由 heap_caps 跟踪)\n");
}

/* Flash 统计：总大小 / 分区已用 / 剩余，NVS(KV) 条目与字节占用 */
static void free_print_flash(void)
{
    uint32_t total = 0;
    uint32_t used  = 0;
    char s_total[24], s_used[24], s_free[24];

    /* 上电自动检测芯片物理 Flash 大小（JEDEC/SFDP），而非 esptool 写入的
     * image header 值（CONFIG_ESPTOOLPY_FLASHSIZE，仅代表烧录配置默认值）。
     * 检测失败时回退到 get_size（header 值）。 */
    if (esp_flash_get_physical_size(NULL, &total) != ESP_OK) {
        esp_flash_get_size(NULL, &total);
    }

    esp_partition_iterator_t it =
        esp_partition_find(ESP_PARTITION_TYPE_ANY, ESP_PARTITION_SUBTYPE_ANY, NULL);
    while (it != NULL) {
        used += esp_partition_get(it)->size;
        it = esp_partition_next(it);
    }

    uint32_t free = (total > used) ? (total - used) : 0;
    uint32_t p_used10 = (uint32_t)((uint64_t)used * 1000u / total);
    uint32_t p_free10 = (uint32_t)((uint64_t)free * 1000u / total);

    fmt_size(s_total, sizeof(s_total), total);
    fmt_size(s_used,  sizeof(s_used),  used);
    fmt_size(s_free,  sizeof(s_free),  free);

    printf("--- FLASH ---\n");
    printf("total: %s | used %s (%lu.%lu%%, 分区表已规划) | free %s (%lu.%lu%%)\n",
           s_total, s_used,
           (unsigned long)(p_used10 / 10), (unsigned long)(p_used10 % 10),
           s_free,
           (unsigned long)(p_free10 / 10), (unsigned long)(p_free10 % 10));

    /* NVS KV 统计：每条目 32B */
    nvs_stats_t st;
    if ((nvs_get_stats(NULL, &st) == ESP_OK) && (st.total_entries > 0)) {
        uint32_t used_b  = (uint32_t)st.used_entries * 32u;
        uint32_t total_b = (uint32_t)st.total_entries * 32u;
        uint32_t p10 = (uint32_t)((uint64_t)st.used_entries * 1000u / st.total_entries);
        char s_used_b[24], s_total_b[24];

        fmt_size(s_used_b,  sizeof(s_used_b),  used_b);
        fmt_size(s_total_b, sizeof(s_total_b), total_b);
        printf("--- NVS (KV) ---\n");
        printf("entries: %lu / %lu (%lu.%lu%%)\n",
               (unsigned long)st.used_entries, (unsigned long)st.total_entries,
               (unsigned long)(p10 / 10), (unsigned long)(p10 % 10));
        printf("bytes:   %s / %s (%lu.%lu%%)\n",
               s_used_b, s_total_b,
               (unsigned long)(p10 / 10), (unsigned long)(p10 % 10));
    } else {
        printf("--- NVS (KV) ---\nNVS not ready (需先 nvs_flash_init)\n");
    }
}

static int cmd_free(int argc, char **argv)
{
    if (argc >= 2 && strcmp(argv[1], "psram") == 0) {
        free_print_psram();
    } else if (argc >= 2 && strcmp(argv[1], "flash") == 0) {
        free_print_flash();
    } else if (argc >= 2 && strcmp(argv[1], "all") == 0) {
        free_print_sram();
        free_print_psram();
        free_print_flash();
    } else {
        free_print_ram();   /* free / free ram: SRAM + PSRAM */
    }
    return 0;
}

/* 查询设备启动次数：startup
 * 计数来自 0xFF 启动上报（main.c 的 app_data_handle 累加），可随时查询 */
static int cmd_startup(int argc, char **argv)
{
    (void)argc; (void)argv;
    printf("startup: device startup times=%lu\n",
           (unsigned long)app_startup_count_get());
    return 0;
}

/* 显示 SPIFFS 文件结构：ls
 * 递归打印 /spiffs 下的目录/文件/大小，及分区总占用 */
static int cmd_ls(int argc, char **argv)
{
    (void)argc; (void)argv;
    return app_spiffs_print_tree();
}

/* 重启 ESP32 主机（esp_restart） */
static int cmd_reboot(int argc, char **argv)
{
    (void)argc; (void)argv;
    printf("rebooting ESP32 in 1s...\n");
    fflush(stdout);
    vTaskDelay(pdMS_TO_TICKS(1000));   /* 留出时间让提示输出到串口 */
    esp_restart();
    return 0;                          /* esp_restart 不返回 */
}

/* ---------------- 命令注册与初始化 ---------------- */

static void app_console_register_cmds(void)
{
    static const esp_console_cmd_t cmds[] = {
        { .command = "wifi",
          .help = "wifi <ssid> <pass> | status | disconnect | default [<ssid> <pass>]",
          .hint = "<ssid> <pass>",
          .func = cmd_wifi },
        { .command = "viz",
          .help = "viz status | viz on | viz off",
          .hint = "status | on | off",
          .func = cmd_viz },
        { .command = "setdev",
          .help = "setdev status | setdev 0x<handle> | setdev clear",
          .hint = "0x<handle>",
          .func = cmd_setdev },
        { .command = "bus",
          .help = "bus [status] | bus <spi|i2c|uart> [<speed>] | bus default: 切换总线预设(NVS)",
          .hint = "status | spi|i2c|uart [speed] | default",
          .func = cmd_bus },
        { .command = "mmwcfg",
          .help = "mmwcfg start on|off | mimo 1T1R|..|1T2R | frame 1d|2d | sfreq/range/rangeres/vel/velres/period <val>",
          .hint = "start | mimo | frame | sfreq | range | rangeres | vel | velres | period",
          .func = cmd_mmwcfg },
        { .command = "cmd",
          .help = "cmd ver customer|sdk | cmd reboot restart|burn",
          .hint = "ver | reboot",
          .func = cmd_cmd },
        { .command = "burn",
          .help = "burn enter | burn exit | burn image <path>",
          .hint = "enter | exit | image",
          .func = cmd_burn },
        { .command = "free",
          .help = "free [ram|psram|flash|all]: SRAM+PSRAM / PSRAM / Flash / all",
          .hint = "ram | psram | flash | all",
          .func = cmd_free },
        { .command = "startup",
          .help = "startup: show device startup times (0xFF report)",
          .func = cmd_startup },
        { .command = "ls",
          .help = "ls: show SPIFFS file tree (/spiffs)",
          .func = cmd_ls },
        { .command = "reboot",
          .help = "reboot ESP32 (esp_restart)",
          .func = cmd_reboot },
        { .command = "ps",
          .help = "list tasks; ps core <0|1> list tasks on a core",
          .func = cmd_ps },
    };

    for (size_t i = 0; i < sizeof(cmds) / sizeof(cmds[0]); i++) {
        esp_console_cmd_register(&cmds[i]);
    }
}

int app_console_init(void)
{
    esp_console_repl_t *repl = NULL;
    esp_console_repl_config_t repl_cfg = ESP_CONSOLE_REPL_CONFIG_DEFAULT();
    esp_console_dev_uart_config_t uart_cfg = ESP_CONSOLE_DEV_UART_CONFIG_DEFAULT();

    repl_cfg.prompt = "ESP32S3_Project>";
    repl_cfg.max_cmdline_length = 256;
    /* ps 命令（uxTaskGetSystemState）格式化输出需要较大栈 */
    repl_cfg.task_stack_size = 8192;

    app_console_register_cmds();

    if (esp_console_new_repl_uart(&uart_cfg, &repl_cfg, &repl) != ESP_OK) {
        printf("console repl uart init fail\n");
        return -1;
    }
    esp_console_start_repl(repl);   /* 内部创建 REPL 任务，不阻塞 */
    return 0;
}
