/**
 * @file    app_console.h
 * @brief   ESP32S3_Project 串口命令行控制台（用于交互调试 host_driver）。
 */

#ifndef APP_CONSOLE_H_
#define APP_CONSOLE_H_

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 初始化命令行控制台（UART0，esp_console REPL）。
 * @note  内部创建 REPL 任务，不会阻塞调用方。
 * @retval 0 成功，-1 失败
 */
int app_console_init(void);

#ifdef __cplusplus
}
#endif

#endif /* APP_CONSOLE_H_ */
