/**
 * @file    app_spiffs.c
 * @brief   ESP32S3_Project SPIFFS 文件系统模块实现。
 *
 * 分区：partitions.csv 中 spiffs 分区（5MB，0x210000）。
 * 预置：img/ 目录经 spiffs_create_partition_image 打包，烧录后位于
 *       /spiffs/img/，文件名原样保留（如 img/a.img -> /spiffs/img/a.img）。
 * 在线：HTTP 上传的固件单独放 /spiffs/img_online/（后续实现）。
 *
 * 依赖 ESP-IDF spiffs 组件（main/CMakeLists.txt 的 PRIV_REQUIRES 已加）。
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <dirent.h>
#include <sys/stat.h>

#include "esp_spiffs.h"

#include "host_driver.h"
#include "app_spiffs.h"

#define APP_SPIFFS_BASE    "/spiffs"
#define APP_SPIFFS_LABEL   "spiffs"
#define APP_SPIFFS_MAX_FILES   8

/* 单目录内最大条目数（固件管理场景远小于此值） */
#define TREE_MAX_ENTRIES   64
/* 段名（d_name）最大长度，与 CONFIG_SPIFFS_OBJ_NAME_LEN 一致 */
#define APP_SPIFFS_NAME_LEN   64

/* 文件树条目：目录优先 + 名字字典序排序后输出 */
typedef struct {
    char name[APP_SPIFFS_NAME_LEN];
} tree_entry_t;

static int tree_entry_cmp(const void *a, const void *b)
{
    const tree_entry_t *ea = (const tree_entry_t *)a;
    const tree_entry_t *eb = (const tree_entry_t *)b;
    return strcmp(ea->name, eb->name);
}

/* 递归打印文件树（VFS 呈现方式）：目录先（递归展开），文件后（带大小），各自按名排序 */
static void spiffs_tree_print(const char *path, int depth)
{
    DIR *dir = opendir(path);
    if (dir == NULL) {
        return;
    }

    tree_entry_t entries[TREE_MAX_ENTRIES];
    int n = 0;
    struct dirent *ent;
    memset(entries, 0, sizeof(entries));

    /* 1. 收集当前目录所有条目（跳过 . 和 ..） */
    while ((ent = readdir(dir)) != NULL) {
        if ((strcmp(ent->d_name, ".") == 0) || (strcmp(ent->d_name, "..") == 0)) {
            continue;
        }
        if (n >= TREE_MAX_ENTRIES) {
            continue;   /* 超过上限丢弃，固件场景不会出现 */
        }
        strlcpy(entries[n].name, ent->d_name, sizeof(entries[n].name));
        n++;
    }
    closedir(dir);

    if (n == 0) {
        return;
    }

    /* 2. 按照字符串进行排序 */
    qsort(entries, (size_t)n, sizeof(entries[0]), tree_entry_cmp);

    /* 3. 呈现 */
    for (int i = 0; i < n; i++) {
        long size = -1;
        size_t plen = strlen(path);
        size_t dlen = strlen(entries[i].name);
        char *sub = malloc(plen + dlen + 2);
        if (sub != NULL) {
            memcpy(sub, path, plen);
            sub[plen] = '/';
            memcpy(sub + plen + 1, entries[i].name, dlen + 1);
            struct stat st;
            if (stat(sub, &st) == 0) {
                size = (long)st.st_size;
            }
            free(sub);
        }
        printf("%s  (%ld bytes)\n", entries[i].name, size);
    }
}

int app_spiffs_init(void)
{
    esp_vfs_spiffs_conf_t conf = {
        .base_path              = APP_SPIFFS_BASE,
        .partition_label        = APP_SPIFFS_LABEL,
        .max_files              = APP_SPIFFS_MAX_FILES,
        /* 出厂镜像已预置固件，禁止首启格式化（格式化会清掉 /spiffs/img） */
        .format_if_mount_failed = false,
    };

    esp_err_t err = esp_vfs_spiffs_register(&conf);
    if (err != ESP_OK) {
        HOST_LOG_ERR("[spiffs] register %s fail(%d)\n", APP_SPIFFS_BASE, err);
        return HOST_ERRCODE_IO_ERROR;
    }

    size_t total = 0, used = 0;
    if (esp_spiffs_info(APP_SPIFFS_LABEL, &total, &used) == ESP_OK) {
        HOST_LOG_INF("[spiffs] mounted %s: used %u / total %u bytes\n",
                     APP_SPIFFS_BASE, (unsigned)used, (unsigned)total);
    }
    return HOST_ERRCODE_SUCCESS;
}

int app_spiffs_print_tree(void)
{
    size_t total = 0, used = 0;
    esp_err_t err = esp_spiffs_info(APP_SPIFFS_LABEL, &total, &used);
    if (err != ESP_OK) {
        printf("spiffs: info fail(%d), not mounted?\n", err);
        return HOST_ERRCODE_IO_ERROR;
    }

    printf("--- SPIFFS (%s) ---\n", APP_SPIFFS_BASE);
    spiffs_tree_print(APP_SPIFFS_BASE, 0);
    printf("--- partition: used %u / total %u bytes, free %u%% ---\n",
           (unsigned)used, (unsigned)total,
           (total > 0) ? (unsigned)((total - used) * 100 / total) : 0);
    return HOST_ERRCODE_SUCCESS;
}
