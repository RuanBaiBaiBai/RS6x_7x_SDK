/**
 * @file    app_spiffs.h
 * @brief   ESP32S3_Project SPIFFS 文件系统模块（从机固件存放区）。
 */

#ifndef APP_SPIFFS_H_
#define APP_SPIFFS_H_

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 挂载 SPIFFS 到 /spiffs。
 * @note  出厂镜像含预置固件，format_if_mount_failed=false，禁止首启格式化。
 * @retval HOST_ERRCODE_SUCCESS 成功，否则失败
 */
int app_spiffs_init(void);

/**
 * @brief 递归打印 /spiffs 文件树（目录/文件/大小/分区占用）。
 * @retval HOST_ERRCODE_SUCCESS 成功，否则失败
 */
int app_spiffs_print_tree(void);

#ifdef __cplusplus
}
#endif

#endif /* APP_SPIFFS_H_ */
