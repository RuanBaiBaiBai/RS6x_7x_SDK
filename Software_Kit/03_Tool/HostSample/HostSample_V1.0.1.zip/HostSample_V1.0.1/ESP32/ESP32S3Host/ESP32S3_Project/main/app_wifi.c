/**
 * @file    app_wifi.c
 * @brief   ESP32S3_Project WiFi STA 连接模块（esp_wifi）。
 * @note    所有初始化调用均幂等：若已初始化过则忽略 ESP_ERR_INVALID_STATE。
 *          连接采用轮询等待 IP，不注册事件 handler，简单可靠。
 */

#include <stdio.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "nvs_flash.h"

#include "app_wifi.h"
#include "host_driver.h"

static bool s_wifi_inited = false;

int app_wifi_init(void)
{
    esp_err_t err;

    if (s_wifi_inited) {
        return HOST_ERRCODE_SUCCESS;
    }

    err = nvs_flash_init();
    if ((err != ESP_OK) && (err != ESP_ERR_NVS_NO_FREE_PAGES) &&
        (err != ESP_ERR_NVS_NEW_VERSION_FOUND) && (err != ESP_ERR_INVALID_STATE)) {
        return HOST_ERRCODE_SYSERR;
    }
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        nvs_flash_erase();
        nvs_flash_init();
    }

    err = esp_event_loop_create_default();
    if ((err != ESP_OK) && (err != ESP_ERR_INVALID_STATE)) {
        return HOST_ERRCODE_SYSERR;
    }

    err = esp_netif_init();
    if (err != ESP_OK) {
        return HOST_ERRCODE_SYSERR;
    }

    esp_netif_create_default_wifi_sta();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    err = esp_wifi_init(&cfg);
    if ((err != ESP_OK) && (err != ESP_ERR_INVALID_STATE)) {
        return HOST_ERRCODE_SYSERR;
    }

    esp_wifi_set_storage(WIFI_STORAGE_RAM);
    s_wifi_inited = true;
    return HOST_ERRCODE_SUCCESS;
}

int app_wifi_connect(const char *ssid, const char *pass, uint32_t timeout_ms)
{
    wifi_config_t cfg;
    uint32_t waited = 0;
    int ret;

    if ((ssid == NULL) || (ssid[0] == '\0')) {
        return HOST_ERRCODE_INVALID_PARAM;
    }

    ret = app_wifi_init();
    if (ret != HOST_ERRCODE_SUCCESS) {
        return ret;
    }

    memset(&cfg, 0, sizeof(cfg));
    strncpy((char *)cfg.sta.ssid, ssid, sizeof(cfg.sta.ssid) - 1);
    if ((pass != NULL) && (pass[0] != '\0')) {
        strncpy((char *)cfg.sta.password, pass, sizeof(cfg.sta.password) - 1);
    }
    cfg.sta.threshold.authmode = WIFI_AUTH_WPA2_PSK;

    if (esp_wifi_set_mode(WIFI_MODE_STA) != ESP_OK) {
        return HOST_ERRCODE_IO_ERROR;
    }
    if (esp_wifi_set_config(WIFI_IF_STA, &cfg) != ESP_OK) {
        return HOST_ERRCODE_IO_ERROR;
    }
    if (esp_wifi_start() != ESP_OK) {
        return HOST_ERRCODE_IO_ERROR;
    }
    if (esp_wifi_connect() != ESP_OK) {
        return HOST_ERRCODE_IO_ERROR;
    }

    esp_netif_ip_info_t ip;
    uint32_t last_dot = 0;
    while (waited < timeout_ms) {
        esp_netif_t *sta = esp_netif_get_handle_from_ifkey("WIFI_STA_DEF");
        if ((sta != NULL) &&
            (esp_netif_get_ip_info(sta, &ip) == ESP_OK) &&
            (ip.ip.addr != 0)) {
            printf("\n");          /* 结束进度点 */
            return HOST_ERRCODE_SUCCESS;
        }
        vTaskDelay(pdMS_TO_TICKS(100));
        waited += 100;
        if (waited - last_dot >= 500) {
            printf(".");           /* 每 0.5s 一个点 */
            fflush(stdout);
            last_dot = waited;
        }
    }
    printf("\n");                  /* 结束进度点 */
    return HOST_ERRCODE_TIMEOUT;
}

int app_wifi_set_default(const char *ssid, const char *pass)
{
    nvs_handle_t h;
    esp_err_t err;

    if ((ssid == NULL) || (ssid[0] == '\0')) {
        return HOST_ERRCODE_INVALID_PARAM;
    }
    err = nvs_open("wifi", NVS_READWRITE, &h);
    if (err != ESP_OK) {
        return HOST_ERRCODE_SYSERR;
    }
    err = nvs_set_str(h, "ssid", ssid);
    if ((err == ESP_OK) && (pass != NULL)) {
        err = nvs_set_str(h, "pass", pass);
    }
    if (err == ESP_OK) {
        err = nvs_commit(h);
    }
    nvs_close(h);
    return (err == ESP_OK) ? HOST_ERRCODE_SUCCESS : HOST_ERRCODE_SYSERR;
}

int app_wifi_get_default(char *ssid, size_t ssid_len, char *pass, size_t pass_len)
{
    nvs_handle_t h;
    esp_err_t err;
    size_t len;

    if (nvs_open("wifi", NVS_READONLY, &h) != ESP_OK) {
        return HOST_ERRCODE_NOT_FOUND;
    }
    len = ssid_len;
    err = nvs_get_str(h, "ssid", ssid, &len);
    if ((err == ESP_OK) && (pass != NULL)) {
        len = pass_len;
        err = nvs_get_str(h, "pass", pass, &len);
    }
    nvs_close(h);
    if ((err != ESP_OK) || (ssid == NULL) || (ssid[0] == '\0')) {
        return HOST_ERRCODE_NOT_FOUND;
    }
    return HOST_ERRCODE_SUCCESS;
}

int app_wifi_connect_default(uint32_t timeout_ms)
{
    char ssid[33] = { 0 };
    char pass[65] = { 0 };
    int ret;

    ret = app_wifi_get_default(ssid, sizeof(ssid), pass, sizeof(pass));
    if (ret != HOST_ERRCODE_SUCCESS) {
        return ret;   /* 未设置默认 WiFi */
    }
    printf("wifi: connecting default \"%s\"", ssid);
    fflush(stdout);
    return app_wifi_connect(ssid, pass, timeout_ms);
}

int app_wifi_disconnect(void)
{
    esp_wifi_disconnect();
    esp_wifi_stop();
    return HOST_ERRCODE_SUCCESS;
}

int app_wifi_status(char *ip_buf, size_t ip_len)
{
    esp_netif_ip_info_t ip;
    esp_netif_t *sta;

    if (ip_buf != NULL && ip_len > 0) {
        ip_buf[0] = '\0';
    }
    sta = esp_netif_get_handle_from_ifkey("WIFI_STA_DEF");
    if ((sta == NULL) || (esp_netif_get_ip_info(sta, &ip) != ESP_OK) || (ip.ip.addr == 0)) {
        return 0;
    }
    if (ip_buf != NULL && ip_len > 0) {
        snprintf(ip_buf, ip_len, IPSTR, IP2STR(&ip.ip));
    }
    return 1;
}
