/**
 * @file    app_wifi.h
 * @brief   ESP32S3_Project WiFi STA 连接模块（供 console 指令调用）。
 */
#ifndef APP_WIFI_H_
#define APP_WIFI_H_

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 初始化 WiFi 子系统（幂等，可重复调用）。
 */
int app_wifi_init(void);

/**
 * @brief 连接 WiFi（STA），阻塞等待获取 IP。
 * @note  等待期间每 0.5s 打印一个 '.' 显示进度（连接完成打印换行）。
 * @retval HOST_ERRCODE_SUCCESS 已连接并获取 IP
 * @retval HOST_ERRCODE_TIMEOUT 超时未连上
 */
int app_wifi_connect(const char *ssid, const char *pass, uint32_t timeout_ms);

/**
 * @brief 保存默认 WiFi（SSID/密码写入 NVS，上电自动尝试连接）。
 */
int app_wifi_set_default(const char *ssid, const char *pass);

/**
 * @brief 读取默认 WiFi。
 * @retval HOST_ERRCODE_SUCCESS 已设置；HOST_ERRCODE_NOT_FOUND 未设置
 */
int app_wifi_get_default(char *ssid, size_t ssid_len, char *pass, size_t pass_len);

/**
 * @brief 尝试连接默认 WiFi（若有）。
 * @note  连接过程打印 "wifi: connecting default ..." + 每 0.5s 一个 '.'。
 * @retval HOST_ERRCODE_SUCCESS 已连接并获取 IP
 * @retval HOST_ERRCODE_NOT_FOUND 未设置默认 WiFi
 * @retval HOST_ERRCODE_TIMEOUT 超时未连上
 */
int app_wifi_connect_default(uint32_t timeout_ms);

/**
 * @brief 断开 WiFi。
 */
int app_wifi_disconnect(void);

/**
 * @brief 查询连接状态。
 * @retval 1 已连接（有 IP）；0 未连接
 */
int app_wifi_status(char *ip_buf, size_t ip_len);

#ifdef __cplusplus
}
#endif

#endif /* APP_WIFI_H_ */
