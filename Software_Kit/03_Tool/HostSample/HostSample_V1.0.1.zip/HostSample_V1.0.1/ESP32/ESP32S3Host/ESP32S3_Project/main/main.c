/**
 * @file    main.c
 * @brief   ESP32S3_Project - PSIC host driver (ESP-IDF 组件化) 使用示例。
 *
 *          演示 host_driver 组件的典型使用流程：
 *          Host_Driver_Init -> Host_Device_Regist -> Host_Device_Open
 *          -> HostCmd_Version_Get -> 业务循环
 *
 * @note    引脚与总线参数为占位配置，请按实际硬件电路修改：
 *          - SPI 总线：SCLK/MOSI/MISO 在 host_driver/porting/esp32/hal_com_spi.c
 *            的 HOST_PORT_SPI_* 宏中定义（默认 12/11/13），可在
 *            host_driver/user_config.h 中覆盖。
 *          - 设备 RST/UPD/NOTIFY 引脚与总线/设备参数（s_bus_* / s_dev_*）
 *            在下方文件级变量中配置。
 */

#include <stdio.h>
#include <string.h>
#include <stdint.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "nvs_flash.h"

#include "host_driver.h"
#include "host_mmw_api.h"
#include "app_console.h"
#include "app_wifi.h"
#include "app_spiffs.h"
#include "viz_server.h"

/* ---- 硬件配置 ----
 * 当前生效参数均为文件级变量（s_ 前缀），默认不赋值：
 * 启动时 app_hwcfg_load() 从 NVS 恢复，无记录则套用默认预设（spi）；
 * console `bus` 命令可整体切换预设并持久化（重启生效）。
 * 类型对齐 DevHw_Set_DefaultParam 形参：bus_type/bus_param/bus_id/引脚为
 * uint8_t，bus_speed 为 uint32_t，dev_param 作为 DevParam(uint32_t)。 */
static uint8_t  s_bus_type;      /* 总线类型：LLC_BUS_TYPE_SPI/I2C/UART */
static uint8_t  s_bus_param;     /* 总线参数：LLC_BUS_PARAM_*（SPI 模式等） */
static uint8_t  s_bus_id;        /* 总线编号（bus_id，对应 HAL 外设实例） */
static uint32_t s_bus_speed;     /* 总线时钟；下载阶段会强制降到 8MHz 以下 */
static uint32_t s_dev_param;     /* 设备参数（DevHw_t.param）：SPI=CS 引脚 / I2C=从机地址 */
static uint8_t  s_dev_rst_io;    /* 复位引脚 */
static uint8_t  s_dev_upd_io;    /* 升级控制引脚 */
static uint8_t  s_dev_notify_io; /* 设备通知(中断)引脚 */

/* ---- 总线预设表（console `bus` 命令按此整体切换） ----
 * 每种总线一组完整硬件参数；改硬件接线时修改此表即可。
 * 注意：UART/I2C 的 HAL 移植层当前未实现（porting_get_com_ops 仅支持 SPI），
 * 预设仅为配置预留，切换后需配套移植层才能工作。 */
typedef struct {
    const char *name;        /* 命令参数名：spi / i2c / uart */
    uint8_t  bus_type;
    uint8_t  bus_param;
    uint8_t  bus_id;
    uint32_t bus_speed;
    uint32_t dev_param;      /* SPI=CS 引脚 / I2C=从机地址 / UART=端口号 */
    uint8_t  rst_io;
    uint8_t  upd_io;
    uint8_t  notify_io;
} hw_preset_t;

static const hw_preset_t s_hw_presets[] = {
    /* name   bus_type           bus_param          bus_id  bus_speed  dev_param  rst upd notify */
    { "spi",  LLC_BUS_TYPE_SPI,  LLC_BUS_PARAM_SPI, 0,      32000000,  10,        9,  8,  7 },
    { "i2c",  LLC_BUS_TYPE_I2C,  0,                 0,      400000,    0x3A,      9,  8,  7 },
    { "uart", LLC_BUS_TYPE_UART, 0,                 0,      1000000,   0,         9,  8,  7 },
};
#define HW_PRESET_NUM        (sizeof(s_hw_presets) / sizeof(s_hw_presets[0]))
#define HW_PRESET_DEFAULT    0   /* 无 NVS 记录时默认套用的预设（spi） */

/* ---- NVS 持久化（存取当前生效的 8 个参数） ----
 * magic 标记"配置已由本驱动完整写入"：读不到或不匹配时一律套默认预设
 * （保证首次上电/数据不完整/被清除时可靠回退到 SPI）。 */
#define HWCFG_NVS_NS      "hwcfg"
#define HWCFG_MAGIC_KEY   "magic"
#define HWCFG_MAGIC_VAL   0x48434647u   /* "HCFG" */

typedef struct {
    const char *name;   /* NVS key */
    void       *val;    /* 指向 s_ 变量 */
    bool        is_u8;  /* true: uint8_t, false: uint32_t */
} hwcfg_item_t;

static const hwcfg_item_t s_hwcfg_items[] = {
    { "bus_type",   (void *)&s_bus_type,      true  },
    { "bus_param",  (void *)&s_bus_param,     true  },
    { "bus_id",     (void *)&s_bus_id,        true  },
    { "bus_speed",  (void *)&s_bus_speed,     false },
    { "dev_param",  (void *)&s_dev_param,     false },
    { "dev_rst",    (void *)&s_dev_rst_io,    true  },
    { "dev_upd",    (void *)&s_dev_upd_io,    true  },
    { "dev_notify", (void *)&s_dev_notify_io, true  },
};
#define HWCFG_ITEM_NUM  (sizeof(s_hwcfg_items) / sizeof(s_hwcfg_items[0]))

/* NVS flash 初始化（幂等：已初始化时忽略 ESP_ERR_INVALID_STATE） */
static void hwcfg_nvs_init(void)
{
    esp_err_t err = nvs_flash_init();
    if ((err == ESP_ERR_NVS_NO_FREE_PAGES) || (err == ESP_ERR_NVS_NEW_VERSION_FOUND)) {
        nvs_flash_erase();
        nvs_flash_init();
    }
}

/* 全部参数 + magic 标记写回 NVS（一次事务，保证完整性）；返回首个失败错误码 */
static int hwcfg_nvs_save_all(void)
{
    nvs_handle_t h;
    esp_err_t err;

    if (nvs_open(HWCFG_NVS_NS, NVS_READWRITE, &h) != ESP_OK) {
        return HOST_ERRCODE_IO_ERROR;
    }
    err = nvs_set_u32(h, HWCFG_MAGIC_KEY, HWCFG_MAGIC_VAL);
    for (size_t i = 0; (i < HWCFG_ITEM_NUM) && (err == ESP_OK); i++) {
        const hwcfg_item_t *item = &s_hwcfg_items[i];
        err = item->is_u8 ? nvs_set_u8(h, item->name, *(uint8_t *)item->val)
                          : nvs_set_u32(h, item->name, *(uint32_t *)item->val);
    }
    if (err == ESP_OK) {
        err = nvs_commit(h);
    }
    nvs_close(h);
    return (err == ESP_OK) ? HOST_ERRCODE_SUCCESS : HOST_ERRCODE_IO_ERROR;
}

/* 套用某个总线预设到当前变量（speed_override 非 0 时覆盖总线时钟），
 * 并持久化到 NVS；返回 HOST_ERRCODE_SUCCESS */
int app_hwcfg_apply_preset(int idx, uint32_t speed_override)
{
    const hw_preset_t *p;

    if ((idx < 0) || (idx >= (int)HW_PRESET_NUM)) {
        return HOST_ERRCODE_INVALID_PARAM;
    }
    p = &s_hw_presets[idx];
    s_bus_type      = p->bus_type;
    s_bus_param     = p->bus_param;
    s_bus_id        = p->bus_id;
    s_bus_speed     = (speed_override != 0) ? speed_override : p->bus_speed;
    s_dev_param     = p->dev_param;
    s_dev_rst_io    = p->rst_io;
    s_dev_upd_io    = p->upd_io;
    s_dev_notify_io = p->notify_io;
    return hwcfg_nvs_save_all();
}

/* 打印当前生效的硬件配置（加载完成/切换预设后调用，便于核对） */
static void hwcfg_dump(const char *tag)
{
    HOST_LOG_INF("[hwcfg] %s: bus_type=%u bus_param=%u bus_id=%u bus_speed=%lu "
                 "dev_param=%lu rst=%u upd=%u notify=%u\n",
                 tag,
                 s_bus_type, s_bus_param, s_bus_id, (unsigned long)s_bus_speed,
                 (unsigned long)s_dev_param, s_dev_rst_io, s_dev_upd_io, s_dev_notify_io);
}

/* 启动时加载硬件配置。
 * 规则：NVS 中 magic 标记匹配（= 本驱动完整写入过）才恢复；
 * 首次上电 / 记录被清除 / 数据不完整或损坏 → 一律套默认 SPI 预设并持久化。
 * 无论走哪条路径，加载完成后都打印一次当前配置。 */
void app_hwcfg_load(void)
{
    nvs_handle_t h;
    uint32_t magic = 0;

    hwcfg_nvs_init();
    if (nvs_open(HWCFG_NVS_NS, NVS_READONLY, &h) != ESP_OK) {
        goto use_default;
    }
    if (nvs_get_u32(h, HWCFG_MAGIC_KEY, &magic) != ESP_OK) {
        nvs_close(h);
        goto use_default;   /* 无 magic：首次上电或旧数据，不信任 */
    }
    for (size_t i = 0; i < HWCFG_ITEM_NUM; i++) {
        const hwcfg_item_t *item = &s_hwcfg_items[i];
        esp_err_t err = item->is_u8
                        ? nvs_get_u8(h, item->name, (uint8_t *)item->val)
                        : nvs_get_u32(h, item->name, (uint32_t *)item->val);
        if (err != ESP_OK) {
            nvs_close(h);
            goto use_default;   /* 配置不完整，回退默认 */
        }
    }
    nvs_close(h);
    HOST_LOG_INF("[hwcfg] restored from NVS(%s)\n", HWCFG_NVS_NS);
    hwcfg_dump("restored");
    return;

use_default:
    HOST_LOG_WRN("[hwcfg] no valid NVS config, apply default preset (spi)\n");
    app_hwcfg_apply_preset(HW_PRESET_DEFAULT, 0);
    hwcfg_dump("default preset");
}

/* 恢复默认（套用默认预设 spi 并写回 NVS） */
int app_hwcfg_reset(void)
{
    return app_hwcfg_apply_preset(HW_PRESET_DEFAULT, 0);
}

/* ---- 供 console `bus` 命令读取当前参数 / 枚举预设 ---- */

int app_hwcfg_count(void)
{
    return (int)HWCFG_ITEM_NUM;
}

const char *app_hwcfg_name(int idx)
{
    if ((idx < 0) || (idx >= (int)HWCFG_ITEM_NUM)) {
        return NULL;
    }
    return s_hwcfg_items[idx].name;
}

uint32_t app_hwcfg_get(int idx)
{
    const hwcfg_item_t *item;

    if ((idx < 0) || (idx >= (int)HWCFG_ITEM_NUM)) {
        return 0;
    }
    item = &s_hwcfg_items[idx];
    return item->is_u8 ? *(uint8_t *)item->val : *(uint32_t *)item->val;
}

int app_hwcfg_preset_count(void)
{
    return (int)HW_PRESET_NUM;
}

const char *app_hwcfg_preset_name(int idx)
{
    if ((idx < 0) || (idx >= (int)HW_PRESET_NUM)) {
        return NULL;
    }
    return s_hw_presets[idx].name;
}

/* ---- 设备启动次数统计（0xFF 启动上报） ---- */
/* 提升为文件级全局：console 的 `startup` 命令可随时查询，不受回调作用域限制 */
static uint32_t dev_startup_count = 0;

/**
 * @brief 获取设备启动累计次数（0xFF 启动上报计数）。
 * @retval 启动次数（app_data_handle 在 0xFF 分支中累加）
 */
uint32_t app_startup_count_get(void)
{
    return dev_startup_count;
}

static void app_data_handle(uint32_t msg_id, uint8_t *data, uint32_t data_len, void *cb_arg)
{
    static uint32_t heart_beat_count = 0;

    if (msg_id == 0xC1) {
        ;
    } else if (msg_id == 0xC2) {
        ;
    } else if (msg_id == 0xC3) {
        /* 0xC3 点云推送可视化服务器（viz_server 内部按推送开关决定是否发送） */
        viz_server_handle_data(msg_id, data, data_len);
    } else if (msg_id == 0xC6) {
        ;
    } else if (msg_id == 0xFE) {
        heart_beat_count++;
    } else if (msg_id == 0xFF) {
        dev_startup_count++;
        HOST_LOG_INF("dev(%p) startup times=%lu\n", cb_arg, dev_startup_count);
    }
}

void app_main(void)
{
    DEV_HANDLE dev = DEV_HANDLE_INVALID;
    DevHw_t hw_cfg;
    HifCfg_t hif_cfg;
    int ret;

    /* 0. 最先启动命令行控制台（UART0 串口，输入 help 查看命令）。
     *    放在最前面：即使后续初始化失败 return，控制台依然可用，
     *    可通过命令手动 dev_reg / dev_open 排查问题。 */
    if (app_console_init() != 0) {
        HOST_LOG_ERR("[main] console init fail\n");
    } else {
        HOST_LOG_INF("[main] console ready, type 'help'\n");
    }

    /* 0.5 加载硬件配置（NVS 持久化，console `bus` 命令可查看/修改，重启后生效） */
    app_hwcfg_load();

    /* 1. 挂载 SPIFFS（/spiffs：从机固件文件系统，含出厂预置 img/ 与在线 img_online/）。
     *    独立于网络与 host_driver，失败不阻塞启动，可用 `ls` 命令查看文件树。 */
    ret = app_spiffs_init();
    if (ret != HOST_ERRCODE_SUCCESS) {
        HOST_LOG_ERR("[main] app_spiffs_init fail(%d)\n", ret);
    } else {
        HOST_LOG_INF("[main] spiffs ready (ls to show file tree)\n");
    }

    /* 2. 网络初始化（esp_netif/tcpip/WiFi 子系统）。
     *    必须在 viz_server 使用 socket 之前完成，否则 lwIP tcpip 线程
     *    未启动会导致 "Invalid mbox" 断言崩溃。
     *    这里只初始化不连接，实际连接用 console 指令 `wifi <ssid> <pass>`。 */
    ret = app_wifi_init();
    if (ret != HOST_ERRCODE_SUCCESS) {
        HOST_LOG_ERR("[main] app_wifi_init fail(%d)\n", ret);
    } else {
        HOST_LOG_INF("[main] network stack ready\n");
    }

    /* 3. 尝试连接默认 WiFi（若已用 `wifi default <ssid> <pass>` 设置）：
     *    超时 5s，连接过程中每 0.5s 打印一个 '.'。
     *    未设置默认 WiFi 则跳过（HOST_ERRCODE_NOT_FOUND）。 */
    ret = app_wifi_connect_default(5000);
    if (ret == HOST_ERRCODE_SUCCESS) {
        char ip[32];
        app_wifi_status(ip, sizeof(ip));
        HOST_LOG_INF("[main] default wifi connected, ip=%s\n", ip);
    } else if (ret == HOST_ERRCODE_NOT_FOUND) {
        HOST_LOG_INF("[main] no default wifi (set with `wifi default <ssid> <pass>`)\n");
    } else {
        HOST_LOG_INF("[main] default wifi connect fail(%d)\n", ret);
    }

    /* 4. 启动可视化服务器（HTTP 网页 + WebSocket 点云推送）。
     *    服务器先行就绪，浏览器访问 http://<esp32-ip>/ 即可打开页面；
     *    点云数据待 host_driver 初始化完成后自动推送。 */
    ret = viz_server_start();
    if (ret != HOST_ERRCODE_SUCCESS) {
        HOST_LOG_ERR("[main] viz_server_start fail(%d)\n", ret);
    } else {
        HOST_LOG_INF("[main] viz server ready\n");
    }

    /* 5. host_driver 相关内容统一放在最后（项目约定）：
     *    初始化驱动 -> 注册设备 -> 注册上报回调 -> 打开设备。 */

    ret = Host_Driver_Init();
    if (ret != HOST_ERRCODE_SUCCESS) {
        HOST_LOG_ERR("[main] Host_Driver_Init fail(%d)\n", ret);
        return;
    }
    HOST_LOG_INF("[main] host driver init ok\n");

    /* 注册设备：总线 + 引脚配置（参数为文件级变量 s_*，由 app_hwcfg_load
     * 在启动时按 NVS/默认预设填充；`bus` 命令切换预设后重启生效） */
    DevHw_Set_DefaultParam(&hw_cfg,
                           s_bus_type, s_bus_param,
                           s_bus_id, s_bus_speed,
                           s_dev_upd_io, s_dev_rst_io, s_dev_notify_io,
                           s_dev_param);

    memset(&hif_cfg, 0, sizeof(hif_cfg));

    ret = Host_Device_Regist(&dev, &hw_cfg, &hif_cfg);
    if (ret != HOST_ERRCODE_SUCCESS) {
        HOST_LOG_ERR("[main] Host_Device_Regist fail(%d)\n", ret);
        return;
    }
    HOST_LOG_INF("[main] device regist ok, device = %p\n", dev);

    ret = Mmw_C1_CubeData_Handle_Set(dev, app_data_handle, dev);
    if (ret != HOST_ERRCODE_SUCCESS) {
        HOST_LOG_ERR("[main] Mmw_C1_CubeData_Handle_Set fail(%d)\n", ret);
        return;
    }
    HOST_LOG_INF("[main] device regist 0xC1 msg ok\n");

    ret = Mmw_C2_FFTData_Handle_Set(dev, app_data_handle, dev);
    if (ret != HOST_ERRCODE_SUCCESS) {
        HOST_LOG_ERR("[main] Mmw_C2_FFTData_Handle_Set fail(%d)\n", ret);
        return;
    }
    HOST_LOG_INF("[main] device regist 0xC2 msg ok\n");

    ret = Mmw_C3_Objects_Handle_Set(dev, app_data_handle, dev);
    if (ret != HOST_ERRCODE_SUCCESS) {
        HOST_LOG_ERR("[main] Mmw_C3_Objects_Handle_Set fail(%d)\n", ret);
        return;
    }
    HOST_LOG_INF("[main] device regist 0xC3 msg ok\n");

    ret = Mmw_C6_GeneralData_Handle_Set(dev, app_data_handle, dev);
    if (ret != HOST_ERRCODE_SUCCESS) {
        HOST_LOG_ERR("[main] Mmw_C6_GeneralData_Handle_Set fail(%d)\n", ret);
        return;
    }
    HOST_LOG_INF("[main] device regist 0xC6 msg ok\n");

    ret = Mmw_FE_Heartbeat_Handle_Set(dev, app_data_handle, dev);
    if (ret != HOST_ERRCODE_SUCCESS) {
        HOST_LOG_ERR("[main] Mmw_FE_Heartbeat_Handle_Set fail(%d)\n", ret);
        return;
    }
    HOST_LOG_INF("[main] device regist 0xFE msg ok\n");

    ret = Mmw_FF_Startup_Handle_Set(dev, app_data_handle, dev);
    if (ret != HOST_ERRCODE_SUCCESS) {
        HOST_LOG_ERR("[main] Mmw_FF_Startup_Handle_Set fail(%d)\n", ret);
        return;
    }
    HOST_LOG_INF("[main] device regist 0xFF msg ok\n");

    /* 打开设备（上电 + 初始化 SPI 设备） */
    ret = Host_Device_Open(dev);
    if (ret != HOST_ERRCODE_SUCCESS) {
        HOST_LOG_ERR("[main] Host_Device_Open fail(%d)\n", ret);
        return;
    }
    HOST_LOG_INF("[main] device open ok\n");
}
