/**
 * @file    viz_server.c
 * @brief   ESP32 点云可视化服务器实现（esp_http_server）。
 *
 * 端点：
 *   GET /          -> 3D 点云页面（index.html）
 *   GET /app.js    -> 渲染脚本（three.js 场景，原生 WebSocket 收数）
 *   GET /style.css -> 样式
 *   GET /ws        -> WebSocket：连接后服务器主动推送 config 与点云帧
 *
 * 推送数据格式（与 PointCloudDisplay 前端约定一致，coord_mode=cartesian）：
 *   config: {"type":"config","config":{"coord_mode":"cartesian","angle_unit":"deg","velocity_scale":2.0}}
 *   data:   {"type":"data","data":{"Type":0,"Flag":0,"TotalLength":0,
 *             "Point":[{"range_or_x":x_m,"azimath_or_y":y_m,"elevation_or_z":z_m,
 *                       "velocity":v_mps,"snr":snr_db}, ...]}}
 *   坐标 cm->m、速度 cm/s->m/s、SNR 0.01dB->dB。
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_http_server.h"
#include "esp_netif.h"
#include "esp_log.h"

#include "viz_server.h"
#include "host_driver.h"
#include "host_mmw_api.h"
#include "assets.h"

#define VIZ_TAG                     "viz"

#define VIZ_WS_MAX_CLIENTS          4
#define VIZ_FRAME_BUF_SIZE          (16 * 1024)

typedef struct {
    int fd;
    bool used;
    uint32_t fail_cnt;   /* 连续发送失败次数（用于区分真死连接与暂时缓冲满） */
} viz_ws_client_t;

static httpd_handle_t s_server = NULL;
static viz_ws_client_t s_clients[VIZ_WS_MAX_CLIENTS];
static SemaphoreHandle_t s_lock = NULL;
static volatile uint32_t s_push_enable = 1;

/* ---------------- WebSocket 客户端管理 ---------------- */

/* 登记 WebSocket 客户端。
 * 返回：0=新登记成功；1=该 fd 已登记（去重，无需重复下发 config）；-1=客户端列表已满 */
static int ws_clients_add(httpd_handle_t server, int fd)
{
    int ret = 0;
    (void)server;
    xSemaphoreTake(s_lock, portMAX_DELAY);
    for (int i = 0; i < VIZ_WS_MAX_CLIENTS; i++) {
        if (s_clients[i].used && s_clients[i].fd == fd) {
            ret = 1;            /* 已存在 */
            break;
        }
    }
    if (ret == 0) {
        ret = -1;               /* 默认：列表已满 */
        for (int i = 0; i < VIZ_WS_MAX_CLIENTS; i++) {
            if (!s_clients[i].used) {
                s_clients[i].fd = fd;
                s_clients[i].used = true;
                ret = 0;        /* 新登记成功 */
                break;
            }
        }
    }
    xSemaphoreGive(s_lock);
    return ret;
}

static void ws_clients_remove(int fd)
{
    xSemaphoreTake(s_lock, portMAX_DELAY);
    for (int i = 0; i < VIZ_WS_MAX_CLIENTS; i++) {
        if (s_clients[i].used && s_clients[i].fd == fd) {
            s_clients[i].used = false;
            break;
        }
    }
    xSemaphoreGive(s_lock);
}

static int ws_clients_count(void)
{
    int n = 0;
    xSemaphoreTake(s_lock, portMAX_DELAY);
    for (int i = 0; i < VIZ_WS_MAX_CLIENTS; i++) {
        if (s_clients[i].used) {
            n++;
        }
    }
    xSemaphoreGive(s_lock);
    return n;
}

/* 异步推送文本帧到所有客户端。
 * 注意：httpd_ws_send_frame_async 内部直接 send()，lwIP 缓冲满等暂时失败
 * 也会返回 ESP_FAIL——绝不能因此判定连接断开并关闭，否则高频推送会把
 * 正常连接误杀（浏览器表现为连上即断、反复重连）。
 * 仅当会话已不存在（ESP_ERR_INVALID_ARG）或连续失败超阈值时才释放槽位。 */
#define VIZ_SEND_FAIL_MAX         20   /* 连续失败阈值（@20Hz 约 1s） */

static void ws_broadcast_text(const char *payload, size_t len)
{
    int dead_fds[VIZ_WS_MAX_CLIENTS];
    int dead_cnt = 0;

    xSemaphoreTake(s_lock, portMAX_DELAY);
    for (int i = 0; i < VIZ_WS_MAX_CLIENTS; i++) {
        if (!s_clients[i].used) {
            continue;
        }
        httpd_ws_frame_t frame = {
            .final = true,
            .fragmented = false,
            .type = HTTPD_WS_TYPE_TEXT,
            .payload = (uint8_t *)payload,
            .len = len,
        };
        esp_err_t err = httpd_ws_send_frame_async(s_server, s_clients[i].fd, &frame);
        if (err == ESP_OK) {
            s_clients[i].fail_cnt = 0;
        } else if (err == ESP_ERR_INVALID_ARG) {
            /* 会话已被 httpd 关闭（sock_db 不存在）：确认死连接，释放槽位 */
            dead_fds[dead_cnt++] = s_clients[i].fd;
            s_clients[i].used = false;
            s_clients[i].fail_cnt = 0;
        } else {
            /* ESP_FAIL：多为发送缓冲满/暂时失败，连接仍有效，不主动关闭；
             * 连续失败超阈值（httpd 大概率已自行清理会话）才释放槽位 */
            if (++s_clients[i].fail_cnt >= VIZ_SEND_FAIL_MAX) {
                dead_fds[dead_cnt++] = s_clients[i].fd;
                s_clients[i].used = false;
                s_clients[i].fail_cnt = 0;
            }
        }
    }
    xSemaphoreGive(s_lock);

    /* 出锁后关闭确认死亡的会话（浏览器会感知断开并自动重连） */
    for (int i = 0; i < dead_cnt; i++) {
        httpd_sess_trigger_close(s_server, dead_fds[i]);
    }
}

/* ---------------- HTTP handlers ---------------- */

static esp_err_t send_text(httpd_req_t *req, const char *body, const char *ctype)
{
    httpd_resp_set_type(req, ctype);
    httpd_resp_send(req, body, HTTPD_RESP_USE_STRLEN);
    return ESP_OK;
}

static esp_err_t uri_index(httpd_req_t *req)
{
    return send_text(req, viz_web_index_html, "text/html; charset=utf-8");
}

static esp_err_t uri_app_js(httpd_req_t *req)
{
    return send_text(req, viz_web_app_js, "application/javascript; charset=utf-8");
}

static esp_err_t uri_three_js(httpd_req_t *req)
{
    /* 本地托管 three.js（内嵌固件），避免浏览器跟踪防护拦截 CDN */
    return send_text(req, viz_web_three_min_js, "application/javascript; charset=utf-8");
}

static esp_err_t uri_style_css(httpd_req_t *req)
{
    return send_text(req, viz_web_style_css, "text/css; charset=utf-8");
}

/* WebSocket 端点：连接时登记 fd 并下发 config（仅首次握手下发一次） */
static esp_err_t uri_ws(httpd_req_t *req)
{
    if (req->method == HTTP_GET) {
        int fd = httpd_req_to_sockfd(req);
        int r = ws_clients_add(req->handle, fd);
        if (r < 0) {
            /* 客户端列表已满：拒绝该连接，浏览器会重试 */
            ESP_LOGW(VIZ_TAG, "ws client %d rejected: no free slot", fd);
            return ESP_FAIL;
        }
        if (r == 0) {
            /* 首次握手：下发 config（重复连接/重复帧不下发，避免覆盖前端设置） */
            static const char cfg_msg[] =
                "{\"type\":\"config\",\"config\":{\"coord_mode\":\"cartesian\","
                "\"angle_unit\":\"deg\",\"velocity_scale\":1.0}}";
            httpd_ws_frame_t frame = {
                .final = true,
                .fragmented = false,
                .type = HTTPD_WS_TYPE_TEXT,
                .payload = (uint8_t *)cfg_msg,
                .len = sizeof(cfg_msg) - 1,
            };
            esp_err_t err = httpd_ws_send_frame_async(req->handle, fd, &frame);
            if (err != ESP_OK) {
                ws_clients_remove(fd);
                return ESP_OK;
            }
            ESP_LOGI(VIZ_TAG, "ws client %d connected (total %d)", fd, ws_clients_count());
        }
        return ESP_OK;
    }
    /* 浏览器发来的帧（一般无）：读取忽略，用于检测断开 */
    httpd_ws_frame_t ws_frame = { 0 };
    ws_frame.type = HTTPD_WS_TYPE_TEXT;
    esp_err_t ret = httpd_ws_recv_frame(req, &ws_frame, 0);
    if (ret != ESP_OK) {
        ws_clients_remove(httpd_req_to_sockfd(req));
    }
    return ret;
}

/* ---------------- 0xC3 数据 -> JSON 推送 ---------------- */

void viz_server_handle_data(uint32_t msg_id, uint8_t *data, uint32_t data_len)
{
    FrameData_C3_t *frame;
    char *buf;
    size_t pos = 0;
    uint32_t n_pts = 0;
    bool first = true;

    /* socket 发送不允许在中断上下文执行（lwIP tcpip API 非 ISR 安全）；
     * 若回调出现在 ISR 中（异常路径），直接跳过本次推送。 */
    if (xPortInIsrContext()) {
        return;
    }
    if ((msg_id != 0xC3) || !viz_server_get_enable() || (s_server == NULL)) {
        return;
    }
    if (ws_clients_count() == 0) {
        return;   /* 无客户端，跳过解析 */
    }
    /* 0xC3 帧布局（host_mmw_api.h）：FrameData_C3_t(16B) + Frame_Point_t[](12B/点) */
    if ((data == NULL) || (data_len < sizeof(FrameData_C3_t))) {
        return;
    }

    buf = malloc(VIZ_FRAME_BUF_SIZE);
    if (buf == NULL) {
        return;
    }

    frame = (FrameData_C3_t *)data;
    /* 点数 = (整帧字节数 - 帧头字节数) / 每点字节数 */
    n_pts = HOST_MMW_GET_C3_DATA_LENGTH(data_len);

    /* ---- 输出 JSON 格式（与 PointCloudDisplay 前端约定一致）----
     * {
     *   "type": "data",
     *   "data": {
     *     "Type":        <frame->type>,         // 0x00 目标对象
     *     "Flag":        <frame->flag>,
     *     "TotalLength": <frame->total_length>,
     *     "Point": [                            // 点数组
     *       { "range_or_x": <x_m>,  "azimath_or_y": <y_m>,
     *         "elevation_or_z": <z_m>, "velocity": <v_mps>, "snr": <snr_db> },
     *       ... 每个点对象之间用 "," 分隔（首点无前缀）
     *     ]
     *   }
     * }
     * 注：0xC3 原始单位为 x,y,z:cm / velocity:cm/s / snr:0.01dB，统一 /100 换算
     */
    pos += snprintf(buf + pos, VIZ_FRAME_BUF_SIZE - pos,
                    "{"
                        "\"type\":\"data\","
                        "\"data\":{"
                            "\"Type\":%u,"
                            "\"Flag\":%u,"
                            "\"TotalLength\":%u,"
                            "\"Point\":[",
                    frame->type, frame->flag, frame->total_length);

    for (uint32_t i = 0; (i < n_pts) && (pos < (VIZ_FRAME_BUF_SIZE - 96)); i++) {
        const Frame_Point_t *pt = &frame->data[i];
        int16_t x, y, z, vel, snr;

        /* Frame_Point_t 字段为 uint16_t（reserved 仅对齐），
         * 坐标/速度可为负，按有符号 16 位读取 */
        memcpy(&x,   &pt->type.coord.x,        2);
        memcpy(&y,   &pt->type.coord.y,        2);
        memcpy(&z,   &pt->type.coord.z,        2);
        memcpy(&vel, &pt->type.coord.velocity, 2);
        memcpy(&snr, &pt->type.coord.snr,      2);

        /* 单个点对象：
         *   { "range_or_x":x, "azimath_or_y":y, "elevation_or_z":z,
         *     "velocity":v, "snr":snr } */
        pos += snprintf(buf + pos, VIZ_FRAME_BUF_SIZE - pos,
                        "%s{"
                            "\"range_or_x\":%.2f,"
                            "\"azimath_or_y\":%.2f,"
                            "\"elevation_or_z\":%.2f,"
                            "\"velocity\":%.2f,"
                            "\"snr\":%.2f"
                        "}",
                        first ? "" : ",",
                        (float)x / 100.0f, (float)y / 100.0f, (float)z / 100.0f,
                        (float)vel / 100.0f, (float)snr / 100.0f);
        first = false;
    }

    /* 闭合 JSON："]"（Point 数组）+ "}"（data 对象）+ "}"（外层） */
    pos += snprintf(buf + pos, VIZ_FRAME_BUF_SIZE - pos,
                            "]"
                        "}"
                    "}");

    ws_broadcast_text(buf, pos);
    free(buf);
}

/* ---------------- 对外接口 ---------------- */

void viz_server_set_enable(uint32_t enable)
{
    s_push_enable = enable ? 1 : 0;
}

uint32_t viz_server_get_enable(void)
{
    return s_push_enable;
}

int viz_server_info(int *client_cnt)
{
    if (client_cnt != NULL) {
        *client_cnt = ws_clients_count();
    }
    return (s_server != NULL) ? 1 : 0;
}

int viz_server_start(void)
{
    httpd_config_t cfg = HTTPD_DEFAULT_CONFIG();

    if (s_server != NULL) {
        return HOST_ERRCODE_SUCCESS;
    }

    /* 确保 lwIP tcpip 线程已初始化（esp_netif_init 内部调用 tcpip_init；
     * 若 app_wifi_init 已调用过则此处幂等跳过）。
     * 否则 httpd_ws_send_frame_async 的 socket 发送会触发
     * lwIP 断言 "Invalid mbox"（tcpip_mbox 无效）。 */
    if (esp_netif_init() != ESP_OK) {
        ESP_LOGE(VIZ_TAG, "esp_netif_init fail");
        return HOST_ERRCODE_SYSERR;
    }

    if (s_lock == NULL) {
        s_lock = xSemaphoreCreateMutex();
    }
    memset(s_clients, 0, sizeof(s_clients));

    cfg.stack_size = 8192;
    cfg.max_uri_handlers = 8;
    cfg.max_open_sockets = VIZ_WS_MAX_CLIENTS + 2;
    cfg.lru_purge_enable = true;
    /* HTTP/WS（点云推送）固定 core0，与 host_driver（UART 接收，core1）隔离，
     * 避免推送负载抢占 UART 事件任务导致接收滞后/丢数据 */
    cfg.core_id = 0;

    if (httpd_start(&s_server, &cfg) != ESP_OK) {
        ESP_LOGE(VIZ_TAG, "httpd_start fail");
        return HOST_ERRCODE_IO_ERROR;
    }

    static const httpd_uri_t uris[] = {
        { .uri = "/",        .method = HTTP_GET, .handler = uri_index,   .user_ctx = NULL },
        { .uri = "/app.js",  .method = HTTP_GET, .handler = uri_app_js,  .user_ctx = NULL },
        { .uri = "/three.min.js", .method = HTTP_GET, .handler = uri_three_js, .user_ctx = NULL },
        { .uri = "/style.css", .method = HTTP_GET, .handler = uri_style_css, .user_ctx = NULL },
        { .uri = "/ws",      .method = HTTP_GET, .handler = uri_ws, .user_ctx = NULL,
          .is_websocket = true },
    };
    for (size_t i = 0; i < sizeof(uris) / sizeof(uris[0]); i++) {
        if (httpd_register_uri_handler(s_server, &uris[i]) != ESP_OK) {
            ESP_LOGE(VIZ_TAG, "register uri %s fail", uris[i].uri);
            return HOST_ERRCODE_SYSERR;
        }
    }

    ESP_LOGI(VIZ_TAG, "viz server ready on :80");
    return HOST_ERRCODE_SUCCESS;
}
