/**
 * @file    viz_server.h
 * @brief   ESP32 点云可视化服务器：HTTP 网页 + WebSocket 数据推送。
 *
 * 浏览器访问 http://<esp32-ip>/ 获取 3D 点云页面，
 * 页面通过原生 WebSocket 连接 /ws，ESP32 主动推送 0xC3 点云帧。
 */
#ifndef VIZ_SERVER_H_
#define VIZ_SERVER_H_

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 启动 HTTP + WebSocket 服务器（端口 80）。
 * @retval HOST_ERRCODE_SUCCESS 成功；其它失败
 */
int viz_server_start(void);

/**
 * @brief 处理 0xC3 上报数据：解析点云并推送 JSON 到所有 WebSocket 客户端。
 * @note  在数据回调上下文（HIF 任务）调用，内部异步发送，不阻塞。
 */
void viz_server_handle_data(uint32_t msg_id, uint8_t *data, uint32_t data_len);

/**
 * @brief 控制推送：0=停止推送 1=推送（viz 指令）。
 */
void viz_server_set_enable(uint32_t enable);

/**
 * @brief 查询推送开关状态。
 */
uint32_t viz_server_get_enable(void);

/**
 * @brief 查询服务器运行状态与当前 WebSocket 客户端数。
 */
int viz_server_info(int *client_cnt);

#ifdef __cplusplus
}
#endif

#endif /* VIZ_SERVER_H_ */
