const defaultConfig = {coord_mode: 'spherical', angle_unit: 'deg', velocity_scale: 2.0};
let socket = null;
let config = null;
let latestData = null;
let showArrows = false;
let showSnr = true;
let showAxisLabels = true;
let velocityScale = defaultConfig.velocity_scale;
let cameraSpherical = null;
let cameraRadiusSet = false;
let isRealData = false;      // 当前是否接收实时数据
let reconnectTimer = null;   // WebSocket 自动重连定时器（服务恢复后自动回到实时）

// 吸附配置
const SNAP_STRENGTH = 0.18;
const SNAP_RANGE = 0.22;

let scene, sceneGroup, camera, renderer, pointsGroup, arrowsGroup, axisLabelsGroup, clusterGroup,
    gridObject, groundPlane, planeXY, planeYZ, yGridObject, yzGridObject;
// 动态注册的事件监听器（[target, type, fn]），cleanup() 时统一移除，防止滞留
const domListeners = [];
let gridSpacing = 1.0;     // XZ 网格间距
let yGridSpacing = 1.0;    // XY 网格间距
let yzGridSpacing = 1.0;    // YZ 网格间距
let heightAxis = 'z';      // 高度轴：'x'|'y'|'z'，选中的轴竖直朝上，对应平面为地面（默认 Z）
let showCluster = false;   // 聚类显示
let clusterEps = 0.5;      // DBSCAN 邻域半径
let clusterMinPts = 5;     // DBSCAN 最少点数
let clusterColor = 0x0cac51; // 聚类框颜色 RGB(12,172,81)
let clusterSnrMin = 20;      // 聚类 SNR 阈值(dB)，低于阈值的点不参与聚类（默认 20dB）
let pointsObject = null;
const pointsMaterial = new THREE.PointsMaterial({
  size: 0.1,
  vertexColors: true,
  sizeAttenuation: true,
});
const lookAtTarget = new THREE.Vector3(0, 0, 0);

// SNR 颜色配置：每段 {snr: 阈值, rgb: [r,g,b]}
const SNR_DEFAULTS = [
  { snr: 0,  rgb: [0, 0, 1] },
  { snr: 10, rgb: [0, 1, 1] },
  { snr: 20, rgb: [0, 1, 0] },
  { snr: 30, rgb: [1, 1, 0] },
  { snr: 40, rgb: [1, 0, 0] },
];
let snrStops = SNR_DEFAULTS.map(s => ({ snr: s.snr, rgb: [...s.rgb] }));
let snrMax = 40;  // SNR 最大值

// 更新"数据源"指示：页面仅实时数据模式，无数据时显示"等待数据"
function updateModeUI() {
  const ds = document.getElementById('dataSource');
  ds.textContent = isRealData ? '实时数据' : '等待数据';
}

// WebSocket 自动重连：离线（ESP32 未启动/未连 WiFi/服务恢复前）时定时重试，
// 重连成功即自动切回实时数据。
function scheduleReconnect() {
  if (reconnectTimer) return;     // 已有重连计划，避免叠加
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    setupSocket();
  }, 2000);
}

function setupSocket() {
  let sock;
  try {
    sock = new WebSocket('ws://' + location.host + '/ws');
  } catch (e) {
    scheduleReconnect();
    return;
  }
  socket = sock;
  sock.onopen = () => {
    if (socket !== sock) return;  // 旧连接已被手动重连替换，忽略
    setStatus('已连接，等待数据...');
  };
  sock.onclose = () => {
    if (socket !== sock) return;  // 旧连接被手动重连主动关闭，忽略
    setStatus('连接断开');
    scheduleReconnect();   // 自动重连，ESP32 服务恢复后自动回到实时
  };
  sock.onerror = () => { /* 错误由 onclose 统一处理 */ };
  sock.onmessage = (ev) => {
    let msg;
    try { msg = JSON.parse(ev.data); } catch (e) { return; }
    if (msg.type === 'config') {
      const cfg = msg.config;
      config = cfg;
      document.getElementById('mode').textContent = cfg.coord_mode;
      if (cfg.velocity_scale !== undefined) {
        velocityScale = cfg.velocity_scale;
        const slider = document.getElementById('velocityScale');
        const label = document.getElementById('velocityScaleVal');
        slider.value = velocityScale;
        label.textContent = velocityScale.toFixed(2);
      }
      return;
    }
    if (msg.type === 'data') {
      isRealData = true;
      latestData = msg.data;
      updateScene(msg.data);
      updateModeUI();
    }
  };
}

// 手动重连实时数据（右上角按钮）：立即重建 WebSocket 连接
function reconnectNow() {
  if (reconnectTimer) {            // 取消待执行的自动重连计划，避免重复建连
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
  if (socket) {                    // 关闭旧连接（onclose 因身份不匹配会忽略）
    const old = socket;
    socket = null;
    try { old.close(); } catch (_) {}
  }
  isRealData = false;
  setStatus('重新连接中...');
  updateModeUI();
  setupSocket();                   // 立即建立新连接
}

document.getElementById('showArrows').addEventListener('change', (e) => {
  showArrows = e.target.checked;
  if (latestData) updateScene(latestData);
});
document.getElementById('showSnr').addEventListener('change', (e) => {
  showSnr = e.target.checked;
  if (latestData) updateScene(latestData);
});
document.getElementById('showAxisLabels').addEventListener('change', (e) => {
  showAxisLabels = e.target.checked;
  if (axisLabelsGroup) axisLabelsGroup.visible = showAxisLabels;
});

document.getElementById('velocityScale').addEventListener('input', (e) => {
  velocityScale = parseFloat(e.target.value);
  document.getElementById('velocityScaleVal').textContent = velocityScale.toFixed(2);
  if (latestData) updateScene(latestData);
});

// SNR 颜色配置弹窗
let tempSnrStops = [];      // [{snr, rgb}]
let tempSnrCount = SNR_DEFAULTS.length;
let tempMaxSnr = 40;

// rainbowRGB: 彩虹渐变，idx=0→纯蓝，idx=count-1→纯红
function rainbowRGB(idx, count) {
  const n = count - 1 || 1;
  const pos = idx * 4 / n;  // [0, 4] 对应蓝→青→绿→黄→红
  if (pos <= 1)       return [0, pos, 1];                       // 蓝→青
  if (pos <= 2)       return [0, 1, 2 - pos];                   // 青→绿
  if (pos <= 3)       return [pos - 2, 1, 0];                   // 绿→黄
  return [1, 4 - pos, 0];                                       // 黄→红
}

function rgbToHex(rgb) {
  return '#' + rgb.map(v => {
    const h = Math.round(v * 255).toString(16);
    return h.length === 1 ? '0' + h : h;
  }).join('');
}

function hexToRgb(hex) {
  const v = parseInt(hex.slice(1), 16);
  return [(v >> 16) & 255, (v >> 8) & 255, v & 255];
}

function renderSnrColorList() {
  const list = document.getElementById('snrColorList');
  list.innerHTML = '';
  for (let i = 0; i < tempSnrCount; i++) {
    if (!tempSnrStops[i]) tempSnrStops[i] = { snr: i * 10, rgb: rainbowRGB(i, tempSnrCount) };
    const stop = tempSnrStops[i];
    const hex = rgbToHex(stop.rgb);
    const row = document.createElement('div');
    row.className = 'row';
    row.innerHTML = `
      <span style="color:#888;font-size:12px;">${i + 1}</span>
      <label style="width:auto;">SNR</label>
      <input type="number" value="${stop.snr}" data-idx="${i}" class="snr-val"
        style="width:60px;background:#222;color:#eee;border:1px solid #555;border-radius:3px;padding:2px 4px;font-size:13px;" step="1">
      <input type="color" value="${hex}" data-idx="${i}" class="snr-color-pick">
      <span class="color-hex">${hex}</span>
    `;
    list.appendChild(row);
  }
  list.querySelectorAll('.snr-val').forEach(input => {
    input.addEventListener('input', (e) => {
      const idx = parseInt(e.target.dataset.idx);
      let v = parseInt(e.target.value);
      if (isNaN(v)) return;
      if (v > tempMaxSnr) { v = tempMaxSnr; e.target.value = tempMaxSnr; }
      if (v < 0) { v = 0; e.target.value = '0'; }
      tempSnrStops[idx].snr = v;
    });
  });
  list.querySelectorAll('.snr-color-pick').forEach(input => {
    input.addEventListener('input', (e) => {
      const idx = parseInt(e.target.dataset.idx);
      const hex = e.target.value;
      const rgb = hexToRgb(hex);
      tempSnrStops[idx].rgb = [rgb[0] / 255, rgb[1] / 255, rgb[2] / 255];
      e.target.parentElement.querySelector('.color-hex').textContent = hex;
    });
  });
}

document.getElementById('snrConfigBtn').addEventListener('click', () => {
  tempSnrStops = snrStops.map(s => ({ snr: s.snr, rgb: [...s.rgb] }));
  tempSnrCount = tempSnrStops.length;
  tempMaxSnr = snrMax;
  document.getElementById('snrCount').value = tempSnrCount;
  document.getElementById('snrMaxInput').value = tempMaxSnr;
  renderSnrColorList();
  document.getElementById('snrOverlay').classList.add('show');
});

document.getElementById('snrCount').addEventListener('input', (e) => {
  let n = parseInt(e.target.value);
  if (isNaN(n) || n < 5) { n = 5; e.target.value = '5'; }
  if (n > 20) { n = 20; e.target.value = '20'; }
  tempSnrCount = n;
  tempSnrStops.length = tempSnrCount;
  for (let i = 0; i < tempSnrCount; i++) {
    const snr = tempSnrStops[i] ? tempSnrStops[i].snr : i * 10;
    tempSnrStops[i] = { snr: snr, rgb: rainbowRGB(i, tempSnrCount) };
  }
  renderSnrColorList();
});

document.getElementById('snrMaxInput').addEventListener('input', (e) => {
  let v = parseInt(e.target.value);
  if (isNaN(v) || v < 1) { v = 1; e.target.value = '1'; }
  tempMaxSnr = v;
  // 修正超出范围的 SNR 值
  tempSnrStops.forEach(s => { if (s.snr > tempMaxSnr) s.snr = tempMaxSnr; });
  renderSnrColorList();
});

document.getElementById('snrAutoSpace').addEventListener('click', () => {
  const n = tempSnrCount;
  for (let i = 0; i < n; i++) {
    tempSnrStops[i].snr = Math.round(i * tempMaxSnr / (n - 1));
  }
  renderSnrColorList();
});

document.getElementById('snrResetDefault').addEventListener('click', () => {
  tempSnrCount = SNR_DEFAULTS.length;
  tempMaxSnr = 40;
  document.getElementById('snrCount').value = tempSnrCount;
  document.getElementById('snrMaxInput').value = tempMaxSnr;
  tempSnrStops = SNR_DEFAULTS.map(s => ({ snr: s.snr, rgb: [...s.rgb] }));
  renderSnrColorList();
});

document.getElementById('snrCancel').addEventListener('click', () => {
  document.getElementById('snrOverlay').classList.remove('show');
});

document.getElementById('snrApply').addEventListener('click', () => {
  snrStops = tempSnrStops.map(s => ({ snr: s.snr, rgb: [...s.rgb] }));
  snrMax = tempMaxSnr;
  document.getElementById('snrOverlay').classList.remove('show');
  if (latestData) updateScene(latestData);
});

document.getElementById('snrOverlay').addEventListener('click', (e) => {
  if (e.target === e.currentTarget) {
    document.getElementById('snrOverlay').classList.remove('show');
  }
});

// 导出 SNR 配置
document.getElementById('snrExport').addEventListener('click', () => {
  const conf = {
    maxSnr: tempMaxSnr,
    stops: tempSnrStops.map(s => ({ snr: s.snr, rgb: s.rgb.map(v => Math.round(v * 255)) })),
  };
  const json = JSON.stringify(conf, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'snr_colors.json';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
});

// 导入 SNR 配置
document.getElementById('snrImport').addEventListener('click', () => {
  document.getElementById('snrFileInput').click();
});
document.getElementById('snrFileInput').addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    try {
      const raw = JSON.parse(ev.target.result);
      // 兼容新旧格式
      let stops, maxSnr = tempMaxSnr;
      if (Array.isArray(raw)) {
        stops = raw;  // 旧格式：纯数组
      } else if (raw.stops && Array.isArray(raw.stops)) {
        stops = raw.stops;
        if (typeof raw.maxSnr === 'number') maxSnr = raw.maxSnr;
      } else {
        alert('配置文件格式无效');
        return;
      }
      if (stops.length < 5) {
        alert('配置文件无效：至少需要 5 段颜色配置');
        return;
      }
      tempSnrStops = stops.map(c => ({
        snr: typeof c.snr === 'number' ? c.snr : 0,
        rgb: (Array.isArray(c.rgb) && c.rgb.length === 3)
          ? c.rgb.map(v => Math.max(0, Math.min(1, v / 255)))
          : [0, 0.5, 1],
      }));
      tempSnrCount = tempSnrStops.length;
      tempMaxSnr = maxSnr;
      document.getElementById('snrCount').value = tempSnrCount;
      document.getElementById('snrMaxInput').value = tempMaxSnr;
      renderSnrColorList();
    } catch {
      alert('配置文件格式错误');
    }
  };
  reader.readAsText(file);
  e.target.value = '';  // 清空以允许重复选择同一文件
});
// 右上角"重连实时数据"按钮：任何时候点它都立即重建连接
document.getElementById('reconnectBtn').addEventListener('click', reconnectNow);

// 地面颜色
let gridMainColor = '#3a5060';
let gridSubColor = '#13293a';

// 高度轴切换：选中的轴竖直朝上，其余两轴水平；只显示对应的地面网格
function applyHeightAxis() {
  if (!sceneGroup) return;
  if (heightAxis === 'x') {
    sceneGroup.rotation.set(0, 0, Math.PI / 2);        // X → +Y 朝上
  } else if (heightAxis === 'y') {
    sceneGroup.rotation.set(0, 0, 0);                  // Y 朝上（默认）
  } else { // 'z'
    sceneGroup.rotation.set(-Math.PI / 2, 0, 0);       // Z → +Y 朝上
  }
  updateGridVisibility();
}
function updateGridVisibility() {
  // 地面 = 与高度轴垂直的平面网格；只显示对应的地面网格与底色平面
  if (gridObject) gridObject.visible = (heightAxis === 'y');   // XZ 网格
  if (yGridObject) yGridObject.visible = (heightAxis === 'z'); // XY 网格
  if (yzGridObject) yzGridObject.visible = (heightAxis === 'x');// YZ 网格
  if (groundPlane) groundPlane.visible = (heightAxis === 'y'); // XZ 底色
  if (planeXY) planeXY.visible = (heightAxis === 'z');         // XY 底色
  if (planeYZ) planeYZ.visible = (heightAxis === 'x');         // YZ 底色
}

function rebuildGrid() {
  if (gridObject) { sceneGroup.remove(gridObject); disposeObject(gridObject); }
  const divs = Math.max(1, Math.round(40 / gridSpacing));
  gridObject = new THREE.GridHelper(40, divs, gridMainColor, gridSubColor);
  sceneGroup.add(gridObject);
  updateGridVisibility();
}
function rebuildYGrid() {
  if (yGridObject) { sceneGroup.remove(yGridObject); disposeObject(yGridObject); }
  const divs = Math.max(1, Math.round(40 / yGridSpacing));
  yGridObject = new THREE.GridHelper(40, divs, gridMainColor, gridSubColor);
  yGridObject.rotation.x = Math.PI / 2;
  sceneGroup.add(yGridObject);
  updateGridVisibility();
}
function rebuildYZGrid() {
  if (yzGridObject) { sceneGroup.remove(yzGridObject); disposeObject(yzGridObject); }
  const divs = Math.max(1, Math.round(40 / yzGridSpacing));
  yzGridObject = new THREE.GridHelper(40, divs, gridMainColor, gridSubColor);
  yzGridObject.rotation.z = Math.PI / 2;
  sceneGroup.add(yzGridObject);
  updateGridVisibility();
}
// 实时将地面主/辅色应用到三个网格（不重建）
function setGridColors() {
  [gridObject, yGridObject, yzGridObject].forEach((g) => {
    if (!g) return;
    g.material.color.set(gridMainColor);
    if (g.material.color2) g.material.color2.set(gridSubColor);
  });
}
document.getElementById('gridColorMain').addEventListener('input', (e) => {
  gridMainColor = e.target.value;
  setGridColors();
});
document.getElementById('gridColorSub').addEventListener('input', (e) => {
  gridSubColor = e.target.value;
  setGridColors();
});
document.getElementById('planeColor').addEventListener('input', (e) => {
  // 三个地面底色平面共享材质，一次设置全部生效
  [groundPlane, planeXY, planeYZ].forEach((p) => { if (p) p.material.color.set(e.target.value); });
});
document.getElementById('gridSpacing').addEventListener('input', (e) => {
  let v = parseFloat(e.target.value);
  if (isNaN(v) || v < 0.05) {v = 0.05; e.target.value = '0.05';}
  gridSpacing = v;
  rebuildGrid();
});
document.getElementById('yGridSpacing').addEventListener('input', (e) => {
  let v = parseFloat(e.target.value);
  if (isNaN(v) || v < 0.05) {v = 0.05; e.target.value = '0.05';}
  yGridSpacing = v;
  rebuildYGrid();
});
document.getElementById('yzGridSpacing').addEventListener('input', (e) => {
  let v = parseFloat(e.target.value);
  if (isNaN(v) || v < 0.05) {v = 0.05; e.target.value = '0.05';}
  yzGridSpacing = v;
  rebuildYZGrid();
});

// 高度轴单选：切换时自动旋转场景并使对应地面网格显示、其余网格隐藏
['x', 'y', 'z'].forEach((axis) => {
  document.getElementById('heightAxis' + axis.toUpperCase()).addEventListener('change', (e) => {
    if (!e.target.checked) return;
    heightAxis = axis;
    applyHeightAxis();
  });
});

// 聚类控制（滑条与输入框双向联动）
document.getElementById('showCluster').addEventListener('change', (e) => {
  showCluster = e.target.checked;
  if (latestData) updateScene(latestData);
});
document.getElementById('clusterEps').addEventListener('input', (e) => {
  clusterEps = parseFloat(e.target.value);
  document.getElementById('clusterEpsNum').value = clusterEps;
  if (showCluster && latestData) updateScene(latestData);
});
document.getElementById('clusterEpsNum').addEventListener('input', (e) => {
  let v = parseFloat(e.target.value);
  if (isNaN(v)) return;
  v = Math.min(5, Math.max(0.1, v));   // 限幅到滑条范围
  clusterEps = v;
  document.getElementById('clusterEps').value = v;
  document.getElementById('clusterEpsNum').value = v;
  if (showCluster && latestData) updateScene(latestData);
});
document.getElementById('clusterMinPts').addEventListener('input', (e) => {
  clusterMinPts = parseInt(e.target.value);
  document.getElementById('clusterMinPtsNum').value = clusterMinPts;
  if (showCluster && latestData) updateScene(latestData);
});
document.getElementById('clusterMinPtsNum').addEventListener('input', (e) => {
  let v = parseInt(e.target.value);
  if (isNaN(v)) return;
  v = Math.min(30, Math.max(3, v));    // 限幅到滑条范围
  clusterMinPts = v;
  document.getElementById('clusterMinPts').value = v;
  document.getElementById('clusterMinPtsNum').value = v;
  if (showCluster && latestData) updateScene(latestData);
});
document.getElementById('clusterColor').addEventListener('input', (e) => {
  clusterColor = parseInt(e.target.value.slice(1), 16);
  if (showCluster && latestData) updateScene(latestData);
});
document.getElementById('clusterSnr').addEventListener('input', (e) => {
  clusterSnrMin = parseFloat(e.target.value);
  document.getElementById('clusterSnrNum').value = clusterSnrMin;
  if (showCluster && latestData) updateScene(latestData);
});
document.getElementById('clusterSnrNum').addEventListener('input', (e) => {
  let v = parseFloat(e.target.value);
  if (isNaN(v)) return;
  v = Math.min(60, Math.max(0, v));    // 限幅到滑条范围
  clusterSnrMin = v;
  document.getElementById('clusterSnr').value = v;
  document.getElementById('clusterSnrNum').value = v;
  if (showCluster && latestData) updateScene(latestData);
});

// 通用 Three.js 对象递归 dispose（兼容 r128 无顶层 dispose 的类）
function disposeObject(obj) {
  obj.traverse((child) => {
    if (child.geometry) child.geometry.dispose();
    if (child.material) {
      if (Array.isArray(child.material)) {
        child.material.forEach(m => m.dispose());
      } else {
        child.material.dispose();
      }
    }
  });
}
function setStatus(text) {
  document.getElementById('status').textContent = text;
}

function toRad(v) {
  if (!config || config.angle_unit === 'deg') return v * Math.PI / 180;
  return v;
}

function parseVelocity(p, x, y, z) {
  if (Array.isArray(p.velocity) && p.velocity.length === 3) {
    const vx = p.velocity[0] || 0;
    const vy = p.velocity[1] || 0;
    const vz = p.velocity[2] || 0;
    return {vx, vy, vz, speed: Math.sqrt(vx * vx + vy * vy + vz * vz)};
  }
  if ('velocity_x' in p || 'velocity_y' in p || 'velocity_z' in p) {
    const vx = p.velocity_x || 0;
    const vy = p.velocity_y || 0;
    const vz = p.velocity_z || 0;
    return {vx, vy, vz, speed: Math.sqrt(vx * vx + vy * vy + vz * vz)};
  }
  const len = Math.sqrt(x * x + y * y + z * z) || 1;
  const v = p.velocity || 0;
  return {
    vx: v * x / len,
    vy: v * y / len,
    vz: v * z / len,
    speed: Math.abs(v),
  };
}

function parsePoints(data) {
  const list = data.Point || [];
  return list.map((p) => {
    let x, y, z;
    if (config && config.coord_mode === 'spherical') {
      const r = p.range_or_x || 0;
      const az = toRad(p.azimath_or_y || 0);
      const el = toRad(p.elevation_or_z || 0);
      x = r * Math.cos(el) * Math.cos(az);
      z = r * Math.cos(el) * Math.sin(az);   // 地面投影在 XZ 平面
      y = r * Math.sin(el);                  // 高度沿 Y 轴
    } else {
      x = p.range_or_x || 0;
      y = p.azimath_or_y || 0;
      z = p.elevation_or_z || 0;
    }
    const vel = parseVelocity(p, x, y, z);
    return {x, y, z, ...vel, snr: p.snr || 0};
  });
}

// DBSCAN 聚类：返回 {clusters: [[idx,...]], noise: [idx,...]}
function dbscan(points, eps, minPts) {
  const n = points.length;
  const visited = new Array(n).fill(false);
  const noise = [];
  const clusters = [];

  // 邻域搜索（基于空间位置）
  function regionQuery(pidx) {
    const neighbors = [];
    const p = points[pidx];
    for (let i = 0; i < n; i++) {
      const q = points[i];
      const dx = p.x - q.x, dy = p.y - q.y, dz = p.z - q.z;
      if (Math.sqrt(dx*dx + dy*dy + dz*dz) <= eps) neighbors.push(i);
    }
    return neighbors;
  }

  for (let i = 0; i < n; i++) {
    if (visited[i]) continue;
    visited[i] = true;
    const neighbors = regionQuery(i);
    if (neighbors.length < minPts) {
      noise.push(i);
    } else {
      const cluster = [i];
      const seeds = [...neighbors];
      for (let s = 0; s < seeds.length; s++) {
        const j = seeds[s];
        if (noise.includes(j)) {
          // 之前误判为噪点，收回
          noise.splice(noise.indexOf(j), 1);
          cluster.push(j);
        }
        if (visited[j]) continue;
        visited[j] = true;
        const nbrs2 = regionQuery(j);
        if (nbrs2.length >= minPts) {
          for (const k of nbrs2) {
            if (!seeds.includes(k) && !visited.some((v, idx) => idx === k && v)) {
              seeds.push(k);
            }
          }
        }
        if (!cluster.includes(j)) cluster.push(j);
      }
      clusters.push(cluster);
    }
  }
  return { clusters, noise };
}

function snrColor(snr, min, max) {
  if (!showSnr) return new THREE.Color(0x00aaff);
  const stops = snrStops;
  if (stops.length === 0) return new THREE.Color(0x00aaff);
  // 低于第一段阈值 → 用第一个颜色
  if (snr <= stops[0].snr) return new THREE.Color(stops[0].rgb[0], stops[0].rgb[1], stops[0].rgb[2]);
  // 高于最后阈值 → 用最后一个颜色
  if (snr >= stops[stops.length - 1].snr) {
    const last = stops[stops.length - 1];
    return new THREE.Color(last.rgb[0], last.rgb[1], last.rgb[2]);
  }
  // 在中间 → 线性插值
  for (let i = 0; i < stops.length - 1; i++) {
    if (snr >= stops[i].snr && snr <= stops[i + 1].snr) {
      const range = stops[i + 1].snr - stops[i].snr || 1;
      const t = (snr - stops[i].snr) / range;
      const a = stops[i].rgb, b = stops[i + 1].rgb;
      return new THREE.Color(
        a[0] + (b[0] - a[0]) * t,
        a[1] + (b[1] - a[1]) * t,
        a[2] + (b[2] - a[2]) * t,
      );
    }
  }
  return new THREE.Color(0x00aaff);
}

function makeAxisLabel(text, color) {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  canvas.width = 64;
  canvas.height = 64;
  ctx.font = 'bold 40px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = color;
  ctx.fillText(text, 32, 32);
  const texture = new THREE.CanvasTexture(canvas);
  const material = new THREE.SpriteMaterial({map: texture, depthTest: false});
  const sprite = new THREE.Sprite(material);
  sprite.scale.set(0.5, 0.5, 1);
  return sprite;
}

function init() {
  const container = document.getElementById('canvas');
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0a0f14);
  scene.fog = new THREE.Fog(0x0a0f14, 20, 200);

  // 场景内容容器：支持整体旋转（"Y 轴放地面"时绕 X 轴 -90°）
  sceneGroup = new THREE.Group();
  scene.add(sceneGroup);

  camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.01, 2000);
  // 默认视角：位置 (4.14, 4.16, 6.15)，距原点约 8.5m
  camera.position.set(4.14, 4.16, 6.15);
  camera.lookAt(lookAtTarget);
  cameraSpherical = new THREE.Spherical().setFromVector3(camera.position);
  cameraSpherical.radius = 8.5;   /* 显式限定默认视角距离 */
  cameraRadiusSet = true;

  renderer = new THREE.WebGLRenderer({antialias: true});
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  container.appendChild(renderer.domElement);

  const ambient = new THREE.AmbientLight(0xffffff, 0.5);
  scene.add(ambient);
  const dir = new THREE.DirectionalLight(0xffffff, 0.8);
  dir.position.set(10, 20, 10);
  scene.add(dir);

  const initDivs = Math.max(1, Math.round(40 / gridSpacing));
  gridObject = new THREE.GridHelper(40, initDivs, 0x3a5060, 0x13293a);
  sceneGroup.add(gridObject);

  // 三个地面底色平面（共享材质，颜色统一由"地面底色"控制）
  // groundPlane=XZ(Y高度地面)  planeXY=XY(Z高度地面)  planeYZ=YZ(X高度地面)
  // PlaneGeometry 默认在 XY 平面（法线 +Z），按高度轴旋转后对应平面变为水平地面
  const planeGeom = new THREE.PlaneGeometry(40, 40);
  const planeMat = new THREE.MeshLambertMaterial({
    color: 0x353940, side: THREE.DoubleSide, transparent: true, opacity: 0.6, depthWrite: false,
  });
  groundPlane = new THREE.Mesh(planeGeom, planeMat);
  groundPlane.rotation.x = -Math.PI / 2;   // → XZ 水平面
  groundPlane.position.y = 0.001;
  sceneGroup.add(groundPlane);

  planeXY = new THREE.Mesh(planeGeom, planeMat);
  planeXY.position.z = 0.001;               // 保持 XY 竖直面，Z 高度时变水平
  sceneGroup.add(planeXY);

  planeYZ = new THREE.Mesh(planeGeom, planeMat);
  planeYZ.rotation.y = Math.PI / 2;         // → YZ 竖直面，X 高度时变水平
  planeYZ.position.x = 0.001;
  sceneGroup.add(planeYZ);

  // XY 网格（仅在 Z 轴高度时作为地面显示）
  const yDivs = Math.max(1, Math.round(40 / yGridSpacing));
  yGridObject = new THREE.GridHelper(40, yDivs, gridMainColor, gridSubColor);
  yGridObject.rotation.x = Math.PI / 2;
  sceneGroup.add(yGridObject);

  // YZ 网格（仅在 X 轴高度时作为地面显示）
  const yzDivs = Math.max(1, Math.round(40 / yzGridSpacing));
  yzGridObject = new THREE.GridHelper(40, yzDivs, gridMainColor, gridSubColor);
  yzGridObject.rotation.z = Math.PI / 2;
  sceneGroup.add(yzGridObject);
  sceneGroup.add(new THREE.AxesHelper(3));

  pointsGroup = new THREE.Group();
  arrowsGroup = new THREE.Group();
  clusterGroup = new THREE.Group();
  sceneGroup.add(pointsGroup);
  sceneGroup.add(arrowsGroup);
  sceneGroup.add(clusterGroup);

  axisLabelsGroup = new THREE.Group();
  const xLabel = makeAxisLabel('X', '#ff0000');
  xLabel.position.set(3.2, 0, 0);
  const yLabel = makeAxisLabel('Y', '#00ff00');
  yLabel.position.set(0, 3.2, 0);
  const zLabel = makeAxisLabel('Z', '#0000ff');
  zLabel.position.set(0, 0, 3.2);
  axisLabelsGroup.add(xLabel, yLabel, zLabel);
  axisLabelsGroup.visible = showAxisLabels;
  sceneGroup.add(axisLabelsGroup);

  applyHeightAxis();  // 按当前高度轴设置场景朝向与地面网格显示
  setupOrbit(renderer.domElement);
  window.addEventListener('resize', onResize);
  domListeners.push([window, 'resize', onResize]);
  animate();
}

function snapAngle(value, snapPoints) {
  // 找最近的吸附点，在范围内则柔和拉近
  let best = null;
  let bestDist = Infinity;
  for (const pt of snapPoints) {
    const d = Math.abs(value - pt);
    if (d < bestDist) {bestDist = d; best = pt;}
  }
  if (bestDist < SNAP_RANGE) {
    const t = 1 - bestDist / SNAP_RANGE;          // 0(边缘) ~ 1(正中)
    const pull = SNAP_STRENGTH * t * t;            // 越近吸力越大（平方曲线）
    return value + (best - value) * pull;
  }
  return value;
}

function setupOrbit(dom) {
  let rotating = false;
  let panning = false;
  let lastX = 0, lastY = 0;

  const onMouseDown = (e) => {
    if (e.button === 0) {        // 左键 → 旋转
      rotating = true;
    } else if (e.button === 1) { // 中键 → 平移
      e.preventDefault();
      panning = true;
    }
    lastX = e.clientX;
    lastY = e.clientY;
  };
  const onAuxClick = (e) => e.preventDefault();
  const onMouseUp = () => {
    rotating = false;
    panning = false;
  };
  const onMouseMove = (e) => {
    if (!rotating && !panning) return;
    const dx = e.clientX - lastX;
    const dy = e.clientY - lastY;
    lastX = e.clientX;
    lastY = e.clientY;

    if (rotating) {
      const flip = cameraSpherical.phi < Math.PI / 2 ? -1 : 1;  // theta 半球统一
      cameraSpherical.theta -= dx * 0.008 * flip;
      cameraSpherical.phi -= dy * 0.008;

      // phi 吸附：0(PI) = XZ顶/底视图, PI/2 = 侧视图
      cameraSpherical.phi = snapAngle(cameraSpherical.phi, [0, Math.PI / 2, Math.PI]);
      cameraSpherical.phi = Math.max(0.001, Math.min(Math.PI - 0.001, cameraSpherical.phi));

      // theta 吸附：仅在接近侧视图(phi≈PI/2)时生效
      // 0/PI → XY平面正视, PI/2/3PI/2 → YZ平面侧视
      if (Math.abs(cameraSpherical.phi - Math.PI / 2) < SNAP_RANGE) {
        cameraSpherical.theta = snapAngle(cameraSpherical.theta, [0, Math.PI / 2, Math.PI, 3 * Math.PI / 2]);
      }

      camera.position.setFromSpherical(cameraSpherical);
      camera.lookAt(lookAtTarget);
    } else if (panning) {
      const dist = camera.position.distanceTo(lookAtTarget);
      const forward = new THREE.Vector3().copy(lookAtTarget).sub(camera.position).normalize();
      const right = new THREE.Vector3().crossVectors(forward, camera.up).normalize();
      const up = new THREE.Vector3().crossVectors(right, forward).normalize();
      const factor = dist * 0.002;
      const offset = new THREE.Vector3()
        .addScaledVector(right, -dx * factor)
        .addScaledVector(up, dy * factor);
      lookAtTarget.add(offset);
      camera.position.add(offset);
    }
  };
  const onWheel = (e) => {
    cameraSpherical.radius *= e.deltaY > 0 ? 1.08 : 0.92;
    cameraSpherical.radius = Math.max(0.1, cameraSpherical.radius);
    camera.position.setFromSpherical(cameraSpherical);
    camera.lookAt(lookAtTarget);
  };

  dom.addEventListener('mousedown', onMouseDown);
  dom.addEventListener('auxclick', onAuxClick);
  dom.addEventListener('mousemove', onMouseMove);
  dom.addEventListener('wheel', onWheel);
  window.addEventListener('mouseup', onMouseUp);
  // 注册到全局，cleanup() 时移除，防止监听器滞留
  domListeners.push(
    [dom, 'mousedown', onMouseDown],
    [dom, 'auxclick', onAuxClick],
    [dom, 'mousemove', onMouseMove],
    [dom, 'wheel', onWheel],
    [window, 'mouseup', onMouseUp]
  );
}

function onResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}

let animating = true;

function animate() {
  if (!animating) return;
  requestAnimationFrame(animate);
  renderer.render(scene, camera);
  document.getElementById('camDist').textContent = cameraSpherical.radius.toFixed(2);
  const p = camera.position;
  document.getElementById('camPos').textContent = `(${p.x.toFixed(2)}, ${p.y.toFixed(2)}, ${p.z.toFixed(2)})`;
  const c = lookAtTarget;
  document.getElementById('centerPos').textContent = `(${c.x.toFixed(2)}, ${c.y.toFixed(2)}, ${c.z.toFixed(2)})`;
}

function updateScene(data) {
  const pts = parsePoints(data);
  document.getElementById('count').textContent = pts.length;
  isRealData = true;
  setStatus('接收数据中');
  updateModeUI();

  // 清除旧箭头（递归 dispose 内部几何体和材质）
  while (arrowsGroup.children.length) {
    const child = arrowsGroup.children[0];
    arrowsGroup.remove(child);
    disposeObject(child);
  }

  if (pts.length === 0) {
    if (pointsObject) {
      pointsObject.geometry.dispose();
      pointsGroup.remove(pointsObject);
      pointsObject = null;
    }
    return;
  }

  // 复用或重建 Points 对象
  if (!pointsObject || pointsObject.geometry.attributes.position.count !== pts.length) {
    if (pointsObject) {
      pointsObject.geometry.dispose();
      pointsGroup.remove(pointsObject);
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(pts.length * 3), 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(new Float32Array(pts.length * 3), 3));
    pointsObject = new THREE.Points(geometry, pointsMaterial);
    pointsGroup.add(pointsObject);
  }

  const posAttr = pointsObject.geometry.attributes.position;
  const colAttr = pointsObject.geometry.attributes.color;
  const c = new THREE.Color();
  pts.forEach((p, i) => {
    posAttr.setXYZ(i, p.x, p.y, p.z);
    c.copy(snrColor(p.snr));
    colAttr.setXYZ(i, c.r, c.g, c.b);
  });
  posAttr.needsUpdate = true;
  colAttr.needsUpdate = true;

  if (showArrows) {
    pts.forEach((p) => {
      if (p.speed === 0) return;
      const dir = new THREE.Vector3(p.vx, p.vy, p.vz).normalize();
      const len = Math.max(0.02, p.speed * velocityScale);
      const headLen = Math.min(len * 0.3, 0.15);
      const headWidth = headLen * 0.6;
      const arrow = new THREE.ArrowHelper(dir, new THREE.Vector3(p.x, p.y, p.z), len, 0xffff00, headLen, headWidth);
      arrowsGroup.add(arrow);
    });
  }

  // 聚类
  while (clusterGroup.children.length) {
    const child = clusterGroup.children[0];
    clusterGroup.remove(child);
    disposeObject(child);
  }
  if (showCluster && pts.length > 0) {
    // SNR 阈值过滤：低于阈值的点视为噪点，不参与聚类
    const snrFiltered = (clusterSnrMin > 0) ? pts.filter(p => p.snr >= clusterSnrMin) : pts;
    if (snrFiltered.length === 0) {
      // 全部被 SNR 阈值滤掉：清空点云显示
      if (pointsObject) {
        pointsObject.geometry.dispose();
        pointsGroup.remove(pointsObject);
        pointsObject = null;
      }
      return;
    }
    const result = dbscan(snrFiltered, clusterEps, clusterMinPts);
    // 过滤噪点：仅保留属于某个聚类的点
    const clustered = new Set();
    result.clusters.forEach(c => c.forEach(idx => clustered.add(idx)));
    const filteredPts = snrFiltered.filter((_, i) => clustered.has(i));
    if (filteredPts.length === 0) {
      // 没有形成任何聚类：不显示本帧（清空点云，避免残留上一帧）
      if (pointsObject) {
        pointsObject.geometry.dispose();
        pointsGroup.remove(pointsObject);
        pointsObject = null;
      }
      return;
    }
    // 为每个聚类画包围盒（统一颜色）
    result.clusters.forEach((cluster) => {
      const box = new THREE.Box3();
      cluster.forEach(idx => box.expandByPoint(
        new THREE.Vector3(snrFiltered[idx].x, snrFiltered[idx].y, snrFiltered[idx].z)
      ));
      if (box.isEmpty()) return;
      const helper = new THREE.Box3Helper(box, clusterColor);
      clusterGroup.add(helper);
    });
    // 用过滤后的点云替换显示
    if (filteredPts.length > 0) {
      // 直接用过滤后点重填几何体
      if (!pointsObject || pointsObject.geometry.attributes.position.count !== filteredPts.length) {
        if (pointsObject) {
          pointsObject.geometry.dispose();
          pointsGroup.remove(pointsObject);
        }
        const geom = new THREE.BufferGeometry();
        geom.setAttribute('position', new THREE.BufferAttribute(new Float32Array(filteredPts.length * 3), 3));
        geom.setAttribute('color', new THREE.BufferAttribute(new Float32Array(filteredPts.length * 3), 3));
        pointsObject = new THREE.Points(geom, pointsMaterial);
        pointsGroup.add(pointsObject);
      }
      const pa = pointsObject.geometry.attributes.position;
      const ca = pointsObject.geometry.attributes.color;
      const cc = new THREE.Color();
      filteredPts.forEach((p, i) => {
        pa.setXYZ(i, p.x, p.y, p.z);
        cc.copy(snrColor(p.snr));
        ca.setXYZ(i, cc.r, cc.g, cc.b);
      });
      pa.needsUpdate = true;
      ca.needsUpdate = true;
    }
  }
}

document.getElementById('resetCenter').addEventListener('click', () => {
  const offset = new THREE.Vector3().copy(lookAtTarget).multiplyScalar(-1);
  camera.position.add(offset);
  lookAtTarget.set(0, 0, 0);
  camera.lookAt(lookAtTarget);
  cameraSpherical.setFromVector3(camera.position);
});

// 页面卸载时释放 WebGL + 网络资源
let cleaned = false;
function cleanup() {
  if (cleaned) return;
  cleaned = true;
  animating = false;
  // 移除动态注册的事件监听器（Orbit 交互、resize）
  domListeners.forEach(([target, type, fn]) => {
    try { target.removeEventListener(type, fn); } catch (_) {}
  });
  domListeners.length = 0;
  if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }
  try { if (socket) { socket.close(); socket = null; } } catch (_) {}
  try {
    if (renderer) {
      renderer.forceContextLoss();
      renderer.dispose();
      const canvas = renderer.domElement;
      if (canvas && canvas.parentNode) canvas.parentNode.removeChild(canvas);
      renderer = null;
    }
  } catch (_) {}
  try {
    if (scene) {
      scene.traverse((obj) => {
        try { if (obj.geometry) obj.geometry.dispose(); } catch (_) {}
        try {
          if (obj.material) {
            if (Array.isArray(obj.material)) {
              obj.material.forEach(m => { try { if (m.map) m.map.dispose(); } catch (_) {}; try { m.dispose(); } catch (_) {} });
            } else {
              try { if (obj.material.map) obj.material.map.dispose(); } catch (_) {}
              try { obj.material.dispose(); } catch (_) {}
            }
          }
        } catch (_) {}
      });
    }
  } catch (_) {}
  try { if (pointsMaterial.map) pointsMaterial.map.dispose(); } catch (_) {}
  try { pointsMaterial.dispose(); } catch (_) {}
}
window.addEventListener('beforeunload', cleanup);
window.addEventListener('pagehide', cleanup);

init();
setupSocket();
