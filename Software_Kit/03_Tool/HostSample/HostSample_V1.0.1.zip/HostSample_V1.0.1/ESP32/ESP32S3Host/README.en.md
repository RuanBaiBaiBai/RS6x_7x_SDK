# ESP32-ESP32S3Host

[English](./README.en.md) | [中文](./README.md)

This tool consists mainly of source code and documentation. It implements data acquisition from the AS2525 radar via 1‑wire SPI/UART/I2C on the ESP32S3, command transmission to the radar, and firmware updates. It also supports data retransmission and automatic reassembly of partial message‑ID data (0xC1, 0xC2, 0xC3). The tool provides a complete ESP32S3 HostDriver component based on ESP‑IDF 5.5.4, along with AI‑generated SKILLs to facilitate porting to other platforms.

This README.md describes how to use/port the official HostDriver component, the sample application content, implementation concepts, and the visualisation interface.

## I. Directory Overview

* res\                                                               Resources used by this README.md

* ESP32S3_Project\                                       Example sample
  
  * img\                                                       Folder for slave firmware images, which will be packed into the host firmware
  
  * main\                                                     Application code folder
  
  * tools\                                                     Web resource conversion tools
  
  * web\                                                      Web resource folder
  
  * assets.h                                                 Converted web resources
  
  * CMakeLists.txt                                      ESP‑IDF project configuration file
  
  * partitions.csv                                        Firmware partition table
  
  * sdkconfig.defaults                               Default configuration
  
  * ......                                                         Other files

* host_driver\                           Official HostDriver component (based on ESP‑IDF 5.5.4)

* SKILL\                                                            SKILL
  
  * SKILL_HostDriver_Porting\                 SKILL used when porting the HostDriver component

* README.md                                                This file

## II. Installation and Porting

### 2.1 Install ESP‑IDF 5.5.4

The Python version used in the test environment is 3.11.2. If you encounter issues during use, try changing the system Python version to 3.11.2.

It is recommended to install ESP‑IDF in VSCode.

### 2.2 Obtain the Official HostDriver Component

The official HostDriver component is located in the `host_driver` folder.

### 2.3 Porting the HostDriver Component (for non‑ESP32S3 platforms)

#### 2.3.1 AI‑Assisted Porting

If you are using a non‑ESP32S3 platform and the official HostDriver component does not meet your functional requirements, you can provide the `host_driver` folder and the `SKILL` folder to an AI, describe the target platform, and let the AI perform the porting.

#### 2.3.2 Manual Porting

This section gives only a brief description. For detailed porting instructions, please refer to Chapter 5 of `Software_Kit/01_Document/CN/《RS6x_7x_HIF_参考手册》`.

##### 2.3.2.1 Files to Port

To port the HostDriver component to another platform that supports ESP‑IDF, the following files need to be ported:

```
<host_driver/porting/esp32>:
    hal_os.c
    hal_io.c
    port_log.h
    hal_store.c
    hal_com_spi.c
    hal_com_uart.c
    hal_com_i2c.c
```

##### 2.3.2.2 hal_os.c

Provides interfaces for entering/exiting critical sections, getting timestamps, allocating/freeing memory, threading, semaphores, and delaying. Note that `host_os_sem_take` and `host_os_sem_give` must support both interrupt context and thread context.

##### 2.3.2.3 hal_io.c

Special attention: do not add a daemon thread for IO interrupts; instead, directly call the registered callback function at interrupt time.

##### 2.3.2.4 port_log.h

You can simply define an alias `host_log_print` for `printf`.

##### 2.3.2.5 hal_store.c

The `offset` parameter of the `host_store_read` interface is an offset relative to the firmware base address.

##### 2.3.2.6 hal_com_spi.c

No special notes.

##### 2.3.2.7 hal_com_uart.c

Pay attention to whether scheduling may cause hardware FIFO overflows. If so, you need to maintain an internal buffer in `hal_com_uart.c`: write data directly to the buffer when data arrives, and read from the buffer when the external `host_uart_read` interface is called.

Ensure that concurrent calls to `host_uart_read` do not read the same data twice.

##### 2.3.2.8 hal_com_i2c.c

Use synchronous transactions for data transfer.

### 2.4 Check the Radar Base Board Hardware

#### 2.4.1 Solder 0Ω Resistors

According to the QA section "How to connect the radar to other embedded hardware for development" in `Software_Kit/01_Document/CN/《RS6x_7x_毫米波雷达开发_快速入门》`, solder the 0Ω resistors to connect the radar module's `PA0–PA5` pins to the `PA0–PA5` header pins on the base board.

#### 2.4.2 Solder a Header onto the Header Holes

To facilitate connecting signals via Dupont wires.

#### 2.4.3 Verify DIP Switch (FUNC SEL) Status

The CH347 bridge chip on the development board shares `PA0–PA6` and `PB0–PB1` with the header. When using the header to communicate with other devices, toggle the DIP switch to disconnect the radar module from the bridge chip.

If using I2C communication, turn on the corresponding DIP switch for I2C to connect it to the bridge chip, using the bridge chip's pull‑up resistors as the I2C pull‑ups.

The picture below shows an example: the switches for LED and IIC are turned on.

![](res/雷达底板拨码示例.jpg)

#### 2.4.4 Connect ESP32S3 and Radar Base Board

| ESP32S3 | Radar Base Board | Function (Radar) |
| ------- | ---------------- | ---------------- |
| 18      | PB0              | UART_TX          |
| 17      | PB1              | UART_RX          |
| 10      | PA0              | SPI_CS           |
| 12      | PA1              | SPI_CLK          |
| 11      | PA2              | SPI_MOSI         |
| 13      | PA3              | SPI_MISO         |
| 5       | PA4              | I2C_SDA          |
| 4       | PA5              | I2C_SCL          |
| 7       | PA6              | NOTIFY           |
| 8       | PB0              | UPD              |
| 9       | NRST             | RST              |
| GND     | GND              | GND              |

### 2.5 Create a Minimal Project

#### 2.5.1 Project Configuration

It is recommended to use the `ESP‑IDF Templates → sample_project` template.

After creating the project, modify the `CMakeLists.txt` file in the project root directory and add:

```
set(EXTRA_COMPONENT_DIRS "${CMAKE_CURRENT_LIST_DIR}/../host_driver")
```

where `"../host_driver"` is the relative path from this file to the HostDriver component. This line must be placed **before** `include(project.cmake)`.

In `main/CMakeLists.txt`, change:

```
idf_component_register(SRCS "main.c"
                    INCLUDE_DIRS ".")
```

to:

```
idf_component_register(SRCS "main.c"
                    INCLUDE_DIRS "."
                    PRIV_REQUIRES host_driver)
```

In `main/main.c`, add the following includes:

```
#include "host_driver.h"
#include "host_mmw_api.h"
```

After completing the above steps, you can build the project to verify that the component has been added successfully.

#### 2.5.2 Using the HostDriver Component

Example code for using the HostDriver component:

```
#include <stdio.h>
#include "host_driver.h"
#include "host_mmw_api.h"

static DEV_HANDLE s_dev = DEV_HANDLE_INVALID;

static void app_data_handle(
    uint32_t msg_id,
    uint8_t *data,
    uint32_t data_len,
    void *cb_arg
)
{
    if (msg_id == 0xC3) {
        ;
    } else if (msg_id == 0xC6) {
        ;
    } else if (msg_id == 0xFE) {
        ;
    } else if (msg_id == 0xFF) {
        HOST_LOG_INF("dev(%p) startup\n", cb_arg);
    }
}

void app_main(void)
{
    DevHw_t hw_cfg;
    HifCfg_t hif_cfg;

    Host_Driver_Init();
    DevHw_Set_DefaultParam(&hw_cfg,
                           LLC_BUS_TYPE_SPI,
                           LLC_BUS_PARAM_SPI,
                           0, 8000000, 8, 9, 7, 0);
    host_os_memset(&hif_cfg, 0, sizeof(hif_cfg));
    Host_Device_Regist(&s_dev, &hw_cfg, &hif_cfg);
    Mmw_C3_Objects_Handle_Set(s_dev, app_data_handle, s_dev);
    Mmw_C6_GeneralData_Handle_Set(dev, app_data_handle, dev);
    Mmw_FE_Heartbeat_Handle_Set(dev, app_data_handle, dev);
    Mmw_FF_Startup_Handle_Set(dev, app_data_handle, dev);
    Host_Device_Open(s_dev);
}
```

The above code implements reception of reported data with MsgID = 0xC3, 0xC6, 0xFE, 0xFF.

#### 2.5.3 Using Other Communication Ports

Please refer to section `5.2.1.2 Device Parameter Configuration` in the SDK product package document `Software_Kit/01_Document/CN/《RS6x_7x_HIF_参考手册》`.

### 2.6 Testing and Verification

Taking MRS6240_P2512 as an example: first download the firmware `Software_Kit/04_Image/Tracking_mrs6240_p2512.img` to the radar, then compile, flash, and monitor the ESP32S3. After the ESP32S3 starts, reset the radar. The ESP32S3 will print something like:

```
[I]dev(0x3fcc46a4) startup
```

Here `0x3fcc46a4` is the hexadecimal value returned to `s_dev` after calling `Host_Device_Regist`. This value depends on the board, code, startup sequence, etc. As long as it is non‑zero, it is generally fine.

## III. Example Sample

The provided sample demonstrates point‑cloud data visualisation for Tracking radar firmware. It visualises point‑cloud data as 3D points and allows viewing on a PC within the local network.

### 3.1 Data Acquisition

Data acquisition relies on the official HostDriver ESP‑IDF component. For the ESP32S3, you can use this component directly. Example code (only key parts retained; logging, validation, etc. omitted):

```
static uint32_t dev_startup_count = 0;

static void app_data_handle(
    uint32_t msg_id,
    uint8_t *data,
    uint32_t data_len,
    void *cb_arg
)
{
    static uint32_t heart_beat_count = 0;

    if (msg_id == 0xC1) {
        ;
    } else if (msg_id == 0xC2) {
        ;
    } else if (msg_id == 0xC3) {
        /* 0xC3 point cloud pushed to visualisation server (viz_server internally decides based on push switch) */
        viz_server_handle_data(msg_id, data, data_len);
    } else if (msg_id == 0xC6) {
        ;
    } else if (msg_id == 0xFE) {
        heart_beat_count++;
    } else if (msg_id == 0xFF) {
        dev_startup_count++;
        HOST_LOG_INF("dev(%p) startup times=%lu\n", cb_arg, dev_startup_count);
    }
}

void app_main(void)
{
    DEV_HANDLE dev = DEV_HANDLE_INVALID;
    DevHw_t hw_cfg;
    HifCfg_t hif_cfg;
    int ret;

    Host_Driver_Init();
    DevHw_Set_DefaultParam(&hw_cfg,
                           s_bus_type, s_bus_param,
                           s_bus_id, s_bus_speed,
                           s_dev_upd_io, s_dev_rst_io, s_dev_notify_io,
                           s_dev_param);
    memset(&hif_cfg, 0, sizeof(hif_cfg));
    Host_Device_Regist(&dev, &hw_cfg, &hif_cfg);
    Mmw_C1_CubeData_Handle_Set(dev, app_data_handle, dev);
    Mmw_C2_FFTData_Handle_Set(dev, app_data_handle, dev);
    Mmw_C3_Objects_Handle_Set(dev, app_data_handle, dev);
    Mmw_C6_GeneralData_Handle_Set(dev, app_data_handle, dev);
    Mmw_FE_Heartbeat_Handle_Set(dev, app_data_handle, dev);
    Mmw_FF_Startup_Handle_Set(dev, app_data_handle, dev);
    Host_Device_Open(dev);
}
```

In the sample, the HostDriver component is used to register callbacks for MsgID 0xC1, 0xC2, 0xC3, 0xC6, 0xFE, 0xFF. Inside the callback, 0xC3 data is pushed to the visualisation server, heartbeat (0xFE) counts are recorded, and 0xFF data is converted to print the number of slave startups.

### 3.2 Data Upload

Data upload depends on the `viz_server_handle_data` API. However, before using it, you need to initialise Wi‑Fi, connect to Wi‑Fi, and start the visualisation server:

```
app_wifi_init();  // initialise Wi‑Fi
app_wifi_connect_default(5000);  // connect to default Wi‑Fi, timeout 5s
viz_server_start();  // start visualisation server
```

If no default Wi‑Fi is set or the default fails, you can call the following API to reconnect:

```
int app_wifi_connect(const char *ssid,
                     const char *pass,
                     uint32_t timeout_ms)
```

Parameters: Wi‑Fi SSID, password, timeout in ms.

Now, the data upload API parameters:

```
void viz_server_handle_data(uint32_t msg_id,
                            uint8_t *data,
                            uint32_t data_len)
```

`msg_id` message ID of the reported data, only 0xC3 is supported.

`data` point‑cloud data in the following format:

```
typedef struct {
    union {
        struct {
            uint16_t range;
            uint16_t azimuth;
            uint16_t elevation;
            uint16_t velocity;
            uint16_t snr;
            uint16_t reserved;
        } polar;
        struct {
            uint16_t x;
            uint16_t y;
            uint16_t z;
            uint16_t velocity;
            uint16_t snr;
            uint16_t reserved;
        } coord;
    } type;
} Frame_Point_t;

typedef struct {
    uint32_t frameIdx;
    uint32_t frameLen;
    uint32_t dataOffset;

    uint8_t  type;
    uint8_t  flag;
    uint16_t total_length;

    Frame_Point_t data[0];
} FrameData_C3_t;
```

For SDK 2.1.2, the callback registered via `Mmw_C3_Objects_Handle_Set` receives data in exactly this format.

`data_len` length of `data` in bytes.

### 3.3 Data Visualisation

Visualisation happens automatically once the ESP32S3 successfully connects to Wi‑Fi and receives uploaded point‑cloud data. Open the ESP32S3's IP address in a browser.

### 3.4 Command Transmission

The sample uses the console component to call HostDriver APIs for command transmission. The command group is `mmwcfg`.

### 3.5 Firmware Download

The sample uses the console component together with HostDriver APIs and the SPIFFS component to store radar firmware. The command group is `burn`.

Users can add/remove radar firmware images in the `ESP32S3_Project/img` directory. After compilation, the radar firmware is embedded in the ESP32S3 firmware. For example, placing `a.img` allows updating the slave firmware with the following commands:

```
setdev 0x<device>
burn enter
burn image /spiffs/img/a.img
burn exit
```

The first command sets the target slave device (hexadecimal value) for subsequent console commands. This value is returned by the first parameter of `Host_Device_Regist`.

### 3.6 Switching Communication Ports

You can switch communication ports with:

```
bus <spi/uart/i2c> [speed]
```

For example, to switch to 400K I2C, send `bus i2c 400000`. The change does not take effect immediately; you need to reboot the host (command `reboot`) for the new port to be used.

## 四、Visualisation Interface

### 4.1 Connect to Wi‑Fi

After the ESP32S3 and the PC are connected to the same Wi‑Fi, send a command via the serial terminal to get the ESP32S3 IP address:

```
wifi status
```

The ESP32S3 replies with the IP:

```
wifi: connected, ip=192.168.1.156
```

Here `192.168.1.156` is the IP address. Open it in a browser to view the visualisation interface.

If the ESP32S3 is not connected to Wi‑Fi, it replies:

```
wifi: not connected
```

In that case, send the command to connect:

```
wifi <ssid> <pass>
```

Where `ssid` is the network name and `pass` is the password. Note that most modules support only 2.4 GHz Wi‑Fi.

Example successful connection output:

```
wifi: connecting "PSIC24"I (342726934) wifi:new:<6,0>, old:<6,0>, ap:<255,255>, sta:<6,0>, prof:1, snd_ch_cfg:0x0
I (342726934) wifi:state: init -> auth (0xb0)
I (342726944) wifi:state: auth -> assoc (0x0)
I (342726954) wifi:state: assoc -> run (0x10)
I (342726994) wifi:connected with PSIC24, aid = 8, channel 6, BW20, bssid = 64:bf:6b:4f:a5:ec
I (342726994) wifi:security: WPA2-PSK, phy: bgn, rssi: -36, cipher(pairwise:0x3, group:0x1), pmf:0
I (342727004) wifi:pm start, type: 1

I (342727004) wifi:dp: 1, bi: 102400, li: 3, scale listen interval from 307200 us to 307200 us
I (342727014) wifi:set rx beacon pti, rx_bcn_pti: 0, bcn_timeout: 25000, mt_pti: 0, mt_time: 10000
I (342727024) wifi:AP's beacon interval = 102400 us, DTIM period = 1
....I (342729204) esp_netif_handlers: sta ip: 192.168.1.156, mask: 255.255.255.0, gw: 192.168.1.1

wifi: connected, ip=192.168.1.156 (浏览器访问 http://192.168.1.156/)
```

### 4.2 Visualisation Interface

After opening the IP in a browser, you will see the visualisation interface:

![](res/可视化界面.png)

The points at the axes are the point clouds reported by the radar.

If the radar and ESP32S3 are working normally but the visualisation does not update, click the **Reconnect Real‑time Data** button in the upper right corner to manually synchronise.

## V. Issues and Notes

### 5.1 Why do I often get no data when using UART?

The ESP‑IDF application‑layer APIs are relatively slow. When receiving reported data, hardware FIFO overflows are very likely. You should combine the LL layer with interrupt callbacks to implement real‑time data buffering. That is, data must be stored in the buffer promptly, and the HostDriver's `read` interface reads from that buffer.

### 5.2 Why do I get internal ESP‑IDF overflow errors when using I2C?

When using I2C, you must use synchronous transactions; otherwise, the HostDriver will continuously initiate read operations because it thinks no data was read.

### 5.3 Why does compilation fail?

If you encounter the following error during compilation, delete the `build` directory and rebuild. This is a known occasional issue with ESP‑IDF.

```
C:/esp/v5.5.4/esp-idf/components/esp_lcd/rgb/esp_lcd_panel_rgb.c: In function 'rgb_panel_draw_bitmap':
C:/esp/v5.5.4/esp-idf/components/esp_lcd/rgb/esp_lcd_panel_rgb.c:700:1: internal compiler error: Segmentation fault
  700 | }
      | ^
```
