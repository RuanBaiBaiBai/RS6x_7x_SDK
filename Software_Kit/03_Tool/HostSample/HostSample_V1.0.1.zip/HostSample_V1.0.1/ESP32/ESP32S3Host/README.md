# ESP32-ESP32S3Host

[中文](./README.md) | [English](./README.en.md)

工具主要是源代码及其说明文件，实现了使用 ESP32S3 的 1线SPI/UART/I2C 采集 AS2525 雷达的上报数据、向雷达下发命令、更新雷达固件，同时支持数据重传、部分消息 ID 数据的自动重组（0xC1、0xC2、0xC3）。工具提供了基于 ESP-IDF 5.5.4 的完整的 ESP32S3 HostDriver 组件，并提供 AI 生成的 SKILL 方便对其他平台进行移植。

README.md 文档用于介绍如何使用/移植官方 HostDriver 组件，官方 Sample 内容及实现思路、可视化界面等内容。

## 一、目录概览

* res\                                                                README.md 文件使用的资源

* ESP32S3_Project\                                        示例 Sample
  
  * img\                                                       存放从机固件的文件夹，将被打包进主机固件
  
  * main\                                                     应用代码文件夹
  
  * tools\                                                     网页资源转换工具文件夹
  
  * web\                                                      网页资源文件夹
  
  * assets.h                                                 网页资源转换后的文件
  
  * CMakeLists.txt                                      ESP-IDF 项目的配置文件
  
  * partitions.csv                                        固件分区表
  
  * sdkconfig.defaults                               默认配置
  
  * ......                                                          其它文件

* host_driver\                                                 官方 HostDriver 组件（基于 ESP-IDF 5.5.4）

* SKILL\                                                            SKILL
  
  * SKILL_HostDriver_Porting\                 移植 HostDriver 组件时使用的 SKILL

* README.md                                                本文件

## 二、安装与移植

### 2.1 安装 ESP-IDF 5.5.4

测试场景的系统 Python 版本是 3.11.2 ，如果使用时出现问题，可尝试将系统 Python 版本修改为 3.11.2 。

推荐在 VSCode 中安装 ESP-IDF 。

### 2.2 获取官方 HostDriver 组件

官方 HostDriver 组件位于 host_driver 文件夹内。

### 2.3 移植 HostDriver 组件（非 ESP32S3 平台）

#### 2.3.1 AI 移植

如果使用非 ESP32S3 平台，并且官方 HostDriver 组件无法满足功能要求，可以将 host_driver 文件夹和 SKILL 文件夹提供给 AI ，并描述待移植平台，让 AI 进行移植操作。

#### 2.3.2 手动移植

这里仅做简单描述，详细移植细节请参考 `Software_Kit/01_Document/CN/《RS6x_7x_HIF_参考手册》` 第 5 章。

##### 2.3.2.1 移植文件

如果需要将 HostDriver 组件移植到支持 ESP-IDF 的其它平台上，需要移植下列文件：

```
<host_driver/porting/esp32>:
    hal_os.c
    hal_io.c
    port_log.h
    hal_store.c
    hal_com_spi.c
    hal_com_uart.c
    hal_com_i2c.c
```

##### 2.3.2.2 hal_os.c

提供进出临界区、获取时间戳、申请/释放内存、线程、信号量、延时操作的接口，需要注意的是， `host_os_sem_take` 和 `host_os_sem_give` 要同时支持中断上下文和线程上下文。

##### 2.3.2.3 hal_io.c

移植时应特别注意，不要添加 IO 中断的守护线程，而是直接在中断时回调注册的回调函数。

##### 2.3.2.4 port_log.h

可直接为 `printf` 定义别名 `host_log_print` 。

##### 2.3.2.5 hal_store.c

`host_store_read` 接口的 `offset` 参数是相对于固件基地址的偏移。

##### 2.3.2.6 hal_com_spi.c

无注意事项。

##### 2.3.2.7 hal_com_uart.c

应注意调度是否会导致硬件FIFO溢出，如果会，需要在 hal_com_uart.c 内部维护一个缓冲区，有数据时直接写入缓冲区，外部读取数据则从缓冲区读数。

注意保证 `host_uart_read` 接口被同时调用时，数据不被重复读取。

##### 2.3.2.8 hal_com_i2c.c

应使用同步事务进行数据传输。

### 2.4 检查雷达底板硬件

#### 2.4.1 焊接 0Ω 电阻

根据 `Software_Kit/01_Document/CN/《RS6x_7x_毫米波雷达开发_快速入门》` 的 QA 章节 “如何连接雷达与其它嵌入式硬件进行开发” ，焊接 0Ω 电阻，将雷达模组的 `PA0~PA5` 与底板的 `PA0~PA5` 排针孔相连。

#### 2.4.2 给排针孔焊接排针

方便杜邦线连接信号。

#### 2.4.3 确认拨码开关（FUNC SEL）状态

开发板上的 CH347 转接芯片与排针共享 `PA0~PA6` 及 `PB0~PB1`，在使用排针与其他设备通信时，应拨动拨码开关，断开雷达模组与转接芯片的连接。

如果需要使用I2C进行通讯，应该将I2C对应的拨码开关拨通，将其与转接芯片连接，使用转接芯片的上拉电阻作为I2C的上拉电阻。

下图是拨码示例，图中， LED 和 IIC 对应的拨码开关拨通了。

![](res/雷达底板拨码示例.jpg)

#### 2.4.4 连接 ESP32S3 和雷达底板

| ESP32S3 | 雷达底板 | 功能（雷达    |
| ------- | ---- | -------- |
| 18      | PB0  | UART_TX  |
| 17      | PB1  | UART_RX  |
| 10      | PA0  | SPI_CS   |
| 12      | PA1  | SPI_CLK  |
| 11      | PA2  | SPI_MOSI |
| 13      | PA3  | SPI_MISO |
| 5       | PA4  | I2C_SDA  |
| 4       | PA5  | I2C_SCL  |
| 7       | PA6  | NOTIFY   |
| 8       | PB0  | UPD      |
| 9       | NRST | RST      |
| GND     | GND  | GND      |

### 2.5 新建最小工程

#### 2.5.1 工程配置

推荐使用 `ESP-IDF Templates --> sample_project` 模板。

工程创建完成后，修改工程根目录下的文件 CMakeLists.txt ，在文件内添加：

```
set(EXTRA_COMPONENT_DIRS "${CMAKE_CURRENT_LIST_DIR}/../host_driver")
```

其中 `"../host_driver"` 是 HostDriver 组件与该文件的相对位置，这行语句必须放在 `include(project.cmake)` 之前。

在文件 main/CMakeLists.txt 中，将

```
idf_component_register(SRCS "main.c"
                    INCLUDE_DIRS ".")
```

修改为

```
idf_component_register(SRCS "main.c"
                    INCLUDE_DIRS "."
                    PRIV_REQUIRES host_driver)
```

在文件 main/main.c 中，添加代码：

```
#include "host_driver.h"
#include "host_mmw_api.h"
```

完成上述步骤后，可以编译项目，验证组件是否添加成功。

#### 2.5.2 使用 HostDriver 组件

使用 HostDriver 组件可参考如下代码：

```
#include <stdio.h>
#include "host_driver.h"
#include "host_mmw_api.h"

static DEV_HANDLE s_dev = DEV_HANDLE_INVALID;

static void app_data_handle(
    uint32_t msg_id,
    uint8_t *data,
    uint32_t data_len,
    void *cb_arg
)
{
    if (msg_id == 0xC3) {
        ;
    } else if (msg_id == 0xC6) {
        ;
    } else if (msg_id == 0xFE) {
        ;
    } else if (msg_id == 0xFF) {
        HOST_LOG_INF("dev(%p) startup\n", cb_arg);
    }
}

void app_main(void)
{
    DevHw_t hw_cfg;
    HifCfg_t hif_cfg;

    Host_Driver_Init();
    DevHw_Set_DefaultParam(&hw_cfg,
                           LLC_BUS_TYPE_SPI,
                           LLC_BUS_PARAM_SPI,
                           0, 8000000, 8, 9, 7, 0);
    host_os_memset(&hif_cfg, 0, sizeof(hif_cfg));
    Host_Device_Regist(&s_dev, &hw_cfg, &hif_cfg);
    Mmw_C3_Objects_Handle_Set(s_dev, app_data_handle, s_dev);
    Mmw_C6_GeneralData_Handle_Set(dev, app_data_handle, dev);
    Mmw_FE_Heartbeat_Handle_Set(dev, app_data_handle, dev);
    Mmw_FF_Startup_Handle_Set(dev, app_data_handle, dev);
    Host_Device_Open(s_dev);
}
```

上述代码实现了接收 MsgID=0xC3、0xC6、0xFE、0xFF 上报数据。

#### 2.5.3 使用其它通信端口

请查看 SDK 产品包的文档 `Software_Kit/01_Document/CN/《RS6x_7x_HIF_参考手册》` 的 `5.2.1.2 设备参数配置` 章节。

### 2.6 测试验证

以 MRS6240_P2512 为例，首先为雷达下载固件 `Software_Kit/04_Image/Tracking_mrs6240_p2512.img` ，然后编译、烧录、监控 ESP32S3 ，当 ESP32S3 启动后，复位雷达，会发现 ESP32S3 打印如下内容。

```
[I]dev(0x3fcc46a4) startup
```

其中 `0x3fcc46a4` 是函数 Host_Device_Regist 注册设备后，返回给 s_dev 的十六进制值，这个值与不同的板子、不同的程序代码、不同的启动顺序等因素有关，只要是非零值，一般没有问题。

## 三、示例 Sample

示例 Sample 提供了 Tracking 雷达固件的点云数据可视化样例，能够将点云数据可视化为 3D 点云，并在局域网内的 PC 设备上查看。

### 3.1 数据采集

数据采集依赖官方 HostDriver ESP-IDF 组件，对于 ESP32S3 ，可以直接使用该组件，示例代码如下，代码只保留了关键部分，其余 LOG 、校验等内容有所删减。

```
static uint32_t dev_startup_count = 0;

static void app_data_handle(
    uint32_t msg_id,
    uint8_t *data,
    uint32_t data_len,
    void *cb_arg
)
{
    static uint32_t heart_beat_count = 0;

    if (msg_id == 0xC1) {
        ;
    } else if (msg_id == 0xC2) {
        ;
    } else if (msg_id == 0xC3) {
        /* 0xC3 点云推送可视化服务器（viz_server 内部按推送开关决定是否发送） */
        viz_server_handle_data(msg_id, data, data_len);
    } else if (msg_id == 0xC6) {
        ;
    } else if (msg_id == 0xFE) {
        heart_beat_count++;
    } else if (msg_id == 0xFF) {
        dev_startup_count++;
        HOST_LOG_INF("dev(%p) startup times=%lu\n", cb_arg, dev_startup_count);
    }
}

void app_main(void)
{
    DEV_HANDLE dev = DEV_HANDLE_INVALID;
    DevHw_t hw_cfg;
    HifCfg_t hif_cfg;
    int ret;

    Host_Driver_Init();
    DevHw_Set_DefaultParam(&hw_cfg,
                           s_bus_type, s_bus_param,
                           s_bus_id, s_bus_speed,
                           s_dev_upd_io, s_dev_rst_io, s_dev_notify_io,
                           s_dev_param);
    memset(&hif_cfg, 0, sizeof(hif_cfg));
    Host_Device_Regist(&dev, &hw_cfg, &hif_cfg);
    Mmw_C1_CubeData_Handle_Set(dev, app_data_handle, dev);
    Mmw_C2_FFTData_Handle_Set(dev, app_data_handle, dev);
    Mmw_C3_Objects_Handle_Set(dev, app_data_handle, dev);
    Mmw_C6_GeneralData_Handle_Set(dev, app_data_handle, dev);
    Mmw_FE_Heartbeat_Handle_Set(dev, app_data_handle, dev);
    Mmw_FF_Startup_Handle_Set(dev, app_data_handle, dev);
    Host_Device_Open(dev);
}
```

示例中，使用 HostDriver 组件注册了 MsgID=0xC1、0xC2、0xC3、0xC6、0xFE、0xFF 的回调函数 `app_data_handle` ，在回调函数中，将 0xC3 数据推送到可视化服务器、记录 0xFE 心跳数据上报次数、将 0xFF 数据转换为打印从机启动次数。

### 3.2 数据上传

数据上传依赖 `viz_server_handle_data` API，但是使用之前需要初始化 wifi 、连接 wifi 、启动可视化界面服务器，即

```
app_wifi_init();  // 初始化 wifi
app_wifi_connect_default(5000);  // 连接默认 wifi ，超时时间 5s
viz_server_start();  // 启动可视化界面服务器
```

如果没有设置默认 wifi ，或者默认 wifi 连接不上，可以调用下述 API 重新连接。

```
int app_wifi_connect(const char *ssid,
                     const char *pass,
                     uint32_t timeout_ms)
```

参数分别是 wifi 名、wifi 密码、超时时间。

接下来介绍数据上传 API 的参数要求，首先是 API 声明。

```
void viz_server_handle_data(uint32_t msg_id,
                            uint8_t *data,
                            uint32_t data_len)
```

`msg_id` 是数据上报时的消息 ID ，仅支持 0xC3；

`data` 是点云数据，数据格式如下：

```
typedef struct {
    union {
        struct {
            uint16_t range;
            uint16_t azimuth;
            uint16_t elevation;
            uint16_t velocity;
            uint16_t snr;
            uint16_t reserved;
        } polar;
        struct {
            uint16_t x;
            uint16_t y;
            uint16_t z;
            uint16_t velocity;
            uint16_t snr;
            uint16_t reserved;
        } coord;
    } type;
} Frame_Point_t;

typedef struct {
    uint32_t frameIdx;
    uint32_t frameLen;
    uint32_t dataOffset;

    uint8_t  type;
    uint8_t  flag;
    uint16_t total_length;

    Frame_Point_t data[0];
} FrameData_C3_t;
```

对于 SDK 2.1.2 ，通过 `Mmw_C3_Objects_Handle_Set` 注册的回调函数，在回调时拿到的数据格式就是该格式；

`data_len` 是数据 data 的长度，单位为字节。

### 3.3 数据可视化

数据可视化会在 ESP32S3 成功连接 wifi 并接收到上传的点云数据后自动完成，在浏览器中访问 ESP32S3 的 IP 地址即可。

### 3.4 命令下发

Sample 基于 console 组件调用 HostDriver 组件的 API 实现命令下发，命令组为 `mmwcfg` 。

### 3.5 固件下载

Sample 基于 console 组件调用 HostDriver 组件的 API 、 SPIFFS 组件保存雷达固件实现命令下发，命令组为 `burn` 。

用户可以在 `ESP32S3_Project/img` 目录下添加/删除雷达固件，编译后雷达固件将被内嵌于 ESP32S3 固件内，例如放入 a.img 固件，在下载固件时，通过如下命令实现对从机固件的更换：

```
setdev 0x<device>
burn enter
burn image /spiffs/img/a.img
burn exit
```

第一条命令是设置 console 命令作用的从机对象，是一个十六进制值，该值由 `Host_Device_Regist` 的第一个参数返回。

### 3.6 切换通信端口

切换通信端口可以通过如下命令实现：

```
bus <spi/uart/i2c> [speed]
```

例如切换为 400K I2C ，发送命令 `bus i2c 400000` ，在配置完成通信端口后，不会立即生效，需要重启主机才能生效，可以输入命令 `reboot` 重启主机。

## 四、可视化界面

### 4.1 连接 wifi

ESP32S3 和 PC 连接同一 wifi 后，通过串口助手向 ESP32S3 发送指令获取其 IP 地址：

```
wifi status
```

ESP32S3 回复 IP 地址：

```
wifi: connected, ip=192.168.1.156
```

其中的 `192.168.1.156` 就是 IP 地址，在浏览器中访问便可查看可视化界面。

如果 ESP32S3 没有连接 wifi ，会回复：

```
wifi: not connected
```

此时发送指令连接 wifi ：

```
wifi <ssid> <pass>
```

ssid 是 wifi 名， pass 是 wifi 密码，注意，大部分型号只能连接 2.4G wifi 。

连接成功后的回复示例如下：

```
wifi: connecting "PSIC24"I (342726934) wifi:new:<6,0>, old:<6,0>, ap:<255,255>, sta:<6,0>, prof:1, snd_ch_cfg:0x0
I (342726934) wifi:state: init -> auth (0xb0)
I (342726944) wifi:state: auth -> assoc (0x0)
I (342726954) wifi:state: assoc -> run (0x10)
I (342726994) wifi:connected with PSIC24, aid = 8, channel 6, BW20, bssid = 64:bf:6b:4f:a5:ec
I (342726994) wifi:security: WPA2-PSK, phy: bgn, rssi: -36, cipher(pairwise:0x3, group:0x1), pmf:0
I (342727004) wifi:pm start, type: 1

I (342727004) wifi:dp: 1, bi: 102400, li: 3, scale listen interval from 307200 us to 307200 us
I (342727014) wifi:set rx beacon pti, rx_bcn_pti: 0, bcn_timeout: 25000, mt_pti: 0, mt_time: 10000
I (342727024) wifi:AP's beacon interval = 102400 us, DTIM period = 1
....I (342729204) esp_netif_handlers: sta ip: 192.168.1.156, mask: 255.255.255.0, gw: 192.168.1.1

wifi: connected, ip=192.168.1.156 (浏览器访问 http://192.168.1.156/)
```

### 4.2 可视化界面

PC 在浏览器访问 IP 地址后，会出现如下可视化界面：

![](res/可视化界面.png)

坐标轴处的点，是雷达上报的点云。

如果出现雷达与 ESP32S3 正常工作，但是可视化界面点云不更新，可以点击右上角的 `重连实时数据` 进行手动同步。

## 五、问题与说明

### 5.1 为什么使用 UART 时，总是读不到数据？

ESP-IDF 提供的应用层 API 调度较慢，在接收上报数据时，极大概率出现硬件 FIFO 溢出的情况，应结合 LL 层和中断回调，实现实时数据缓存。也就是说需要及时将数据存放到缓存区， HostDriver 调用 read 接口时再从缓存区取数。

### 5.2 为什么使用 I2C 时，出现 ESP-IDF 内部的溢出报错？

使用 I2C 时，应使用同步事务，否则 HostDriver 认为没有读到数据，会不断发起读取操作。

### 5.3 为什么编译失败？

如果编译时出现如下错误，需要删除 build 目录后重新编译，这是 ESP-IDF 编译时可能出现的问题。

```
C:/esp/v5.5.4/esp-idf/components/esp_lcd/rgb/esp_lcd_panel_rgb.c: In function 'rgb_panel_draw_bitmap':
C:/esp/v5.5.4/esp-idf/components/esp_lcd/rgb/esp_lcd_panel_rgb.c:700:1: internal compiler error: Segmentation fault
  700 | }
      | ^
```
