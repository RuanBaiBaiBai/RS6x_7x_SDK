---
name: SKILL_HostDriver_Porting
description: host_driver 通信总线（SPI/I2C/UART）HAL 移植指南。适用于把 PSIC host_driver（RS6x/7x 毫米波雷达）的 COM 层移植到任意平台（ESP-IDF/STM32/RT-Thread 等）。包含 host_com_ops_t 九接口契约、EDGE 简单路径与 COM_IRQ_THREAD 中断模型两种通知架构、SPI/I2C/UART 逐总线实现骨架、硬性铁律（临界区 printf 禁忌、阻塞禁忌、任务优先级）、烧录（burn）场景专项约束、移植 checklist 与问题排查表。任何 AI 或工程师在接到"移植 host_driver COM 层"任务时必须先加载本 SKILL。
---

# SKILL_HostDriver_Porting

## 0. 适用范围与目标

本 SKILL 指导把 host_driver（PSIC 毫米波雷达主机驱动，RS6x/RS7x 系列）的**通信移植层（COM / porting）** 从 ESP32 移植到任意目标平台。参考实现：`host_driver/porting/esp32/hal_com_{spi,i2c,uart}.c`。

**交付物**：目标平台上的 `hal_com_spi.c` / `hal_com_i2c.c` / `hal_com_uart.c`（+ 必要头文件），实现 `host_com_ops_t` 全部必需回调，并通过 `porting_get_<bus>_com_ops()` 导出。

**禁止修改**：`protocol/`（llc、hif、cmd_api、burn）、`porting/include/`、`host_config.h`、`user_config.h` 中的框架/协议内容。只允许新增/修改 `porting/<平台>/` 下的文件（hal_com_*.c 等）。

---

## 1. 架构与调用关系

```
┌─ app（console / viz / 业务）────────────────────────────┐
│  Host_Driver_Init → Host_Device_Regist → Host_Device_Open │
└───────────────┬──────────────────────────────────────────┘
                ▼
┌─ cmd_api（host_driver.c，协议层，不可改）────────────────┐
└───────────────┬──────────────────────────────────────────┘
                ▼
┌─ protocol ────────────────────────────────────────────────┐
│  LLC（host_llc.c）←→ HIF TL（host_hif_tl.c）              │
│  LLC（host_llc.c）←→ burn（host_burn.c，直连 LLC）         │
│  LLC 持有 host_com_ops_t*，经 porting_get_com_ops 获取     │
└───────────────┬──────────────────────────────────────────┘
                ▼
┌─ porting/port.c（分发，只加 switch 分支）────────────────┐
│  porting_get_com_ops(type, id) → 各总线 HAL               │
└───────────────┬──────────────────────────────────────────┘
                ▼
┌─ porting/<平台>/hal_com_*.c（★ 移植目标）────────────────┐
│  init/deinit/open/close/write/read/read_finish/           │
│  interrupt_ctrl/interrupt_handle_regist/data_callback      │
└───────────────────────────────────────────────────────────┘
```

**关键源码位置**（ESP32 参考实现）：

| 文件                                              | 内容                                             |
| ----------------------------------------------- | ---------------------------------------------- |
| `porting/include/hal_com.h`                     | `host_com_ops_t` 结构、所有回调 typedef（**移植契约，必读**）  |
| `porting/include/hal_os.h`                      | OS 抽象：临界区/信号量/线程/malloc/延时（移植时按平台实现）           |
| `porting/host_port.h`                           | 统一包含入口（`CFG_HOST_PORT_*` 开关）                   |
| `porting/port.c`                                | 分发：`porting_get_com_ops()` switch（新增总线在此加分支）   |
| `porting/esp32/hal_com_uart.c`                  | UART 参考实现（中断+线程模型）                             |
| `porting/esp32/hal_com_spi.c` / `hal_com_i2c.c` | SPI / I2C 参考实现（EDGE 简单路径）                      |
| `porting/esp32/hal_os.c`                        | ESP-IDF 的 OS 抽象实现（信号量 ISR 判断、临界区）              |
| `porting/esp32/port_log.h`                      | 日志宏（`HOST_LOG_*`），`CFG_HOST_PORT_LOG_FILE` 指向它 |

---

## 2. 接口契约：host_com_ops_t 九回调（移植核心）

```c
typedef struct {
    host_com_init_t                    init;        // 总线初始化（bus open）
    host_com_deinit_t                  deinit;      // 总线释放（bus close）
    host_com_open_t                    open;        // 设备打开（device open）
    host_com_close_t                   close;       // 设备关闭（device close）
    host_com_write_t                   write;       // 写数据
    host_com_read_t                    read;        // 读数据
    host_com_read_finish_t             read_finish; // 停止读取/一帧处理完（LLC 调用）
    host_com_interrupt_ctrl_t          interrupt_ctrl;      // 中断使能/阈值（可选）
    host_com_interrupt_handle_regist_t interrupt_handle_regist; // 注册数据到达 handler（可选）
    host_com_data_callback_regist_t    data_callback_regist;   // 数据回调注册（LLC 当前未用）
} host_com_ops_t;
```

### 2.1 逐回调语义

| 回调                        | 参数                                               | 语义                                                                         | 返回值                                                      |
| ------------------------- | ------------------------------------------------ | -------------------------------------------------------------------------- | -------------------------------------------------------- |
| `init`                    | `id` 总线号，`speed` 频率（SPI）/速率（I2C）/波特率（UART），`arg` | 总线级初始化（引脚、时钟、分配资源）。`speed==0` 用默认值                                         | 返回 `void*` bus 句柄；失败返回 NULL                              |
| `deinit`                  | `bus`                                            | 总线级释放（关时钟、释放资源）                                                            | `HOST_ERRCODE_SUCCESS`(0) / 错误码                          |
| `open`                    | `bus`，`param`                                    | **设备级打开**。`param` 含义按总线：SPI=`cs_pin`、I2C=`addr`(7bit)、UART=`id`，可自定义该参数的含义 | 0=成功                                                     |
| `close`                   | `bus`，`param`                                    | 设备级关闭（释放设备句柄）                                                              | 0=成功                                                     |
| `write`                   | `bus`，`param`，`pbuff`，`size`                     | 发送数据                                                                       | **实际发送字节数**（`>0` 成功，LLC_Send 以 >0 判定；失败返回 0，**不能返回错误码**） |
| `read`                    | `bus`，`param`，`pbuff`，`size`                     | 接收数据                                                                       | **实际读取字节数**（`>0` 成功，LLC_Recv 以 >0 判定累加；失败/无数据返回 0）       |
| `read_finish`             | `bus`，`param`                                    | 一帧数据处理完毕/超时。中断型总线在此恢复"允许通知"                                                | 0=成功                                                     |
| `interrupt_ctrl`          | `bus`，`en`，`size`                                | 使能/关闭数据到达中断，`size`=期望接收字节数。**EDGE 型总线置 NULL**                              | 0=成功                                                     |
| `interrupt_handle_regist` | `bus`，`handler`，`arg`                            | 注册"数据到达"中断处理（LLC 传 `llc_interrupt_handle`）。**EDGE 型总线置 NULL**              | 0=成功                                                     |

### 2.2 通知类型（决定 ops 注册哪些）

由设备配置 `notify_type` 决定，`host_com_ops_t` 必须与之匹配：

| 通知类型             | 适用总线       | LLC 行为                                                                                            | 必须注册                                       | 置 NULL                                                                          |
| ---------------- | ---------- | ------------------------------------------------------------------------------------------------- | ------------------------------------------ | ------------------------------------------------------------------------------- |
| `EDGE`           | SPI、I2C    | LLC 走**简单路径**：`LLC_Recv` 循环调 `read` 主动读，超时退出                                                      | `init/deinit/open/close/write/read`        | `read_finish`、`interrupt_ctrl`、`interrupt_handle_regist`、`data_callback_regist` |
| `COM_IRQ_THREAD` | UART       | 数据到达 → HAL 通知 → LLC handler 在**线程上下文**被调（搬运+回填 rx_cache+notify TL）；`LLC_Recv` 先读 rx_cache 再读 ring | 另需 `interrupt_handle_regist`、`read_finish` | `interrupt_ctrl`（未实现则走简单读取路径）、`data_callback_regist`                            |
| `COM_ISR`        | （SKILL不说明） | （SKILL不说明）                                                                                        | （SKILL不说明）                                 | （SKILL不说明）                                                                      |

### 2.3 返回值铁律

- `write`/`read` 只返回**字节数**（0 = 失败/无数据），**严禁返回错误码**（`HOST_ERRCODE_*`）。
- 其余回调返回 `HOST_ERRCODE_SUCCESS`(0) 或 `HOST_ERRCODE_*`。

---

## 3. 两种接收模型（移植前必须选定）

### 3.1 EDGE 简单路径（SPI / I2C 参考：hal_com_spi.c / hal_com_i2c.c）

- 无中断、无事件任务。`read` 为**同步阻塞**调用：发起硬件事务，收完返回字节数。
- LLC_Recv 内部 `while (recv_num < size)` 循环调 `read`，**read 无数据时返回 0，循环会忙等直到超时**——因此移植时 `read` 内部必须自带等待（如信号量/阻塞 API），避免纯忙等饿死低优先级任务（触发看门狗）。
- 硬件读超时用平台默认（SPI 事务、I2C timeout 参数）。

### 3.2 COM_IRQ_THREAD 中断 + 事件线程模型（UART 参考：hal_com_uart.c）

```
硬件 RX 中断 → ISR（只做：清中断 + 搬 FIFO→内部环形缓冲 + 唤醒）
            → 事件线程（evt_task）：队列有数据且允许通知 → 调 handler（LLC 状态机 + llc_read 从 ring 读 + notify TL）
            → read_finish 恢复允许通知（中断常开）
```

**必须实现三件事**（缺一不可）：

1. **ISR 快进快出**：只搬 FIFO 到环形缓冲 + 唤醒，**严禁在 ISR 里调 handler**（handler 是 LLC 状态机+memcpy 重活，ISR 里跑会饿死 IDLE 触发 task_wdt；出错路径 printf 在中断上下文会 abort）。
2. **事件线程（evt_task）**：优先级必须**高于 LLC 的 hif_tl_task**（ESP32 参考：hif_tl=11，evt_task=12）。原因：确保数据通知任务优先级高于数据处理任务优先级。
3. **`allow_notify` 门控**：每次通知后置 0（一轮处理只通知一次），`read_finish` 置 1 恢复；`read_finish` 时队列仍有数据则唤醒evt_task再通知一次。

**环形缓冲要点**：

- ISR 写入 `wr_pos`、read 消费 `rd_pos`（绝对计数，模 ring_size 定位）；回绕流控：`wr_pos - rd_pos > ring_size` 时丢最旧（`rd_pos` 前移）+ 计数。
- **双读者原子性**：handler 与 LLC_Recv 都可能调 `read`。`read` 必须"临界区内判断 + 前进 rd_pos 预留本块，出临界区再 memcpy"（先预留后拷贝），否则并发读者各取同一快照 → 数据重复/瓜分、rd_pos 越过 wr_pos。memcpy 放临界区外（避免长时间关中断）。
- **read 空队列等待**：任务上下文阻塞等"数据就绪"信号量（ISR give），超时返回 0；**等待时间必须 ≥ 1 个系统 tick**（如 CONFIG_FREERTOS_HZ=100 时 ≥10ms，`pdMS_TO_TICKS(1)` 整除得 0=非阻塞，会忙等空转触发 task_wdt）。

---

## 4. 逐总线移植指南

### 4.1 SPI（参考 hal_com_spi.c）

- `init`：平台 SPI master 初始化（ESP-IDF: `spi_bus_initialize`），引脚 SCLK/MOSI/MISO，速度上限 80MHz，默认 8MHz。
- `open`：按 `param=cs_pin` 添加设备（ESP-IDF: `spi_bus_add_device`，mode 0）；**同 cs_pin 已存在时先移除再重建**（保证用最新总线速度，支持烧录降速场景）。
- `write`：全双工事务，只发 `tx_buffer`，成功返回 size。
- `read`：全双工事务，`tx_buffer=NULL`（从机只看时钟），`rx_buffer=pbuff`，成功返回 size。
- 单次事务长度上限（参考 32KB），超限报错返回 0。

### 4.2 I2C（参考 hal_com_i2c.c）

- `init`：I2C master 初始化（ESP-IDF 5.x: `i2c_new_master_bus`），默认 400kHz。
- `open`：按 `param=addr`（7bit，>0x7F 拒绝）添加设备（`i2c_master_bus_add_device`）；同地址先移除。
- **`trans_queue_depth` 必须 = 0（同步事务）**：>0 是实验性异步，高频下报 "ops list is full"，且 API 拿不到总线错误、与 probe 不兼容。LLC 是同步语义，必须同步模式。
- 从机时钟拉伸容忍（`scl_wait_us`，参考 20000us）：从机 SCL 被拉低处理中时 driver 报 "I2C software timeout" 即此问题。
- `read`/`write` 带超时参数（参考 1000ms），失败返回 0。

### 4.3 UART（参考 hal_com_uart.c，最复杂）

- **总线号映射**：平台 console 常占用 UART0 → `bus_id 0→UART1`、`1→UART2`（按平台实际调整）。
- `init`：配置 8N1、无流控、引脚、波特率（范围校验，参考 9600~4M）；**不装驱动，纯寄存器 + 中断**；分配环形缓冲（参考 16KB，2的N次幂）+ "数据就绪"信号量；注册 RX 中断（FIFO 满阈值参考 32B + 空闲超时 3ms 帧判定：`tout_chars = ms*baud/10000`，限幅 1~1023）；创建 evt_task（参考：stack 8192、prio 12、固定核 1）。
- `open`：**清 FIFO 残留 + 复位 wr/rd_pos**（UPD/RST 翻转产生的假数据会入队触发一次 notify，若不清，之后真实数据不再 notify 自动接收）；置 `allow_notify=true`；使能 RX 中断。
- `deinit`：关中断 → 释放中断/线程/信号量/缓冲 → **把 `ctx->handler/handler_arg` 存回静态暂存区再 memset ctx**。原因：burn 流程 `Host_BurnMode_Enter/Exit` 会 Close 设备 → `dev_open_num==0` 时总线 deinit，随后重新 init；若 handler 丢失，事件线程 `handler==NULL` 永不 notify → 退出 burn 后 UART 收不到数据（LLC 只在设备注册时注册一次 handler）。
- `interrupt_handle_regist`：LLC 可能在总线 init **之前**（设备注册阶段）调用 → bus 未创建时暂存到静态变量，init 后绑定。
- `read_finish`：置 `allow_notify=true`；队列仍有数据则再通知事件线程一次。
- **禁止在 HAL ops 内加 printf/HOST_LOG**（见 §5 铁律 1）。
- `interrupt_ctrl` 可置 NULL（LLC 走简单读取路径；若实现则 LLC 走标准中断缓冲路径，可一步到位避免 rx_cache 中转，属高级选项）。

---

## 5. 硬性铁律（违反必出事故，按严重度排序）

1. **【致命】HAL ops（open/close/read/write/read_finish 等）内严禁 printf / HOST_LOG**：LLC 可能在**临界区（关中断）** 内调用 HAL ops（实测 `LLC_Device_Open`、`LLC_Device_Recv_Finish` 链路即是）。printf 的 newlib 递归锁在关中断上下文直接 abort（locks.c 断言）。诊断日志只能放独立任务（如 evt_task）上下文或 init 失败路径。
2. **【致命】临界区内严禁阻塞**：`xSemaphoreTake`/`vTaskDelay` 等阻塞 API 在临界区（关中断+持自旋锁）内调用会 configASSERT/死锁。空队列等待必须先出临界区再等。
3. **【高】事件线程优先级必须高于 hif_tl_task**（参考 12 > 11），否则 handler 填充 rx_cache 与 hif_tl_task 直读竞争 → 数据重复/错位 check32。
4. **【高】ISR 内严禁调 handler**：重活（状态机+memcpy+notify）在 ISR 里会饿死 IDLE → task_wdt 复位；出错路径 printf 直接 abort。
5. **【高】read/write 只返回字节数**（>0 成功、0 失败），严禁返回错误码。
6. **【中】`read` 空队列等待 ≥ 1 tick**（`pdMS_TO_TICKS(1)=0` 陷阱：非阻塞忙等 → task_wdt）。
7. **【中】临界区是"关本地中断 + 全局自旋锁"**（双核 SMP 下跨核互斥）：一个核在临界区，另一核进同一临界区会**自旋等待**。临界区内只做指针操作（取快照/预留 pos），memcpy 放外面。
8. **【中】信号量 give/take 要支持 ISR 上下文**：参考 `host_os_sem_give` 用 `xPortInIsrContext()` 判断走 `GiveFromISR` 版本（否则 ISR 里 give 会崩）。
9. **【中】bus open 前清接收残留**（UART 假数据问题，见 §4.3）。
10. **【低】deinit 前暂存 handler**（burn deinit→reinit 场景，见 §4.3）。

---

## 6. 烧录（burn）场景专项

burn（`burn enter → burn image → burn exit`）是高压测试路径，移植后必须专项验证：

- **流程**：`Host_BurnMode_Enter` 会 Close 同总线设备 → `dev_open_num==0` 时总线 deinit → reopen → 传输；`Host_BurnMode_Exit` 同样 Close+Open。**每个 HAL 必须正确承受 deinit→reinit 循环**（UART 的 handler 暂存机制、SPI/I2C 的 init 幂等）。
- **UART burn 读取竞争（已知坑）**：burn 读路径 `host_burn_protocol_com_read` 每读完**必调 `LLC_Device_Recv_Finish`** → `read_finish` 无条件恢复 `allow_notify=true` → **每个数据包到达都触发 handler**，handler 与 burn 并发从环形缓冲抢数据 → 数据瓜分 → burn `LLC_Recv` 超时（`read err! ret=-5`）。诊断要点：
  - handler（`llc_interrupt_handle`）COM_IRQ_THREAD 分支顺序：**先 `notify_callback`（give notify_sem，host_llc.c:485）→ 再清空 rx_cache → 再 `llc_read` 搬数据（读到这里，需要先检查host_llc.c的llc_interrupt_handle函数，因为当前源代码可能已经将这段逻辑改成了先cache缓存，再notify）**。notify 不依赖搬数据结果。
  - burn 对 UART（`COM_IRQ_THREAD`）必须先等 `notify_sem`（`host_burn.c:166`），该信号量由 handler 的 notify 回调 give → **handler 不能简单禁用**。
  - 修复方向（三选一，按侵入性）：
    a. burn 期间架空 handler 数据搬运（HAL 加 burn 标志，handler 调用 `read` 时返回 0 留数据在 ring；notify 照常给）→ burn 一步拷贝 ring→buffer，无 rx_cache 中转；
    b. LLC_Recv 循环内轮流查 rx_cache 与 ring；
    c. UART 实现 `interrupt_ctrl` 走 LLC 标准中断缓冲路径（一步拷贝，根治，改动大）。
  - **rx_cache 是防溢出缓冲，不是数据中转站**：burn 正确姿势是"环形缓冲 → buffer 一步拷贝"，禁止 "ring→rx_cache→buffer" 两段拷贝。
- **超时兜底**：burn timeout 参考 1000ms，`read` 空队列等待参考 10ms/次，数据段参考 20ms 间隔，余量充足。
- **验收标准**：连续多次 `burn image` 全量通过（无 `read err`），`burn exit` 后设备恢复正常通信（命令响应、主动上报），无残留死锁。

---

## 7. 移植 Checklist（完成后逐项打勾）

- [ ] 平台 OS 抽象（hal_os：临界区/信号量/线程/malloc/延时）就绪，信号量支持 ISR give
- [ ] `host_com_ops_t` 按总线通知类型注册正确回调（EDGE：6 个；COM_IRQ_THREAD：8 个）
- [ ] `read`/`write` 只返回字节数，失败返回 0
- [ ] 所有 HAL ops 无 printf/HOST_LOG（日志只放事件线程/init 失败路径）
- [ ] 无阻塞 API 出现在临界区内
- [ ] UART：evt_task 优先级 > hif_tl_task；ISR 只搬 FIFO；环形缓冲预留 pos 原子读；空队列等待 ≥1 tick；open 清残留；deinit 暂存 handler
- [ ] I2C：同步事务模式（trans_queue_depth=0）；时钟拉伸容忍；7bit 地址校验
- [ ] SPI：同 CS 设备先移除再重建；事务长度上限校验
- [ ] burn enter/exit 循环 ≥3 次通过；exit 后设备恢复正常
- [ ] 新增总线时 `porting/port.c` switch 已加分发分支 + `CFG_HOST_PORT_COM_*_EN` 开关

---

## 8. 问题排查表

| 现象                         | 可能原因                                                 | 排查方向                             |
| -------------------------- | ---------------------------------------------------- | -------------------------------- |
| `read err! ret=-5`（LLC 超时） | handler 与 burn/LLC_Recv 并发抢环形缓冲；数据被瓜分                | 见 §6；检查 allow_notify 恢复时机、双读者原子性 |
| check32 error / 数据错位重复     | evt_task 优先级 ≤ hif_tl_task，handler 回填 rx_cache 与直读竞争 | evt_task 优先级上调（>hif_tl）          |
| task_wdt 复位                | read 空队列忙等（等待 0 tick）；ISR 调 handler 重活               | 等待 ≥1 tick；handler 移线程           |
| 关中断上下文 abort（locks.c）      | HAL ops 内 printf；临界区内阻塞                              | 删 printf；移出临界区                   |
| 退出 burn 后收不到数据             | deinit 后 handler 丢失                                  | handler 暂存区（§4.3）                |
| 偶发首包不处理                    | open 前 FIFO 残留假数据触发一次性 notify                        | open 清残留                         |
| 高频 I2C "ops list is full"  | trans_queue_depth>0 异步模式                             | 置 0 同步                           |
| I2C "software timeout"     | 从机时钟拉伸                                               | scl_wait_us 调大                   |
| ISR 里 give 信号量崩            | sem give 未走 FromISR 分支                               | 用 `xPortInIsrContext()` 分流       |
| 数据间歇性丢失                    | 环形缓冲回绕覆盖                                             | 加大 ring；检查 wr/rd_pos 流控          |

---

## 9. 关键文件索引（参考实现）

- 接口契约：`host_driver/porting/include/hal_com.h`、`hal_os.h`、`host_port.h`
- 分发：`host_driver/porting/port.c`
- ESP32 参考：`host_driver/porting/esp32/hal_com_{spi,i2c,uart}.c`、`hal_os.c`、`port_log.h`
- LLC 调用侧（只读，理解语义）：`host_driver/protocol/llc/host_llc.c`（`llc_read`/`LLC_Recv`/`llc_interrupt_handle`/`LLC_Device_Recv_Finish`）
- burn 调用侧（只读）：`host_driver/protocol/burn/host_burn.c`（`host_burn_protocol_com_read`）
- 配置开关：`CFG_HOST_PORT_COM_EN` / `COM_SPI_EN` / `COM_I2C_EN` / `COM_UART_EN` / `OS_EN`（host_config.h / user_config.h）

---

*（C）POSSUMIC Technology —— host_driver COM 移植指南 v1.0（基于 ESP32S3 ESP-IDF 5.5.4 实测）*
