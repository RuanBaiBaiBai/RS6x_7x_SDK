---
name: SKILL_HostDriver_Porting_EN
description: English version of the host_driver communication-bus (SPI/I2C/UART) HAL porting guide. For porting the COM layer of the PSIC host_driver (RS6x/7x mmWave radar) to any platform (ESP-IDF/STM32/RT-Thread, etc.). Covers the host_com_ops_t nine-callback contract, the EDGE simple path and COM_IRQ_THREAD interrupt-model notification architectures, per-bus SPI/I2C/UART implementation skeletons, hard iron rules (no printf in critical sections, no blocking, task priorities), burn-scenario constraints, a porting checklist, and a troubleshooting table. Any AI or engineer taking on a "port the host_driver COM layer" task MUST load this SKILL first.
---

# SKILL_HostDriver_Porting_EN

## 0. Scope and Goals

This SKILL guides porting the **communication porting layer (COM / porting)** of host_driver (PSIC mmWave radar host driver, RS6x/RS7x series) from ESP32 to any target platform. Reference implementation: `host_driver/porting/esp32/hal_com_{spi,i2c,uart}.c`.

**Deliverables**: `hal_com_spi.c` / `hal_com_i2c.c` / `hal_com_uart.c` (+ required headers) on the target platform, implementing all required callbacks of `host_com_ops_t` and exported via `porting_get_<bus>_com_ops()`.

**Forbidden to modify**: framework/protocol content under `protocol/` (llc, hif, cmd_api, burn), `porting/include/`, `host_config.h`, `user_config.h`. Only files under `porting/<platform>/` (hal_com_*.c etc.) may be added or modified.

---

## 1. Architecture and Call Relationships

```
┌─ app (console / viz / business) ──────────────────────────┐
│  Host_Driver_Init → Host_Device_Regist → Host_Device_Open │
└───────────────┬───────────────────────────────────────────┘
                ▼
┌─ cmd_api (host_driver.c, protocol layer, no modify) ──────┐
└───────────────┬───────────────────────────────────────────┘
                ▼
┌─ protocol ────────────────────────────────────────────────┐
│  LLC (host_llc.c) ←→ HIF TL (host_hif_tl.c)               │
│  LLC (host_llc.c) ←→ burn (host_burn.c, direct LLC)       │
│  LLC holds host_com_ops_t*, via porting_get_com_ops       │
└───────────────┬───────────────────────────────────────────┘
                ▼
┌─ porting/port.c (dispatch, add switch branches) ──────────┐
│  porting_get_com_ops(type, id) → per-bus HAL              │
└───────────────┬───────────────────────────────────────────┘
                ▼
┌─ porting/<platform>/hal_com_*.c (★ porting target) ───────┐
│  init/deinit/open/close/write/read/read_finish/           │
│  interrupt_ctrl/interrupt_handle_regist/data_callback     │
└───────────────────────────────────────────────────────────┘
```

**Key source locations** (ESP32 reference implementation):

| File                                             | Content                                            |
| ------------------------------------------------ | ------------------------------------------------- |
| `porting/include/hal_com.h`                      | `host_com_ops_t` struct and all callback typedefs (**porting contract, must read**) |
| `porting/include/hal_os.h`                       | OS abstraction: critical section / semaphore / thread / malloc / delay (implement per platform) |
| `porting/host_port.h`                            | Unified include entry (`CFG_HOST_PORT_*` switches) |
| `porting/port.c`                                 | Dispatch: `porting_get_com_ops()` switch (add branches here for new buses) |
| `porting/esp32/hal_com_uart.c`                   | UART reference implementation (interrupt + thread model) |
| `porting/esp32/hal_com_spi.c` / `hal_com_i2c.c`  | SPI / I2C reference implementation (EDGE simple path) |
| `porting/esp32/hal_os.c`                         | ESP-IDF OS abstraction implementation (semaphore ISR detection, critical section) |
| `porting/esp32/port_log.h`                       | Log macros (`HOST_LOG_*`); `CFG_HOST_PORT_LOG_FILE` points to it |

---

## 2. Interface Contract: host_com_ops_t Nine Callbacks (Porting Core)

```c
typedef struct {
    host_com_init_t                    init;        // bus init (bus open)
    host_com_deinit_t                  deinit;      // bus release (bus close)
    host_com_open_t                    open;        // device open
    host_com_close_t                   close;       // device close
    host_com_write_t                   write;       // write data
    host_com_read_t                    read;        // read data
    host_com_read_finish_t             read_finish; // stop reading / frame handled (called by LLC)
    host_com_interrupt_ctrl_t          interrupt_ctrl;      // interrupt enable/threshold (optional)
    host_com_interrupt_handle_regist_t interrupt_handle_regist; // register data-arrival handler (optional)
    host_com_data_callback_regist_t    data_callback_regist;   // data callback registration (not used by LLC currently)
} host_com_ops_t;
```

### 2.1 Per-callback Semantics

| Callback                 | Parameters                                            | Semantics                                                                        | Return value                                                 |
| ------------------------ | ----------------------------------------------------- | ------------------------------------------------------------------------------- | ------------------------------------------------------------ |
| `init`                   | `id` bus number, `speed` freq(SPI)/rate(I2C)/baud(UART), `arg` | Bus-level init (pins, clock, allocate resources). `speed==0` uses defaults                 | Returns `void*` bus handle; NULL on failure                  |
| `deinit`                 | `bus`                                                 | Bus-level release (clock off, free resources)                                     | `HOST_ERRCODE_SUCCESS`(0) / error code                       |
| `open`                   | `bus`, `param`                                        | **Device-level open**. `param` meaning by bus: SPI=`cs_pin`, I2C=`addr`(7-bit), UART=`id`; the platform may customize the meaning of this parameter | 0=success |
| `close`                  | `bus`, `param`                                        | Device-level close (release device handle)                                         | 0=success                                                    |
| `write`                  | `bus`, `param`, `pbuff`, `size`                       | Send data                                                                            | **Actual bytes sent** (`>0` success; LLC_Send tests `>0`; on failure return 0, **never an error code**) |
| `read`                   | `bus`, `param`, `pbuff`, `size`                       | Receive data                                                                            | **Actual bytes read** (`>0` success; LLC_Recv tests `>0` and accumulates; 0 on failure/no data) |
| `read_finish`            | `bus`, `param`                                        | A frame has been processed / timed out. Interrupt-type buses restore "allow notify" here | 0=success |
| `interrupt_ctrl`         | `bus`, `en`, `size`                                   | Enable/disable data-arrival interrupt; `size`=expected byte count. **Set NULL for EDGE-type buses** | 0=success |
| `interrupt_handle_regist`| `bus`, `handler`, `arg`                               | Register "data arrival" interrupt handler (LLC passes `llc_interrupt_handle`). **Set NULL for EDGE-type buses** | 0=success |

### 2.2 Notification Types (determines which ops to register)

Determined by the device configuration `notify_type`; `host_com_ops_t` must match:

| Notification type | Applicable buses | LLC behavior                                                                                                  | Must register                                        | May be NULL                                                                          |
| ----------------- | ---------------- | ------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------- | ------------------------------------------------------------------------------------ |
| `EDGE`            | SPI, I2C         | LLC uses the **simple path**: `LLC_Recv` loops calling `read` actively, exits on timeout                                | `init/deinit/open/close/write/read`                  | `read_finish`, `interrupt_ctrl`, `interrupt_handle_regist`, `data_callback_regist`    |
| `COM_IRQ_THREAD`  | UART             | Data arrival → HAL notify → LLC handler called in **thread context** (move data + refill rx_cache + notify TL); `LLC_Recv` reads rx_cache first, then the ring | additionally `interrupt_handle_regist`, `read_finish` | `interrupt_ctrl` (falls back to simple read path if not implemented), `data_callback_regist` |
| `COM_ISR`         | (not covered in this SKILL) | (not covered in this SKILL)                                                                                    | (not covered in this SKILL)                          | (not covered in this SKILL)                                                            |

### 2.3 Return Value Iron Rules

- `write`/`read` return **only byte counts** (0 = failure/no data); **never return error codes** (`HOST_ERRCODE_*`).
- All other callbacks return `HOST_ERRCODE_SUCCESS`(0) or `HOST_ERRCODE_*`.

---

## 3. Two Receive Models (must choose before porting)

### 3.1 EDGE Simple Path (SPI / I2C reference: hal_com_spi.c / hal_com_i2c.c)

- No interrupt, no event task. `read` is a **synchronous blocking** call: start a hardware transaction, return the byte count when done.
- Inside `LLC_Recv`, a `while (recv_num < size)` loop calls `read`; **when `read` returns 0 (no data) the loop busy-waits until timeout** — therefore the ported `read` must internally wait on its own (semaphore / blocking API) to avoid pure busy-wait starving low-priority tasks (triggers the watchdog).
- Use platform defaults for hardware read timeout (SPI transaction, I2C timeout parameter).

### 3.2 COM_IRQ_THREAD Interrupt + Event Thread Model (UART reference: hal_com_uart.c)

```
HW RX interrupt → ISR (only: clear interrupt + move FIFO→internal ring buffer + wake)
               → event thread (evt_task): data queued and notify allowed → call handler (LLC state machine + llc_read from ring + notify TL)
               → read_finish restores notify-allowed (interrupt stays enabled)
```

**Three things MUST be implemented** (all required):

1. **ISR in, ISR out**: only move FIFO to the ring buffer + wake up; **never call the handler in the ISR** (the handler is heavy LLC state machine + memcpy; running it in the ISR starves IDLE and triggers task_wdt; printf on error paths in interrupt context aborts).
2. **Event thread (evt_task)**: priority MUST be **higher than the LLC hif_tl_task** (ESP32 reference: hif_tl=11, evt_task=12). Reason: ensures the data-notification task priority is higher than the data-processing task priority.
3. **`allow_notify` gating**: set to 0 after each notification (one notification per round); `read_finish` sets it back to 1; if data is still queued when `read_finish` is called, wake evt_task and notify once more.

**Ring buffer essentials**:

- ISR writes `wr_pos`, `read` consumes `rd_pos` (absolute counters, positioned modulo ring_size); wraparound flow control: when `wr_pos - rd_pos > ring_size`, drop the oldest (`rd_pos` advances) + count.
- **Dual-reader atomicity**: both the handler and `LLC_Recv` may call `read`. `read` must "check inside the critical section + advance rd_pos to reserve this chunk, then memcpy after leaving the critical section" (reserve-then-copy); otherwise concurrent readers take the same snapshot → duplicated/split data, rd_pos passing wr_pos. Keep memcpy outside the critical section (avoid long interrupt disable).
- **read empty-queue wait**: block in task context on the "data ready" semaphore (given by ISR), return 0 on timeout; **the wait MUST be ≥ 1 system tick** (e.g. ≥10ms at CONFIG_FREERTOS_HZ=100; `pdMS_TO_TICKS(1)` truncates to 0 = non-blocking, causing busy-wait spin and task_wdt).

---

## 4. Per-Bus Porting Guide

### 4.1 SPI (reference hal_com_spi.c)

- `init`: platform SPI master init (ESP-IDF: `spi_bus_initialize`), pins SCLK/MOSI/MISO, speed up to 80MHz, default 8MHz.
- `open`: add device by `param=cs_pin` (ESP-IDF: `spi_bus_add_device`, mode 0); **if the same cs_pin already exists, remove first then re-add** (ensures the latest bus speed, supports the burn speed-reduction scenario).
- `write`: full-duplex transaction, send `tx_buffer` only, return size on success.
- `read`: full-duplex transaction, `tx_buffer=NULL` (slave only sees the clock), `rx_buffer=pbuff`, return size on success.
- Single-transaction length limit (reference 32KB); return 0 if exceeded.

### 4.2 I2C (reference hal_com_i2c.c)

- `init`: I2C master init (ESP-IDF 5.x: `i2c_new_master_bus`), default 400kHz.
- `open`: add device by `param=addr` (7-bit; reject >0x7F) (`i2c_master_bus_add_device`); remove the same address first if it exists.
- **`trans_queue_depth` MUST be 0 (synchronous transactions)**: >0 is experimental async; under high frequency it reports "ops list is full", the API cannot retrieve bus errors, and it is incompatible with probe. LLC has synchronous semantics — must use synchronous mode.
- Slave clock-stretch tolerance (`scl_wait_us`, reference 20000us): when the slave holds SCL low while processing, the driver reports "I2C software timeout" — that is this problem.
- `read`/`write` with timeout parameters (reference 1000ms), return 0 on failure.

### 4.3 UART (reference hal_com_uart.c, the most complex)

- **Bus number mapping**: the platform console usually occupies UART0 → `bus_id 0→UART1`, `1→UART2` (adjust per platform).
- `init`: configure 8N1, no flow control, pins, baud rate (range-checked, reference 9600~4M); **do NOT install the driver, pure registers + interrupts**; allocate a ring buffer (reference 16KB, power of 2) + a "data ready" semaphore; register the RX interrupt (FIFO full threshold reference 32B + idle timeout 3ms frame detection: `tout_chars = ms*baud/10000`, clamped to 1~1023); create evt_task (reference: stack 8192, prio 12, pinned core 1).
- `open`: **clear FIFO residue + reset wr/rd_pos** (bogus data from UPD/RST toggling can queue and trigger one notify; if not cleared, real data afterwards never notifies for auto-receive); set `allow_notify=true`; enable the RX interrupt.
- `deinit`: disable interrupt → free interrupt/thread/semaphore/buffer → **store `ctx->handler/handler_arg` back to a static staging area, then memset ctx**. Reason: the burn flow `Host_BurnMode_Enter/Exit` closes the device → when `dev_open_num==0` the bus deinits and later re-inits; if the handler is lost, the event thread never notifies (`handler==NULL`) → after exiting burn, UART receives nothing (LLC registers the handler only once, at device registration).
- `interrupt_handle_regist`: LLC may call it **before** bus init (device registration phase) → stage into a static variable if the bus does not exist yet, bind after init.
- `read_finish`: set `allow_notify=true`; if data is still queued, notify the event thread once more.
- **No printf/HOST_LOG inside HAL ops** (see iron rule 1 in §5).
- `interrupt_ctrl` may be NULL (LLC uses the simple read path; if implemented, LLC uses the standard interrupt-buffer path, a single-step copy avoiding rx_cache relaying — advanced option).

---

## 5. Hard Iron Rules (violations cause incidents, ordered by severity)

1. **【FATAL】No printf / HOST_LOG inside HAL ops (open/close/read/write/read_finish, etc.)**: LLC may call HAL ops inside a **critical section (interrupts disabled)** (verified on the `LLC_Device_Open` and `LLC_Device_Recv_Finish` paths). printf's newlib recursive lock aborts directly in interrupt-disabled context (locks.c assertion). Diagnostic logs only belong in an independent task context (e.g. evt_task) or the init-failure path.
2. **【FATAL】No blocking inside a critical section**: blocking APIs such as `xSemaphoreTake`/`vTaskDelay` called inside a critical section (interrupts off + holding the spinlock) cause configASSERT/deadlock. Empty-queue waits must first exit the critical section.
3. **【HIGH】Event thread priority must be higher than hif_tl_task** (reference 12 > 11); otherwise the handler refilling rx_cache races with hif_tl_task's direct read → duplicated/misaligned data (check32 error).
4. **【HIGH】Never call the handler inside the ISR**: heavy work (state machine + memcpy + notify) in the ISR starves IDLE → task_wdt reset; printf on error paths aborts directly.
5. **【HIGH】read/write return byte counts only** (>0 success, 0 failure); never return error codes.
6. **【MEDIUM】`read` empty-queue wait ≥ 1 tick** (`pdMS_TO_TICKS(1)=0` trap: non-blocking busy-wait → task_wdt).
7. **【MEDIUM】A critical section is "disable local interrupts + global spinlock"** (cross-core mutual exclusion on dual-core SMP): while one core is in the critical section, the other core entering it **spins**. Inside the critical section only do pointer operations (take snapshot / reserve pos); memcpy goes outside.
8. **【MEDIUM】Semaphore give/take must support ISR context**: reference `host_os_sem_give`, which uses `xPortInIsrContext()` to pick the `GiveFromISR` variant (otherwise giving in the ISR crashes).
9. **【MEDIUM】Clear receive residue before bus open** (UART bogus-data problem, see §4.3).
10. **【LOW】Stage the handler before deinit** (burn deinit→reinit scenario, see §4.3).

---

## 6. Burn Scenario

burn (`burn enter → burn image → burn exit`) is the high-stress test path; after porting it MUST be verified specifically:

- **Flow**: `Host_BurnMode_Enter` closes devices on the same bus → when `dev_open_num==0` the bus deinits → reopens → transfers; `Host_BurnMode_Exit` also Close+Open. **Every HAL must correctly survive the deinit→reinit cycle** (UART's handler staging mechanism; SPI/I2C init idempotency).
- **UART burn read race (known pitfall)**: the burn read path `host_burn_protocol_com_read` **always calls `LLC_Device_Recv_Finish` after each read** → `read_finish` unconditionally restores `allow_notify=true` → **every data packet arrival triggers the handler**; the handler and burn concurrently grab data from the ring buffer → data split → burn `LLC_Recv` times out (`read err! ret=-5`). Diagnostic points:
  - COM_IRQ_THREAD branch order of the handler (`llc_interrupt_handle`): **first `notify_callback` (gives notify_sem, host_llc.c:485) → then clear rx_cache → then `llc_read` moves data. (At this point, first check the current `llc_interrupt_handle` in host_llc.c — the source may have been changed to cache into rx_cache first and then notify.)** Notify does not depend on the data-move result.
  - For UART (`COM_IRQ_THREAD`), burn must first wait on `notify_sem` (`host_burn.c:166`), given by the handler's notify callback → **the handler cannot simply be disabled**.
  - Fix directions (pick one of three, by invasiveness):
    a. Neutralize the handler's data move during burn (HAL adds a burn flag; when set, the handler's `read` returns 0, leaving data in the ring; notify still fires) → burn copies ring→buffer in one step, no rx_cache relay;
    b. `LLC_Recv` loop alternately checks rx_cache and the ring;
    c. UART implements `interrupt_ctrl` to use LLC's standard interrupt-buffer path (single-step copy; root fix, but a bigger change).
  - **rx_cache is an anti-overflow buffer, not a data relay**: the correct burn posture is a one-step "ring buffer → buffer" copy; "ring→rx_cache→buffer" two-stage copy is forbidden.
- **Timeout safety margin**: burn timeout reference 1000ms, `read` empty-queue wait reference 10ms/iteration, data segment reference 20ms interval — ample margin.
- **Acceptance criteria**: consecutive `burn image` runs pass completely (no `read err`); after `burn exit` the device resumes normal communication (command responses, active reporting) with no residual deadlock.

---

## 7. Porting Checklist (check off each item when done)

- [ ] Platform OS abstraction (hal_os: critical section / semaphore / thread / malloc / delay) ready; semaphore supports ISR give
- [ ] `host_com_ops_t` registers the correct callbacks per bus notify type (EDGE: 6; COM_IRQ_THREAD: 8)
- [ ] `read`/`write` return byte counts only, 0 on failure
- [ ] No printf/HOST_LOG in any HAL op (logs only in the event thread / init-failure path)
- [ ] No blocking API inside a critical section
- [ ] UART: evt_task priority > hif_tl_task; ISR only moves FIFO; ring buffer reserve-pos atomic read; empty-queue wait ≥1 tick; open clears residue; deinit stages handler
- [ ] I2C: synchronous transaction mode (trans_queue_depth=0); clock-stretch tolerance; 7-bit address validation
- [ ] SPI: remove-and-rebuild same CS device; transaction length limit check
- [ ] burn enter/exit cycle passes ≥3 times; device recovers normally after exit
- [ ] New bus: `porting/port.c` switch has the dispatch branch + `CFG_HOST_PORT_COM_*_EN` switch

---

## 8. Troubleshooting Table

| Symptom                          | Likely cause                                                      | Where to look                                                       |
| -------------------------------- | ----------------------------------------------------------------- | ------------------------------------------------------------------- |
| `read err! ret=-5` (LLC timeout) | handler and burn/LLC_Recv concurrently grab the ring buffer; data split | see §6; check allow_notify restore timing, dual-reader atomicity    |
| check32 error / misaligned/duplicated data | evt_task priority ≤ hif_tl_task; handler refills rx_cache racing direct read | raise evt_task priority (>hif_tl)                                   |
| task_wdt reset                   | read empty-queue busy-wait (0-tick wait); heavy handler work in ISR | wait ≥1 tick; move handler to a thread                               |
| abort in interrupt-disabled context (locks.c) | printf inside HAL ops; blocking inside critical section          | remove printf; move out of the critical section                      |
| No data received after exiting burn | handler lost after deinit                                        | handler staging area (§4.3)                                          |
| Occasional first packet not handled | FIFO residue before open triggers a one-time notify              | clear residue on open                                                 |
| High-frequency I2C "ops list is full" | trans_queue_depth>0 async mode                                   | set to 0 synchronous                                                 |
| I2C "software timeout"           | slave clock stretching                                           | increase scl_wait_us                                                  |
| Crash giving a semaphore in ISR  | sem give does not use the FromISR branch                         | branch with `xPortInIsrContext()`                                     |
| Intermittent data loss            | ring buffer wraparound overwrite                                 | enlarge ring; check wr/rd_pos flow control                            |

---

## 9. Key File Index (reference implementation)

- Interface contract: `host_driver/porting/include/hal_com.h`, `hal_os.h`, `host_port.h`
- Dispatch: `host_driver/porting/port.c`
- ESP32 reference: `host_driver/porting/esp32/hal_com_{spi,i2c,uart}.c`, `hal_os.c`, `port_log.h`
- LLC caller side (read-only, to understand semantics): `host_driver/protocol/llc/host_llc.c` (`llc_read`/`LLC_Recv`/`llc_interrupt_handle`/`LLC_Device_Recv_Finish`)
- burn caller side (read-only): `host_driver/protocol/burn/host_burn.c` (`host_burn_protocol_com_read`)
- Config switches: `CFG_HOST_PORT_COM_EN` / `COM_SPI_EN` / `COM_I2C_EN` / `COM_UART_EN` / `OS_EN` (host_config.h / user_config.h)

---

*（C）POSSUMIC Technology — host_driver COM Porting Guide v1.0 (English, verified on ESP32S3 ESP-IDF 5.5.4)*
