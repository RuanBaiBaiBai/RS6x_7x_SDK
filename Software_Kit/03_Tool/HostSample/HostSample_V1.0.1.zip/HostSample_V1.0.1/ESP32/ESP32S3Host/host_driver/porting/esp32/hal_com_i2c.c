/**
 **************************************************************************************************
 * @file    hal_com_i2c.c
 * @brief   HAL COM (I2C master) porting for ESP-IDF.
 * @note    LLC 层经 porting/port.c 的 porting_get_com_ops 转调本函数。
 *          使用 ESP-IDF 5.x I2C master driver（driver/i2c_master.h）。
 *          引脚可在 user_config.h 中通过 HOST_PORT_I2C_* 宏覆盖。
 * @attention
 *          Copyright (c) 2026 Possumic Technology. all rights reserved.
 **************************************************************************************************
 */

/* Includes.
 * ------------------------------------------------------------------------------------------------
 */
#include "host_port.h"
#include "host_llc_com_bus.h"

#include <string.h>
#include "driver/i2c_master.h"

#if (CFG_HOST_PORT_COM_EN == 1) && (CFG_HOST_PORT_COM_I2C_EN == 1)

/* Exported defines.
 * ------------------------------------------------------------------------------------------------
 */
/* I2C 引脚配置（可在 user_config.h 中覆盖） */
#ifndef HOST_PORT_I2C_SCL_PIN
#define HOST_PORT_I2C_SCL_PIN                    4
#endif
#ifndef HOST_PORT_I2C_SDA_PIN
#define HOST_PORT_I2C_SDA_PIN                    5
#endif

#ifndef HOST_PORT_I2C_MAX_DEV_PER_BUS
#define HOST_PORT_I2C_MAX_DEV_PER_BUS            4
#endif

/* LLC bus_id 0 -> I2C_NUM_0, 1 -> I2C_NUM_1 */
#define HOST_PORT_I2C_BUS_NUM                    2

/* 单次传输超时（ms） */
#ifndef HOST_PORT_I2C_XFER_TIMEOUT_MS
#define HOST_PORT_I2C_XFER_TIMEOUT_MS            1000
#endif

/* 从机时钟拉伸容忍时间（us）；0=driver 默认寄存器值。
 * 从机响应慢（SCL 被拉低等待/处理中）时 driver 会报 "I2C software timeout"，
 * 设非 0 值允许从机拉伸 SCL 至多该时长。 */
#ifndef HOST_PORT_I2C_SCL_WAIT_US
#define HOST_PORT_I2C_SCL_WAIT_US                20000
#endif

/* I2C master 事务模式（trans_queue_depth）：
 * 0   -> 同步事务（默认，推荐）：transmit/receive 阻塞等待完成，API 能返回总线
 *        错误（NACK 等），与 i2c_master_probe 兼容，无异步 ops 池；
 * >0  -> 实验性异步事务：driver 内部 ops 队列，高频下报 "ops list is full, please
 *        increase your trans_queue_depth"，且 API 拿不到总线错误、与 probe 不兼容。
 *        LLC 为同步调用语义（每次等待完成/超时），必须用同步模式，勿设 >0。 */
#ifndef HOST_PORT_I2C_TRANS_QUEUE_DEPTH
#define HOST_PORT_I2C_TRANS_QUEUE_DEPTH          0
#endif

/* Exported types.
 * ------------------------------------------------------------------------------------------------
 */
typedef struct {
    i2c_master_bus_handle_t bus;
    bool is_init;
    uint32_t speed;
    i2c_master_dev_handle_t devs[HOST_PORT_I2C_MAX_DEV_PER_BUS];
    uint16_t dev_addrs[HOST_PORT_I2C_MAX_DEV_PER_BUS];   /* 设备从机地址（DevHw_t.param） */
} host_i2c_bus_ctx_t;

/* Exported variables.
 * ------------------------------------------------------------------------------------------------
 */
static host_i2c_bus_ctx_t s_i2c_buses[HOST_PORT_I2C_BUS_NUM];

/* Exported functions.
 * ------------------------------------------------------------------------------------------------
 */

static host_i2c_bus_ctx_t *host_i2c_ctx_get(uint8_t id)
{
    if (id >= HOST_PORT_I2C_BUS_NUM) {
        return NULL;
    }
    return &s_i2c_buses[id];
}

static i2c_master_dev_handle_t *host_i2c_dev_find(host_i2c_bus_ctx_t *ctx, uint16_t addr)
{
    for (int i = 0; i < HOST_PORT_I2C_MAX_DEV_PER_BUS; i++) {
        if ((ctx->dev_addrs[i] == addr) && (ctx->devs[i] != NULL)) {
            return &ctx->devs[i];
        }
    }
    return NULL;
}

/* 总线上电：i2c_new_master_bus */
static void *host_i2c_init(uint8_t id, uint32_t speed, void *arg)
{
    host_i2c_bus_ctx_t *ctx = host_i2c_ctx_get(id);
    i2c_master_bus_config_t buscfg;
    esp_err_t err;

    (void)arg;
    if ((ctx == NULL) || ctx->is_init) {
        return NULL;
    }

    memset(&buscfg, 0, sizeof(buscfg));
    buscfg.i2c_port          = (id == 0) ? I2C_NUM_0 : I2C_NUM_1;
    buscfg.scl_io_num        = HOST_PORT_I2C_SCL_PIN;
    buscfg.sda_io_num        = HOST_PORT_I2C_SDA_PIN;
    buscfg.clk_source        = I2C_CLK_SRC_DEFAULT;
    buscfg.glitch_ignore_cnt = 7;
    buscfg.intr_priority     = 0;              /* 默认优先级 */
    buscfg.trans_queue_depth = HOST_PORT_I2C_TRANS_QUEUE_DEPTH;

    err = i2c_new_master_bus(&buscfg, &ctx->bus);
    if (err != ESP_OK) {
        HOST_LOG_ERR("i2c_new_master_bus(bus_id=%u) fail: %d\n", id, err);
        return NULL;
    }

    ctx->speed   = (speed == 0) ? 400000 : speed;
    ctx->is_init = true;
    return ctx;
}

/* 总线下电：i2c_del_master_bus */
static int host_i2c_deinit(void *bus)
{
    host_i2c_bus_ctx_t *ctx = (host_i2c_bus_ctx_t *)bus;
    esp_err_t err;

    if ((ctx == NULL) || !ctx->is_init) {
        return HOST_ERRCODE_INVALID_PARAM;
    }
    err = i2c_del_master_bus(ctx->bus);
    if (err != ESP_OK) {
        return HOST_ERRCODE_IO_ERROR;
    }
    memset(ctx, 0, sizeof(*ctx));
    return HOST_ERRCODE_SUCCESS;
}

/* 设备打开：按从机地址添加 I2C 设备（速度取总线当前值） */
static int host_i2c_open(void *bus, uint32_t param)
{
    host_i2c_bus_ctx_t *ctx = (host_i2c_bus_ctx_t *)bus;
    i2c_device_config_t devcfg;
    uint16_t addr = (uint16_t)param;
    esp_err_t err;
    int slot = -1;

    if ((ctx == NULL) || !ctx->is_init) {
        return HOST_ERRCODE_INVALID_PARAM;
    }
    if (addr > 0x7F) {  // allways 7-bit device
        HOST_LOG_ERR("%s: addr=0x%04X out of 7-bit range!\n", __func__, addr);
        return HOST_ERRCODE_INVALID_PARAM;
    }

    /* 同地址已存在：先移除，保证以最新总线速度重新添加 */
    for (int i = 0; i < HOST_PORT_I2C_MAX_DEV_PER_BUS; i++) {
        if ((ctx->devs[i] != NULL) && (ctx->dev_addrs[i] == addr)) {
            i2c_master_bus_rm_device(ctx->devs[i]);
            ctx->devs[i]       = NULL;
            ctx->dev_addrs[i]  = 0;
            break;
        }
    }

    /* 查找空槽位 */
    for (int i = 0; i < HOST_PORT_I2C_MAX_DEV_PER_BUS; i++) {
        if (ctx->devs[i] == NULL) {
            slot = i;
            break;
        }
    }
    if (slot < 0) {
        return HOST_ERRCODE_NO_BUFFER;
    }

    memset(&devcfg, 0, sizeof(devcfg));
    devcfg.dev_addr_length = I2C_ADDR_BIT_LEN_7;
    devcfg.device_address  = addr;
    devcfg.scl_speed_hz    = ctx->speed;
    devcfg.scl_wait_us     = HOST_PORT_I2C_SCL_WAIT_US;   /* 容忍从机时钟拉伸 */

    err = i2c_master_bus_add_device(ctx->bus, &devcfg, &ctx->devs[slot]);
    if (err != ESP_OK) {
        return HOST_ERRCODE_IO_ERROR;
    }
    ctx->dev_addrs[slot] = addr;
    return HOST_ERRCODE_SUCCESS;
}

/* 设备关闭：按从机地址移除 I2C 设备 */
static int host_i2c_close(void *bus, uint32_t param)
{
    host_i2c_bus_ctx_t *ctx = (host_i2c_bus_ctx_t *)bus;
    uint16_t addr = (uint16_t)param;
    int slot = -1;

    if ((ctx == NULL) || !ctx->is_init) {
        return HOST_ERRCODE_INVALID_PARAM;
    }
    for (int i = 0; i < HOST_PORT_I2C_MAX_DEV_PER_BUS; i++) {
        if ((ctx->devs[i] != NULL) && (ctx->dev_addrs[i] == addr)) {
            slot = i;
            break;
        }
    }
    if (slot < 0) {
        return HOST_ERRCODE_SUCCESS;   /* 不存在视为成功 */
    }
    i2c_master_bus_rm_device(ctx->devs[slot]);
    ctx->devs[slot]      = NULL;
    ctx->dev_addrs[slot] = 0;
    return HOST_ERRCODE_SUCCESS;
}

/* 写数据
 * @retval 成功返回实际发送字节数；失败返回 0
 *         （LLC_Send 以 >0 判定成功并累加字节数，不能返回 HOST_ERRCODE_*） */
static int host_i2c_write(void *bus, uint32_t param, void *pbuff, uint32_t size)
{
    host_i2c_bus_ctx_t *ctx = (host_i2c_bus_ctx_t *)bus;
    i2c_master_dev_handle_t *dev;

    if ((ctx == NULL) || (pbuff == NULL) || (size == 0)) {
        return 0;
    }
    dev = host_i2c_dev_find(ctx, (uint16_t)param);
    if (dev == NULL) {
        return 0;
    }
    if (i2c_master_transmit(*dev, pbuff, size, HOST_PORT_I2C_XFER_TIMEOUT_MS) != ESP_OK) {
        return 0;
    }
    return (int)size;
}

/* 读数据
 * @retval 成功返回实际读取字节数；失败返回 0
 *         （LLC_Recv 以 >0 判定成功并累加字节数） */
static int host_i2c_read(void *bus, uint32_t param, void *pbuff, uint32_t size)
{
    host_i2c_bus_ctx_t *ctx = (host_i2c_bus_ctx_t *)bus;
    i2c_master_dev_handle_t *dev;

    if ((ctx == NULL) || (pbuff == NULL) || (size == 0)) {
        return 0;
    }
    dev = host_i2c_dev_find(ctx, (uint16_t)param);
    if (dev == NULL) {
        return 0;
    }
    if (i2c_master_receive(*dev, pbuff, size, HOST_PORT_I2C_XFER_TIMEOUT_MS) != ESP_OK) {
        return 0;
    }
    return (int)size;
}

/* I2C 总线操作集（LLC 层经 porting/port.c 的 porting_get_com_ops 转调本函数）。
 * I2C 与 SPI 同用 EDGE 通知（DevHw_Set_DefaultParam: upload_type=PASSIVE、
 * notify_type=EDGE），只需常规接口，interrupt 相关置 NULL。 */
host_com_ops_t *porting_get_i2c_com_ops(host_bus_type_t type, uint8_t id)
{
    static const host_com_ops_t s_i2c_ops = {
        .init                     = host_i2c_init,
        .deinit                   = host_i2c_deinit,
        .open                     = host_i2c_open,
        .close                    = host_i2c_close,
        .write                    = host_i2c_write,
        .read                     = host_i2c_read,
        .read_finish              = NULL,
        .interrupt_ctrl           = NULL,
        .interrupt_handle_regist  = NULL,
        .data_callback_regist     = NULL,
    };

    if (type == HOST_BUS_TYPE_I2C && id < HOST_PORT_I2C_BUS_NUM) {
        return (host_com_ops_t *)&s_i2c_ops;
    }
    return NULL;
}

#endif  /* CFG_HOST_PORT_COM_EN == 1 && CFG_HOST_PORT_COM_I2C_EN == 1 */

/*
 **************************************************************************************************
 * (C) COPYRIGHT POSSUMIC Technology
 * END OF FILE
 **************************************************************************************************
 */
