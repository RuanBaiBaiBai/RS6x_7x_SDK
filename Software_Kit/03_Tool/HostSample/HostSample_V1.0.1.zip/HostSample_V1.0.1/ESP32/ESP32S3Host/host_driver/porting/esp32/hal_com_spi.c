/**
 **************************************************************************************************
 * @file    hal_com_spi.c
 * @brief   HAL COM (SPI master) porting for ESP-IDF.
 * @note    LLC 层通过 porting_get_com_ops() 获取总线操作集。
 *          引脚可在 user_config.h 中通过 HOST_PORT_SPI_* 宏覆盖。
 * @attention
 *          Copyright (c) 2026 Possumic Technology. all rights reserved.
 **************************************************************************************************
 */

/* Includes.
 * ------------------------------------------------------------------------------------------------
 */
#include "host_port.h"
#include "host_llc_com_bus.h"

#include <string.h>
#include "driver/spi_master.h"

#if (CFG_HOST_PORT_COM_EN == 1) && (CFG_HOST_PORT_COM_SPI_EN == 1)

/* Exported defines.
 * ------------------------------------------------------------------------------------------------
 */
/* SPI 引脚配置（可在 user_config.h 中覆盖） */
#ifndef HOST_PORT_SPI_SCLK_PIN
#define HOST_PORT_SPI_SCLK_PIN                    12
#endif
#ifndef HOST_PORT_SPI_MOSI_PIN
#define HOST_PORT_SPI_MOSI_PIN                    11
#endif
#ifndef HOST_PORT_SPI_MISO_PIN
#define HOST_PORT_SPI_MISO_PIN                    13
#endif

#ifndef HOST_PORT_SPI_MAX_DEV_PER_BUS
#define HOST_PORT_SPI_MAX_DEV_PER_BUS             4
#endif
#ifndef HOST_PORT_SPI_MAX_TRANSFER_SZ
#define HOST_PORT_SPI_MAX_TRANSFER_SZ             (32 * 1024)
#endif

/* LLC bus_id 0 -> SPI2_HOST, 1 -> SPI3_HOST */
#define HOST_PORT_SPI_BUS_NUM                     2

/* Exported types.
 * ------------------------------------------------------------------------------------------------
 */
typedef struct {
    uint32_t cs_pin;
    spi_device_handle_t dev;
} host_spi_dev_entry_t;

typedef struct {
    spi_host_device_t host;
    bool is_init;
    uint32_t speed;
    host_spi_dev_entry_t devs[HOST_PORT_SPI_MAX_DEV_PER_BUS];
} host_spi_bus_ctx_t;

/* Exported constants.
 * ------------------------------------------------------------------------------------------------
 */
/* Exported variables.
 * ------------------------------------------------------------------------------------------------
 */
static host_spi_bus_ctx_t s_spi_buses[HOST_PORT_SPI_BUS_NUM];

/* Exported functions.
 * ------------------------------------------------------------------------------------------------
 */

static host_spi_bus_ctx_t *host_spi_ctx_get(uint8_t id)
{
    if (id >= HOST_PORT_SPI_BUS_NUM) {
        return NULL;
    }
    return &s_spi_buses[id];
}

static host_spi_dev_entry_t *host_spi_dev_find(host_spi_bus_ctx_t *ctx, uint32_t cs_pin)
{
    for (int i = 0; i < HOST_PORT_SPI_MAX_DEV_PER_BUS; i++) {
        if ((ctx->devs[i].cs_pin == cs_pin) && (ctx->devs[i].dev != NULL)) {
            return &ctx->devs[i];
        }
    }
    return NULL;
}

/* 总线上电：spi_bus_initialize */
static void *host_spi_init(uint8_t id, uint32_t speed, void *arg)
{
    host_spi_bus_ctx_t *ctx = host_spi_ctx_get(id);
    spi_bus_config_t buscfg;
    esp_err_t err;

    (void)arg;
    if ((ctx == NULL) || ctx->is_init) {
        return NULL;
    }

    ctx->host  = (id == 0) ? SPI2_HOST : SPI3_HOST;
    if (speed == 0) {
        ctx->speed = 8000000;
    } else if (speed > 80000000) {
        ctx->speed = 80000000;
    } else {
        ctx->speed = speed;
    }

    memset(&buscfg, 0, sizeof(buscfg));
    buscfg.sclk_io_num     = HOST_PORT_SPI_SCLK_PIN;
    buscfg.mosi_io_num     = HOST_PORT_SPI_MOSI_PIN;
    buscfg.miso_io_num     = HOST_PORT_SPI_MISO_PIN;
    buscfg.quadwp_io_num   = -1;
    buscfg.quadhd_io_num   = -1;
    buscfg.max_transfer_sz = HOST_PORT_SPI_MAX_TRANSFER_SZ;

    err = spi_bus_initialize(ctx->host, &buscfg, SPI_DMA_CH_AUTO);
    if (err != ESP_OK) {
        HOST_LOG_ERR("spi_bus_initialize(bus_id=%u) fail: %d\n", id, err);
        return NULL;
    }

    ctx->is_init = true;
    return ctx;
}

/* 总线下电：spi_bus_free */
static int host_spi_deinit(void *bus)
{
    host_spi_bus_ctx_t *ctx = (host_spi_bus_ctx_t *)bus;
    esp_err_t err;

    if ((ctx == NULL) || !ctx->is_init) {
        return HOST_ERRCODE_INVALID_PARAM;
    }
    err = spi_bus_free(ctx->host);
    if (err != ESP_OK) {
        return HOST_ERRCODE_IO_ERROR;
    }
    memset(ctx, 0, sizeof(*ctx));
    return HOST_ERRCODE_SUCCESS;
}

/* 设备打开：按 CS 引脚添加 SPI 设备（速度取总线当前值，支持烧录降速场景） */
static int host_spi_open(void *bus, uint32_t param)
{
    host_spi_bus_ctx_t *ctx = (host_spi_bus_ctx_t *)bus;
    spi_device_interface_config_t devcfg;
    host_spi_dev_entry_t *entry;
    esp_err_t err;
    uint32_t cs_pin = param;

    if ((ctx == NULL) || !ctx->is_init) {
        return HOST_ERRCODE_INVALID_PARAM;
    }

    /* 已存在的设备先移除，保证以最新总线速度重新创建 */
    entry = host_spi_dev_find(ctx, cs_pin);
    if (entry != NULL) {
        spi_bus_remove_device(entry->dev);
        entry->dev    = NULL;
        entry->cs_pin = 0;
    }

    /* 查找空槽位 */
    entry = NULL;
    for (int i = 0; i < HOST_PORT_SPI_MAX_DEV_PER_BUS; i++) {
        if (ctx->devs[i].dev == NULL) {
            entry = &ctx->devs[i];
            break;
        }
    }
    if (entry == NULL) {
        return HOST_ERRCODE_NO_BUFFER;
    }

    memset(&devcfg, 0, sizeof(devcfg));
    devcfg.clock_speed_hz = ctx->speed;
    devcfg.mode           = 0;
    devcfg.spics_io_num   = (int)cs_pin;
    devcfg.queue_size     = 8;
    devcfg.flags          = 0;

    err = spi_bus_add_device(ctx->host, &devcfg, &entry->dev);
    if (err != ESP_OK) {
        return HOST_ERRCODE_IO_ERROR;
    }
    entry->cs_pin = cs_pin;
    return HOST_ERRCODE_SUCCESS;
}

/* 设备关闭：移除 SPI 设备 */
static int host_spi_close(void *bus, uint32_t param)
{
    host_spi_bus_ctx_t *ctx = (host_spi_bus_ctx_t *)bus;
    host_spi_dev_entry_t *entry;

    if ((ctx == NULL) || !ctx->is_init) {
        return HOST_ERRCODE_INVALID_PARAM;
    }
    entry = host_spi_dev_find(ctx, param);
    if (entry == NULL) {
        return HOST_ERRCODE_SUCCESS;
    }
    spi_bus_remove_device(entry->dev);
    entry->dev    = NULL;
    entry->cs_pin = 0;
    return HOST_ERRCODE_SUCCESS;
}

/* 写数据（全双工事务，只关心 MOSI 输出）
 * @retval 成功返回实际发送字节数；失败返回 0
 *         （LLC_Send 以 >0 判定成功并累加字节数，不能返回 HOST_ERRCODE_*） */
static int host_spi_write(void *bus, uint32_t param, void *pbuff, uint32_t size)
{
    host_spi_bus_ctx_t *ctx = (host_spi_bus_ctx_t *)bus;
    host_spi_dev_entry_t *entry;
    spi_transaction_t t;
    esp_err_t err;

    if ((ctx == NULL) || (pbuff == NULL) || (size == 0)) {
        return 0;
    }
    if (size > HOST_PORT_SPI_MAX_TRANSFER_SZ) {
        HOST_LOG_ERR("%s: trans data size=%u too large! must less than %u\n", size, HOST_PORT_SPI_MAX_TRANSFER_SZ);
        return 0;
    }
    entry = host_spi_dev_find(ctx, param);
    if ((entry == NULL) || (entry->dev == NULL)) {
        return 0;
    }

    memset(&t, 0, sizeof(t));
    t.length    = size * 8;
    t.tx_buffer = pbuff;

    err = spi_device_transmit(entry->dev, &t);
    if (err != ESP_OK) {
        return 0;
    }
    return (int)size;
}

/* 读数据（从机只关心时钟，MOSI 置空闲电平即可）
 * @retval 成功返回实际读取字节数；失败返回 0
 *         （LLC_Recv 以 >0 判定成功并累加字节数） */
static int host_spi_read(void *bus, uint32_t param, void *pbuff, uint32_t size)
{
    host_spi_bus_ctx_t *ctx = (host_spi_bus_ctx_t *)bus;
    host_spi_dev_entry_t *entry;
    spi_transaction_t t;
    esp_err_t err;

    if ((ctx == NULL) || (pbuff == NULL) || (size == 0)) {
        return 0;
    }
    entry = host_spi_dev_find(ctx, param);
    if ((entry == NULL) || (entry->dev == NULL)) {
        return 0;
    }

    memset(&t, 0, sizeof(t));
    t.length    = size * 8;
    t.tx_buffer = NULL;
    t.rx_buffer = pbuff;

    err = spi_device_transmit(entry->dev, &t);
    if (err != ESP_OK) {
        return 0;
    }
    return (int)size;
}

/* SPI 总线操作集（LLC 层经 porting/port.c 的 porting_get_com_ops 转调本函数）。
 * 对齐 RS6x_7x_HIF_参考手册 5.1.2.5.7 / 5.1.2.5.8：
 * SPI 使用 EDGE 通知类型（表 5-31），只需常规接口，
 * read_finish / interrupt_ctrl / interrupt_handle_regist /
 * data_callback_regist 置 NULL（COM_ISR / COM_IRQ_THREAD 才需要）。 */
host_com_ops_t *porting_get_spi_com_ops(host_bus_type_t type, uint8_t id)
{
    static const host_com_ops_t s_spi_ops = {
        .init                     = host_spi_init,
        .deinit                   = host_spi_deinit,
        .open                     = host_spi_open,
        .close                    = host_spi_close,
        .write                    = host_spi_write,
        .read                     = host_spi_read,
        .read_finish              = NULL,
        .interrupt_ctrl           = NULL,
        .interrupt_handle_regist  = NULL,
        .data_callback_regist     = NULL,
    };

    if (type == HOST_BUS_TYPE_SPI && id < HOST_PORT_SPI_BUS_NUM) {
        return (host_com_ops_t *)&s_spi_ops;
    }
    return NULL;
}

#endif  /* CFG_HOST_PORT_COM_EN == 1 && CFG_HOST_PORT_COM_SPI_EN == 1 */

/*
 **************************************************************************************************
 * (C) COPYRIGHT POSSUMIC Technology
 * END OF FILE
 */
