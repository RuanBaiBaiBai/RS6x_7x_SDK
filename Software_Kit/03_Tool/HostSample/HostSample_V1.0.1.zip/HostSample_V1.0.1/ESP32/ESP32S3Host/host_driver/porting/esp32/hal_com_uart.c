/**
 **************************************************************************************************
 * @file    hal_com_uart.c
 * @brief   HAL COM (UART) porting for ESP-IDF：**中断接收（FIFO 中断）+ 内部环形缓冲**。
 * @note    LLC 层经 porting/port.c 的 porting_get_com_ops 转调本函数。
 *
 *          工作模型（中断接收，不用 DMA）：
 *          1. **UART RX 硬件中断**（esp_intr_alloc，FIFO 满阈值/空闲超时触发）：
 *             ISR 快进快出——清中断 + 把 FIFO 数据搬入内部环形缓冲（CPU 搬移，
 *             FIFO 永不堆积溢出）+ 唤醒事件任务/read 信号量，**不在 ISR 调 handler**；
 *          2. **COM 通知事件任务（COM_IRQ_THREAD 语义）**：handler（LLC 状态机 +
 *             llc_read memcpy + notify TL）在线程上下文调用，优先级须高于 hif_tl_task
 *             （否则 notify 后被抢占，rx_cache 未填充时 hif_tl_task 从环形缓冲直读，
 *             与 handler 填充 rx_cache 竞争导致数据错位 check32）；
 *          3. **read 只从环形缓冲取**：队列空时任务上下文阻塞等"数据就绪"信号量
 *             （让出 CPU 防 task_wdt），ISR 上下文直接返回 0；
 *          4. **read_finish**：队列仍有数据 -> 直接通知上层；队列已空 -> 置
 *             s_allow_notify=1（中断常开，无需重开，ISR 已搬空 FIFO）。
 *
 *          注意：UART0 被 console（REPL）占用，bus_id 0->UART_NUM_1、1->UART_NUM_2。
 *          引脚/波特率/缓冲/超时可在 user_config.h 中通过 HOST_PORT_UART_* 宏覆盖。
 * @attention
 *          Copyright (c) 2026 Possumic Technology. all rights reserved.
 **************************************************************************************************
 */

/* Includes.
 * ------------------------------------------------------------------------------------------------
 */
#include "host_port.h"
#include "host_llc_com_bus.h"

#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "driver/uart.h"
#include "hal/uart_ll.h"
#include "soc/interrupts.h"
#include "esp_intr_alloc.h"
#include "esp_attr.h"

#if (CFG_HOST_PORT_COM_EN == 1) && (CFG_HOST_PORT_COM_UART_EN == 1)

/* Exported defines.
 * ------------------------------------------------------------------------------------------------
 */
/* UART 引脚配置（可在 user_config.h 中覆盖） */
#ifndef HOST_PORT_UART_TX_PIN
#define HOST_PORT_UART_TX_PIN                    17
#endif
#ifndef HOST_PORT_UART_RX_PIN
#define HOST_PORT_UART_RX_PIN                    18
#endif

/* LLC bus_id: 0 -> UART_NUM_1, 1 -> UART_NUM_2（UART0 被 console 占用） */
#define HOST_PORT_UART_BUS_NUM                   2

/* bus_speed 传入 0 时的默认波特率 */
#ifndef HOST_PORT_UART_DEFAULT_BAUD
#define HOST_PORT_UART_DEFAULT_BAUD              115200
#endif

/* 内部 RX 环形缓冲大小（字节）。ISR 把 FIFO 数据搬入此缓冲，read 从这里取。
 * 需能吸收"TL report 队列满 -> 接收链阻塞"期间的积压（viz 推送慢时 hif_tl_task
 * 会阻塞在 HIF_TL_ReportQueuePut）；过小会回绕覆盖未消费数据（记 drop）。 */
#ifndef HOST_PORT_UART_RX_RING_SIZE
#define HOST_PORT_UART_RX_RING_SIZE              16384
#endif

/* RX FIFO 满中断触发阈值（字节）：FIFO 积压达该值即触发中断搬移（大流量及时清 FIFO）。 */
#ifndef HOST_PORT_UART_RX_FULL_THR
#define HOST_PORT_UART_RX_FULL_THR               32
#endif

/* UART 总线空闲超时（ms）：RX TOUT 中断触发阈值（帧结束/小数据判定）。
 * 换算为字符周期 = ms * baud / 10000（8N1，10 bit/字符）；115200 波特率下 3ms -> 34。
 * 取 3ms 降延迟——点云帧间隔 33~100ms（10~30Hz）远大于 3ms，帧内字节连续发送
 * （间隔 ~9us @115200）远小于 3ms，故 3ms 只在帧间触发、不拆帧。 */
#ifndef HOST_PORT_UART_RX_TOUT_MS
#define HOST_PORT_UART_RX_TOUT_MS                3
#endif

/* read 队列空时阻塞等"数据就绪"信号量的超时（ms）。
 * 注意：CONFIG_FREERTOS_HZ=100 时 1 tick=10ms，pdMS_TO_TICKS(1) 整数除法得 0
 * （非阻塞）会让 LLC 忙等空转触发 task_wdt——必须 >= 10ms（至少 1 tick）。 */
#ifndef HOST_PORT_UART_READ_WAIT_MS
#define HOST_PORT_UART_READ_WAIT_MS              10
#endif

/* COM 通知事件任务（栈/优先级）：COM_IRQ_THREAD 语义=handler 在线程上下文调用。
 * handler 内部 llc_read(memcpy 到 LLC rx_cache)+notify TL+LLC 状态机是重活，
 * 在 ISR 里直调会让 CPU 长时间被中断占用、IDLE 饿死触发 task_wdt——
 * 故 ISR 只搬 FIFO+唤醒，handler 由本任务（线程上下文）调用。栈用 8192。
 * 优先级必须高于 hif_tl_task（HOST_OS_THREAD_PRIO_HIGH=11）：handler 执行顺序是
 * 先 notify_callback(唤醒 hif_tl_task) 后 llc_read 填充 rx_cache——若本任务优先级
 * 低于 hif_tl_task，notify 后 hif_tl_task 会立即抢占本任务、在 rx_cache 尚未填充时
 * 从环形缓冲直读，随后本任务恢复又把同批数据填入 rx_cache，导致数据重复/错位
 * （check32 error）。故设为 12（>11），保证 handler 完整执行完再让 hif_tl_task 消费。 */
#ifndef HOST_PORT_UART_EVT_STACK
#define HOST_PORT_UART_EVT_STACK                 8192
#endif
#ifndef HOST_PORT_UART_EVT_PRIO
#define HOST_PORT_UART_EVT_PRIO                  12
#endif

/* RX 相关中断集合（FIFO 满 / 超时 / 溢出） */
#define HOST_UART_RX_INTR_MASK   (UART_INTR_RXFIFO_FULL | UART_INTR_RXFIFO_TOUT | UART_INTR_RXFIFO_OVF)

/* Exported types.
 * ------------------------------------------------------------------------------------------------
 */
typedef struct {
    uart_port_t port;
    uart_dev_t *hw;                     /* UART 硬件寄存器基址（UART_LL_GET_HW） */
    uint8_t *ring;                      /* 内部 RX 环形缓冲（init 动态分配） */
    uint32_t wr_pos;                    /* ISR 累计写入字节数（绝对值，模 ring_size 定位） */
    uint32_t rd_pos;                    /* read 累计消费字节数（绝对值） */
    SemaphoreHandle_t rx_data_sem;      /* "数据就绪"信号量：队列空时 read 阻塞等待（防 task_wdt） */
    TaskHandle_t evt_task;              /* COM 通知事件任务：handler 在线程上下文调用 */
    intr_handle_t intr_handle;          /* UART RX 中断句柄（esp_intr_alloc） */
    bool     open;                      /* 设备已打开 */
    bool     allow_notify;              /* s_allow_notify：允许通知上层（1=允许，0=通知后已清除） */
    uint32_t drop;                      /* 回绕覆盖丢弃计数（调试，上层消费严重滞后时增长） */
    bool     is_init;
    bool     exit_flag;
    uint32_t baud;
    host_com_interrupt_handler_t handler;   /* LLC 注册的中断处理（llc_interrupt_handle） */
    void *handler_arg;
} host_uart_bus_ctx_t;

/* Exported variables.
 * ------------------------------------------------------------------------------------------------
 */
static host_uart_bus_ctx_t s_uart_buses[HOST_PORT_UART_BUS_NUM];

/* COM 通知 handler 暂存：两个来源复用同一通道——
 * 1) LLC 在总线初始化之前（Host_Device_Regist 阶段）就会调用 interrupt_handle_regist，
 *    此时 HAL ctx 尚未创建（bus 未 open），先暂存到静态变量，待 host_uart_init
 *    创建 ctx 后绑定；
 * 2) host_uart_deinit 释放资源前把 ctx->handler 回填至此，保证 burn 流程
 *    deinit->reinit 后重新绑定（否则事件任务因 handler==NULL 永不 notify）。
 * 注：COM_IRQ_THREAD 场景通常单设备，多 UART 设备同时注册时以最后一次为准。 */
static host_com_interrupt_handler_t s_uart_pending_handler = NULL;
static void *s_uart_pending_arg = NULL;

/* Exported functions.
 * ------------------------------------------------------------------------------------------------
 */

static host_uart_bus_ctx_t *host_uart_ctx_get(uint8_t id)
{
    if (id >= HOST_PORT_UART_BUS_NUM) {
        return NULL;
    }
    return &s_uart_buses[id];
}

/* 把 UART FIFO 数据搬入内部环形缓冲（ISR/临界区上下文调用）。
 * 立即搬空 FIFO，确保 FIFO(128B) 永不堆积溢出丢字节；环形缓冲吸收突发。 */
static void host_uart_rx_push(host_uart_bus_ctx_t *ctx)
{
    host_os_critical_flag_t flag = host_os_enter_critical();
    uint32_t avail = uart_ll_get_rxfifo_len(ctx->hw);

    while (avail > 0) {
        uint32_t w = ctx->wr_pos % HOST_PORT_UART_RX_RING_SIZE;
        uint32_t space = HOST_PORT_UART_RX_RING_SIZE - w;   /* 到尾部连续空间 */
        uint32_t n = (avail < space) ? avail : space;

        uart_ll_read_rxfifo(ctx->hw, &ctx->ring[w], n);
        ctx->wr_pos += n;
        avail -= n;
        /* 回绕流控：未消费数据超缓冲容量 -> 丢最旧（rd_pos 前移），记 drop */
        if ((ctx->wr_pos - ctx->rd_pos) > HOST_PORT_UART_RX_RING_SIZE) {
            ctx->rd_pos = ctx->wr_pos - HOST_PORT_UART_RX_RING_SIZE;
            ctx->drop++;
        }
    }
    host_os_exit_critical(flag);
}

/* COM 通知事件任务（COM_IRQ_THREAD 语义：handler 在线程上下文调用）。
 * 队列有数据且允许通知（s_allow_notify）-> 调 handler（LLC 状态机 + llc_read memcpy
 * + notify TL），并置 s_allow_notify=0（一次通知一轮处理，read_finish 处理完再置 1）。
 * 与 ISR 解耦：ISR 快进快出（只搬 FIFO+唤醒），重活在本任务做，IDLE 不被饿死。 */
static void host_uart_evt_task(void *arg)
{
    host_uart_bus_ctx_t *ctx = (host_uart_bus_ctx_t *)arg;
    host_os_critical_flag_t flag;
    bool do_notify;

    while (1) {
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
        if (ctx->exit_flag) {
            vTaskDelete(NULL);
        }
        flag = host_os_enter_critical();
        do_notify = ((ctx != NULL) && ctx->open && ctx->allow_notify &&
                     (ctx->handler != NULL) && (ctx->wr_pos - ctx->rd_pos > 0));
        if (do_notify) {
            ctx->allow_notify = false;
        }
        host_os_exit_critical(flag);
        if (do_notify) {
            ctx->handler(ctx->handler_arg);     /* 线程上下文调 LLC handler（重活） */
        }
    }
}

/* UART RX 中断（数据到达，真实硬件中断）：清中断 -> 搬 FIFO 入环形缓冲 -> 唤醒
 * 事件任务/read 信号量。**快进快出，不在 ISR 调 handler**（handler 重活由事件任务
 * 在线程上下文做，避免 ISR 长时间占用 CPU 饿死 IDLE 触发 task_wdt）。
 * ISR 上下文：只做 ISR 安全操作（寄存器 + 缓冲搬移 + FromISR 唤醒）。 */
static void IRAM_ATTR host_uart_isr(void *arg)
{
    host_uart_bus_ctx_t *ctx = (host_uart_bus_ctx_t *)arg;
    BaseType_t hpw = pdFALSE;
    BaseType_t hpw2 = pdFALSE;
    uint32_t intr;

    if ((ctx == NULL) || (ctx->hw == NULL)) {
        return;
    }
    intr = uart_ll_get_intraw_mask(ctx->hw);
    if ((intr & HOST_UART_RX_INTR_MASK) == 0) {
        return;
    }
    /* 写 1 清除中断标志（W1C） */
    ctx->hw->int_clr.val = intr & HOST_UART_RX_INTR_MASK;
    /* FIFO 溢出：读空残留数据丢弃，避免旧数据干扰后续帧（溢出本身已丢数据，
     * 由上层 TL 重传/校验兜底） */
    if (intr & UART_INTR_RXFIFO_OVF) {
        while (uart_ll_get_rxfifo_len(ctx->hw) > 0) {
            uint8_t tmp;
            uart_ll_read_rxfifo(ctx->hw, &tmp, 1);
        }
    }
    /* 搬空 FIFO 到内部环形缓冲（CPU 搬移，FIFO 不堆积） */
    host_uart_rx_push(ctx);

    /* 唤醒 read 阻塞等待（数据就绪） */
    if (ctx->rx_data_sem != NULL) {
        xSemaphoreGiveFromISR(ctx->rx_data_sem, &hpw2);
        hpw |= hpw2;
    }
    /* 唤醒事件任务调 handler（COM_IRQ_THREAD 线程上下文） */
    if (ctx->evt_task != NULL) {
        vTaskNotifyGiveFromISR(ctx->evt_task, &hpw2);
        hpw |= hpw2;
    }
    if (hpw == pdTRUE) {
        portYIELD_FROM_ISR();
    }
}

/* 总线上电：配置 UART（不装 driver）+ UART RX 中断 + 事件任务 */
static void *host_uart_init(uint8_t id, uint32_t speed, void *arg)
{
    host_uart_bus_ctx_t *ctx = host_uart_ctx_get(id);
    uart_config_t ucfg;
    uint32_t tout_chars;
    esp_err_t err;

    (void)arg;
    if ((ctx == NULL) || ctx->is_init) {
        return NULL;
    }
    if (speed != 0 && (speed < 9600 || speed > 4000000)) {
        HOST_LOG_ERR("uart baud=%u out of range(9600~4000000)!\n", speed);
        return NULL;
    }

    memset(ctx, 0, sizeof(*ctx));
    ctx->port = (id == 0) ? UART_NUM_1 : UART_NUM_2;
    ctx->baud = (speed == 0) ? HOST_PORT_UART_DEFAULT_BAUD : speed;
    ctx->hw   = UART_LL_GET_HW(ctx->port);

    /* 1) 配置 UART（引脚/波特率，不安装 uart driver，纯中断裸操作） */
    memset(&ucfg, 0, sizeof(ucfg));
    ucfg.baud_rate  = (int)ctx->baud;
    ucfg.data_bits  = UART_DATA_8_BITS;
    ucfg.parity     = UART_PARITY_DISABLE;
    ucfg.stop_bits  = UART_STOP_BITS_1;
    ucfg.flow_ctrl  = UART_HW_FLOWCTRL_DISABLE;
    ucfg.source_clk = UART_SCLK_DEFAULT;

    err = uart_param_config(ctx->port, &ucfg);
    if (err == ESP_OK) {
        err = uart_set_pin(ctx->port, HOST_PORT_UART_TX_PIN, HOST_PORT_UART_RX_PIN,
                           UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
    }
    if (err != ESP_OK) {
        HOST_LOG_ERR("uart param/pin config(port=%d) fail: %d\n", ctx->port, err);
        return NULL;
    }

    /* 2) RX 触发阈值：FIFO 满阈值（大流量及时搬）+ 空闲超时 3ms（帧结束判定） */
    uart_ll_set_rxfifo_full_thr(ctx->hw, HOST_PORT_UART_RX_FULL_THR);
    tout_chars = (uint32_t)(((uint64_t)HOST_PORT_UART_RX_TOUT_MS * ctx->baud) / 10000u);
    if (tout_chars < 1) {
        tout_chars = 1;
    } else if (tout_chars > 1023) {
        tout_chars = 1023;
    }
    uart_ll_set_rx_tout(ctx->hw, tout_chars);

    /* 3) 分配内部 RX 环形缓冲与"数据就绪"信号量 */
    ctx->ring = heap_caps_malloc(HOST_PORT_UART_RX_RING_SIZE, MALLOC_CAP_8BIT);
    if (ctx->ring == NULL) {
        HOST_LOG_ERR("alloc uart rx ring fail(port=%d, size=%d)\n",
                     ctx->port, HOST_PORT_UART_RX_RING_SIZE);
        return NULL;
    }
    ctx->rx_data_sem = xSemaphoreCreateBinary();
    if (ctx->rx_data_sem == NULL) {
        HOST_LOG_ERR("create uart rx sem fail(port=%d)\n", ctx->port);
        heap_caps_free(ctx->ring);
        ctx->ring = NULL;
        return NULL;
    }
    ctx->wr_pos = 0;
    ctx->rd_pos = 0;

    /* 4) UART RX 中断（数据到达搬 FIFO）：默认关闭，open 时才使能 */
    uart_ll_disable_intr_mask(ctx->hw, UART_LL_INTR_MASK);
    while (uart_ll_get_rxfifo_len(ctx->hw) > 0) {   /* 清空 FIFO 残留 */
        uint8_t tmp;
        uart_ll_read_rxfifo(ctx->hw, &tmp, 1);
    }
    err = esp_intr_alloc(
        (ctx->port == UART_NUM_1) ? ETS_UART1_INTR_SOURCE : ETS_UART2_INTR_SOURCE,
        ESP_INTR_FLAG_LEVEL1,
        host_uart_isr, ctx, &ctx->intr_handle);
    if (err != ESP_OK) {
        HOST_LOG_ERR("esp_intr_alloc(port=%d) fail: %d\n", ctx->port, err);
        vSemaphoreDelete(ctx->rx_data_sem);
        ctx->rx_data_sem = NULL;
        heap_caps_free(ctx->ring);
        ctx->ring = NULL;
        return NULL;
    }
    uart_ll_disable_intr_mask(ctx->hw, HOST_UART_RX_INTR_MASK);

    /* 5) COM 通知事件任务（COM_IRQ_THREAD 语义：handler 在线程上下文调用，固定 core1） */
    if (xTaskCreatePinnedToCore(host_uart_evt_task, "uart_evt", HOST_PORT_UART_EVT_STACK,
                                ctx, HOST_PORT_UART_EVT_PRIO, &ctx->evt_task, 1) != pdPASS) {
        HOST_LOG_ERR("create uart evt task fail(port=%d)\n", ctx->port);
        esp_intr_free(ctx->intr_handle);
        ctx->intr_handle = NULL;
        vSemaphoreDelete(ctx->rx_data_sem);
        ctx->rx_data_sem = NULL;
        heap_caps_free(ctx->ring);
        ctx->ring = NULL;
        return NULL;
    }

    ctx->is_init = true;
    ctx->exit_flag = false;

    /* 绑定暂存的 COM 通知 handler（两个来源：LLC 在设备注册阶段（Host_Device_Regist）
     * 经 interrupt_handle_regist 早先注册的；或 deinit 时回填的，保证 burn 流程
     * deinit->reinit 后 handler 不丢失） */
    ctx->handler     = s_uart_pending_handler;
    ctx->handler_arg = s_uart_pending_arg;
    s_uart_pending_handler = NULL;
    s_uart_pending_arg     = NULL;

    return ctx;
}

/* 总线下电：关中断并释放中断/事件任务/信号量/缓冲 */
static int host_uart_deinit(void *bus)
{
    host_uart_bus_ctx_t *ctx = (host_uart_bus_ctx_t *)bus;

    if ((ctx == NULL) || !ctx->is_init) {
        return HOST_ERRCODE_INVALID_PARAM;
    }
    ctx->open = false;
    uart_ll_disable_intr_mask(ctx->hw, UART_LL_INTR_MASK);
    if (ctx->intr_handle != NULL) {
        esp_intr_free(ctx->intr_handle);
        ctx->intr_handle = NULL;
    }
    if (ctx->evt_task != NULL) {
        ctx->exit_flag = true;
        xTaskNotifyGive(ctx->evt_task);
        for (int i = 0; i < 200; i++) {
            if (eTaskGetState(ctx->evt_task) == eDeleted) {
                ctx->evt_task = NULL;
                break;
            }
            vTaskDelay(pdMS_TO_TICKS(10));
        }
        if (ctx->evt_task != NULL) {
            vTaskDelete(ctx->evt_task);
            ctx->evt_task = NULL;
        }
    }
    if (ctx->rx_data_sem != NULL) {
        vSemaphoreDelete(ctx->rx_data_sem);
        ctx->rx_data_sem = NULL;
    }
    if (ctx->ring != NULL) {
        heap_caps_free(ctx->ring);
        ctx->ring = NULL;
    }
    /* 保存 COM 通知 handler 到暂存区，再清空 ctx：
     * LLC 只在设备注册/协议切换时经 interrupt_handle_regist 注册一次 handler，
     * 而 burn 流程（Host_BurnMode_Enter/Exit）会 Close 设备 -> dev_open_num==0 时
     * 触发总线级 deinit（本函数），随后重新 LLC_Device_Open -> host_uart_init 重建。
     * 若此处不暂存，重新 init 时 ctx->handler = s_uart_pending_handler（首次 init
     * 已取空 -> NULL），事件任务 do_notify 条件 ctx->handler != NULL 永不满足，
     * 退出 burn 后 UART 无法接收数据、命令响应也收不到。
     * 存回暂存区由 host_uart_init 重新绑定（burn 期间 HOST_BURN_Protocol_Init 会
     * 经 interrupt_handle_regist 再注册一次，故烧录本身不受影响）。 */
    s_uart_pending_handler = ctx->handler;
    s_uart_pending_arg     = ctx->handler_arg;
    memset(ctx, 0, sizeof(*ctx));
    return HOST_ERRCODE_SUCCESS;
}

/* 设备打开：开启 UART RX 中断（等待数据到达搬 FIFO），允许通知。
 * 注意：打开前清空接收残留——UPD 引脚若与从机 UART TX 相连，burn exit 时
 * UPD/RST 翻转产生的电平变化会被 RX 当成假数据收进 FIFO；若不清理，数据入队
 * 触发一次 notify（allow_notify=false）后，burn 流程不会调 read_finish 恢复，
 * 导致之后从机真实数据也不再 notify（不自动接收）。open 恰在假数据之后、
 * 真实数据之前执行，清残留即根治。 */
static int host_uart_open(void *bus, uint32_t param)
{
    host_uart_bus_ctx_t *ctx = (host_uart_bus_ctx_t *)bus;

    (void)param;
    if ((ctx == NULL) || !ctx->is_init) {
        return HOST_ERRCODE_INVALID_PARAM;
    }
    /* 清 FIFO 残留（读空，中断此时已关闭，无并发） */
    while (uart_ll_get_rxfifo_len(ctx->hw) > 0) {
        uint8_t tmp;
        uart_ll_read_rxfifo(ctx->hw, &tmp, 1);
    }
    /* 复位内部环形缓冲（绝对指针归零，丢弃残留假数据） */
    ctx->wr_pos = 0;
    ctx->rd_pos = 0;
    ctx->open         = true;
    ctx->allow_notify = true;               /* s_allow_notify = 1：允许通知 */
    uart_ll_ena_intr_mask(ctx->hw, HOST_UART_RX_INTR_MASK);
    /* 注意：本函数可能在临界区（关中断）内被 LLC 调用（LLC_Device_Open 链路），
     * 严禁在此加 printf/HOST_LOG（newlib 递归锁在关中断上下文 abort）！ */
    return HOST_ERRCODE_SUCCESS;
}

/* 设备关闭：关闭 UART RX 中断 */
static int host_uart_close(void *bus, uint32_t param)
{
    host_uart_bus_ctx_t *ctx = (host_uart_bus_ctx_t *)bus;

    (void)param;
    if ((ctx == NULL) || !ctx->is_init) {
        return HOST_ERRCODE_INVALID_PARAM;
    }
    ctx->open = false;
    uart_ll_disable_intr_mask(ctx->hw, HOST_UART_RX_INTR_MASK);
    return HOST_ERRCODE_SUCCESS;
}

/* 写数据：FIFO 直写（ISR 安全，写满 TX FIFO 则忙等空间）。
 * @retval 成功返回发送字节数；失败返回 0（LLC_Send 以 >0 判定） */
static int host_uart_write(void *bus, uint32_t param, void *pbuff, uint32_t size)
{
    host_uart_bus_ctx_t *ctx = (host_uart_bus_ctx_t *)bus;
    const uint8_t *data = (const uint8_t *)pbuff;
    uint32_t written = 0;
    uint32_t space;

    (void)param;
    if ((ctx == NULL) || (pbuff == NULL) || (size == 0)) {
        return 0;
    }
    while (written < size) {
        space = uart_ll_get_txfifo_len(ctx->hw);
        if (space == 0) {
            continue;                       /* TX FIFO 满：忙等（发送数据量小，可接受） */
        }
        if (space > (size - written)) {
            space = size - written;
        }
        uart_ll_write_txfifo(ctx->hw, &data[written], space);
        written += space;
    }
    return (int)written;
}

/* 读数据：**只从环形缓冲取**（ISR 已把 FIFO 数据搬入 ring，绝不直读 FIFO）。
 * 队列空时：任务上下文（hif_tl_task 经 LLC_Recv 调用）短暂阻塞等"数据就绪"信号量
 * （让出 CPU，避免 LLC 简单路径 while 忙等空转触发 task_wdt）；ISR 上下文
 * （中断->handler->LLC 链路）直接返回 0（不能阻塞）。
 * @retval 成功返回实际读取字节数；队列空返回 0（LLC_Recv 以 >0 判定） */
static int host_uart_read(void *bus, uint32_t param, void *pbuff, uint32_t size)
{
    host_uart_bus_ctx_t *ctx = (host_uart_bus_ctx_t *)bus;
    host_os_critical_flag_t flag;
    uint32_t avail, n, first;
    uint8_t *dst = (uint8_t *)pbuff;

    (void)param;
    if ((ctx == NULL) || (pbuff == NULL) || (size == 0)) {
        return 0;
    }

    /* 第 1 次尝试：临界区内"判断 + 预留 pos"，临界区外再 memcpy。
     * 预留先行的原因：本环形缓冲有两个并发读者——UART 数据通知任务（evt_task）
     * 经 handler(LLC) 读，以及 burn/命令路径经 LLC_Recv 读。旧实现"取快照 -> memcpy
     * -> 更新 pos"三步之间互斥不完整：两个读者并发时都会取到同一块数据的快照
     * （pos 未前进），各自 memcpy 同一区间、pos 又各加一次，造成数据重复/瓜分、
     * rd_pos 越过 wr_pos。改为先在临界区内前进 rd_pos 预留本块，memcpy 区间即
     * 唯一归属当前读者，其余读者（含 ISR 追加 wr_pos）不会再触达，竞争消除。 */
    flag = host_os_enter_critical();
    avail = ctx->wr_pos - ctx->rd_pos;
    if (avail == 0) {
        /* 队列空：出临界区，任务上下文阻塞等 rx_data_sem（ISR 搬入 FIFO 后
         * give 唤醒，给 ISR 完成搬移的时间）；ISR 上下文不能阻塞，直接返回 0 */
        host_os_exit_critical(flag);
        if (!xPortInIsrContext() && (ctx->rx_data_sem != NULL)) {
            xSemaphoreTake(ctx->rx_data_sem, pdMS_TO_TICKS(HOST_PORT_UART_READ_WAIT_MS));
        }
        /* 第 2 次尝试：等信号量后仍无数据 -> 出临界区直接返回 0 */
        flag = host_os_enter_critical();
        avail = ctx->wr_pos - ctx->rd_pos;
        if (avail == 0) {
            host_os_exit_critical(flag);
            return 0;
        }
    }
    n = (size < avail) ? size : avail;
    first = ctx->rd_pos % HOST_PORT_UART_RX_RING_SIZE;
    ctx->rd_pos += n;               /* 预留：pos 先前进，本块只归当前读者 */
    host_os_exit_critical(flag);

    /* 临界区外 memcpy（区间已预留：rd_pos 已越过本块，ISR 只追加 wr_pos 不触碰
     * 本区间，回绕保护仅在未消费数据超整环时丢最旧，正常流量不触发）。
     * 避免关中断做大块 memcpy 导致高优先级任务长时间占 CPU、IDLE 喂狗超时。 */
    if (n > 0) {
        if ((first + n) <= HOST_PORT_UART_RX_RING_SIZE) {
            memcpy(dst, &ctx->ring[first], n);
        } else {
            uint32_t tail = HOST_PORT_UART_RX_RING_SIZE - first;
            memcpy(dst, &ctx->ring[first], tail);
            memcpy(&dst[tail], &ctx->ring[0], n - tail);
        }
    }
    return (int)n;
}

/* 停止读取（上层 LLC 处理完一帧后调用）：
 * - 队列仍有数据 -> 直接通知上层（s_allow_notify 保持 0，不置 1）；
 * - 队列已空     -> 置 s_allow_notify=1（中断常开：ISR 已搬空 FIFO，无需重开中断）。 */
static int host_uart_read_finish(void *bus, uint32_t param)
{
    host_uart_bus_ctx_t *ctx = (host_uart_bus_ctx_t *)bus;
    host_os_critical_flag_t flag;
    bool has_data;

    (void)param;
    if ((ctx == NULL) || !ctx->is_init) {
        return HOST_ERRCODE_INVALID_PARAM;
    }

    flag = host_os_enter_critical();
    has_data = (ctx->wr_pos - ctx->rd_pos > 0);
    // host_os_exit_critical(flag);

    /* 置 s_allow_notify=1，允许下一次数据入队时通知（中断一直开着） */
    // flag = host_os_enter_critical();
    ctx->allow_notify = true;
    host_os_exit_critical(flag);

    if (has_data) {
        /* 队列有数据：直接通知上层处理 */
        if (ctx->evt_task != NULL) {
            xTaskNotifyGive(ctx->evt_task);
        }
        /* 注意：本函数可能在临界区（关中断）内被 LLC 调用（LLC_Device_Recv_Finish
         * 链路），严禁在此加 printf/HOST_LOG（newlib 递归锁在关中断上下文 abort）！ */
        return HOST_ERRCODE_SUCCESS;
    }

    return HOST_ERRCODE_SUCCESS;
}

/* 注册 RX 数据到达处理（LLC 在设备打开时注册 llc_interrupt_handle）。
 * 注意：LLC 可能在总线初始化之前（Host_Device_Regist 阶段）就调用本函数，
 * 此时 bus 参数可能为 NULL（HAL ctx 未创建）——暂存到静态变量，
 * 由 host_uart_init 创建 ctx 后绑定，不能直接返回错误。 */
static int host_uart_int_handle_regist(void *bus, host_com_interrupt_handler_t handler, void *arg)
{
    host_uart_bus_ctx_t *ctx = (host_uart_bus_ctx_t *)bus;

    if ((ctx != NULL) && ctx->is_init) {
        ctx->handler     = handler;
        ctx->handler_arg = arg;
    } else {
        /* bus 未 init：暂存，等 init 后绑定 */
        s_uart_pending_handler = handler;
        s_uart_pending_arg     = arg;
    }
    return HOST_ERRCODE_SUCCESS;
}

/* UART 总线操作集（LLC 层经 porting/port.c 的 porting_get_com_ops 转调本函数）。
 * - interrupt_ctrl 不注册（置 NULL）：LLC 走"简单路径"；
 * - 通知 = UART RX 中断 -> 搬 FIFO 入环形缓冲 -> 唤醒事件任务调 handler（线程上下文，
 *   s_allow_notify 门控）；
 * - read_finish 按队列剩余决定"直接通知"还是"置 allow_notify=1"（中断常开）；
 * - read 只从 16KB 内部环形缓冲取（ISR 中断搬移，不用 DMA）；
 * - data_callback_regist 当前 LLC 未使用，置 NULL。 */
host_com_ops_t *porting_get_uart_com_ops(host_bus_type_t type, uint8_t id)
{
    static const host_com_ops_t s_uart_ops = {
        .init                     = host_uart_init,
        .deinit                   = host_uart_deinit,
        .open                     = host_uart_open,
        .close                    = host_uart_close,
        .write                    = host_uart_write,
        .read                     = host_uart_read,
        .read_finish              = host_uart_read_finish,
        .interrupt_ctrl           = NULL,
        .interrupt_handle_regist  = host_uart_int_handle_regist,
        .data_callback_regist     = NULL,
    };

    if (type == HOST_BUS_TYPE_UART && id < HOST_PORT_UART_BUS_NUM) {
        return (host_com_ops_t *)&s_uart_ops;
    }
    return NULL;
}

#endif  /* CFG_HOST_PORT_COM_EN == 1 && CFG_HOST_PORT_COM_UART_EN == 1 */

/*
 **************************************************************************************************
 * (C) COPYRIGHT POSSUMIC Technology
 * END OF FILE
 **************************************************************************************************
 */
