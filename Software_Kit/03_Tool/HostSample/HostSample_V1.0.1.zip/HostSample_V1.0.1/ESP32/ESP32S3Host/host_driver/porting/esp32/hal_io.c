/**
 **************************************************************************************************
 * @file    hal_io.c
 * @brief   HAL IO porting for ESP-IDF (GPIO control & notify interrupt).
 * @note    notify_io 的中断回调直接注册为 GPIO ISR handler
 *          （gpio_isr_handler_add），即回调在中断上下文执行：
 *          - 回调链（llc_notify_io_irq_handle → notify_callback → host_os_sem_give）
 *            只做 ISR 安全操作，满足直接回调要求；
 *          - 中断触发方式：host_io_mode_set 在 INTERRUPT 模式下按上下拉
 *            设置默认边沿（PULL_DOWN → 上升沿），保证驱动
 *            LLC_IO_Notify_Irq_Control 的 enable 路径（只调 mode_set +
 *            irq_enable，无 irq_cfg）也能触发中断；host_io_irq_cfg 的
 *            trig 再直接映射覆盖为精确类型（POSEDGE/NEGEDGE/ANYEDGE/
 *            HIGH_LEVEL/LOW_LEVEL）。
 *          - 休眠 WKIO（is_wkio=true）当前不支持，返回 HOST_ERRCODE_UNSUPPORT。
 * @attention
 *          Copyright (c) 2026 Possumic Technology. all rights reserved.
 **************************************************************************************************
 */

/* Includes.
 * ------------------------------------------------------------------------------------------------
 */
#include "host_port.h"

#include "driver/gpio.h"

#if (CFG_HOST_PORT_IO_EN == 1)

/* Exported defines.
 * ------------------------------------------------------------------------------------------------
 */
/* Exported types.
 * ------------------------------------------------------------------------------------------------
 */
/* Exported constants.
 * ------------------------------------------------------------------------------------------------
 */
/* Exported variables.
 * ------------------------------------------------------------------------------------------------
 */
/* Exported functions.
 * ------------------------------------------------------------------------------------------------
 */

int host_io_mode_set(uint32_t io, host_io_mode_t mode, host_io_pull_t pull, bool is_wkio)
{
    esp_err_t status = ESP_OK;

    if (is_wkio) {
        return HOST_ERRCODE_UNSUPPORT;
    } else {
        if (io >= GPIO_NUM_MAX) {
            HOST_LOG_ERR("%s: io=%u is invalid!\n", __func__, io);
            return HOST_ERRCODE_INVALID_PARAM;
        }
        gpio_config_t config = {
            .pin_bit_mask  = (1ULL << io),
            .mode          = GPIO_MODE_DISABLE,
            .pull_up_en    = GPIO_PULLUP_DISABLE,
            .intr_type     = GPIO_INTR_DISABLE,
#if SOC_GPIO_SUPPORT_PIN_HYS_FILTER
            .hys_ctrl_mode = GPIO_HYS_SOFT_DISABLE,
#endif
        };
        if (mode == HOST_IO_MODE_DISABLE) {
            // do noting
        } else if (mode == HOST_IO_MODE_OUTPUT) {
            config.mode = GPIO_MODE_OUTPUT;
        } else if (mode == HOST_IO_MODE_INPUT) {
            config.mode = GPIO_MODE_INPUT;
        } else if (mode == HOST_IO_MODE_INTERRUPT) {
            /* 中断引脚按输入模式配置；触发方式默认按上下拉决定
             * （PULL_DOWN → 上升沿，否则 → 下降沿）。
             * 注意：驱动 LLC_IO_Notify_Irq_Control 的 enable 路径只调
             * host_io_mode_set + host_io_irq_enable（无 irq_cfg），
             * 因此这里必须设置 intr_type，否则中断永远不会触发；
             * 显式触发类型（如 EDGE_BOTH/LEVEL）由 host_io_irq_cfg
             * 在 gpio_set_intr_type 中覆盖。 */
            config.mode = GPIO_MODE_INPUT;
            if (pull == HOST_IO_PULL_DOWN) {
                config.intr_type = GPIO_INTR_POSEDGE;
            } else {
                config.intr_type = GPIO_INTR_NEGEDGE;
            }
        } else {
            HOST_LOG_ERR("%s: mode=%d is invalid!\n", __func__, mode);
            return HOST_ERRCODE_INVALID_PARAM;
        }
        if (pull == HOST_IO_PULL_NO) {
            // do noting
        } else if (pull == HOST_IO_PULL_UP) {
            config.pull_up_en = GPIO_PULLUP_ENABLE;
        } else if (pull == HOST_IO_PULL_DOWN) {
            config.pull_down_en = GPIO_PULLDOWN_ENABLE;
        } else {
            HOST_LOG_ERR("%s: pull=%d is invalid!\n", __func__, pull);
            return HOST_ERRCODE_INVALID_PARAM;
        }
        status = gpio_config(&config);
    }

    return (status == ESP_OK) ? HOST_ERRCODE_SUCCESS : HOST_ERRCODE_IO_ERROR;
}

void host_io_write(uint32_t io, host_io_value_t value, bool is_wkio)
{
    esp_err_t status = ESP_OK;

    if (is_wkio) {
        return ;
    } else {
        status = gpio_set_level((gpio_num_t)io, (value == HOST_IO_VALUE_LOW) ? 0 : 1);
        if (status != ESP_OK) {
            HOST_LOG_ERR("%s: set IO%u to %s fail(%d)\n",
                __func__, io, (value == HOST_IO_VALUE_LOW) ? "LOW" : "HIGH", status);
            return ;
        }
    }
}

host_io_value_t host_io_read(uint32_t io, bool is_wkio)
{
    if (is_wkio) {
        HOST_LOG_ERR("%s: is_wkio unsupport!\n", __func__);
        return HOST_IO_VALUE_LOW;
    } else {
        return (gpio_get_level(io) == 1) ? HOST_IO_VALUE_HIGH : HOST_IO_VALUE_LOW;
    }
}

static void ensure_isr_service_installed(void)
{
    static bool installed = false;
    esp_err_t status;

    if (!installed) {
        status = gpio_install_isr_service(0);
        if ((status != ESP_OK) && (status != ESP_ERR_INVALID_STATE)) {
            HOST_LOG_ERR("%s: gpio_install_isr_service fail(%d)\n", __func__, status);
            return ;
        }
        installed = true;
    }
}

int host_io_irq_cfg(uint32_t io, host_io_irq_trig_t trig, host_io_irq_callback_t pcallback, void *arg, bool is_wkio)
{
    esp_err_t status = ESP_OK;
    gpio_int_type_t int_type;
    host_io_pull_t pull;

    if (is_wkio) {
        return HOST_ERRCODE_UNSUPPORT;
    }
    if (pcallback == NULL) {
        HOST_LOG_ERR("%s: pcallback is NULL!\n", __func__);
        return HOST_ERRCODE_INVALID_PARAM;
    }

    /* trig 直接映射为 GPIO 中断类型（与 SDK 参考实现 event=trig 对齐） */
    switch (trig) {
    case HOST_IO_IRQ_EDGE_RISING:
        int_type = GPIO_INTR_POSEDGE;
        pull     = HOST_IO_PULL_DOWN;
        break;
    case HOST_IO_IRQ_EDGE_FALLING:
        int_type = GPIO_INTR_NEGEDGE;
        pull     = HOST_IO_PULL_UP;
        break;
    case HOST_IO_IRQ_EDGE_BOTH:
        int_type = GPIO_INTR_ANYEDGE;
        pull     = HOST_IO_PULL_DOWN;
        break;
    case HOST_IO_IRQ_LEVEL_HIGH:
        int_type = GPIO_INTR_HIGH_LEVEL;
        pull     = HOST_IO_PULL_DOWN;
        break;
    case HOST_IO_IRQ_LEVEL_LOW:
        int_type = GPIO_INTR_LOW_LEVEL;
        pull     = HOST_IO_PULL_UP;
        break;
    default:
        HOST_LOG_ERR("%s: trig=%d is invalid!\n", __func__, trig);
        return HOST_ERRCODE_INVALID_PARAM;
    }

    int ret = host_io_mode_set(io, HOST_IO_MODE_INTERRUPT, pull, is_wkio);
    if (ret != HOST_ERRCODE_SUCCESS) {
        HOST_LOG_ERR("%s: set mode fail(%d)\n", __func__, ret);
        return ret;
    }

    ensure_isr_service_installed();

    do {
        status = gpio_isr_handler_remove(io);
        if (status != ESP_OK) {
            HOST_LOG_ERR("%s: remove IO%d last isr handler fail(%d)\n", __func__, io, status);
            break;
        }

        status = gpio_isr_handler_add(io, pcallback, arg);
        if (status != ESP_OK) {
            HOST_LOG_ERR("%s: add IO%d isr handler fail(%d)\n", __func__, io, status);
            break;
        }

        status = gpio_set_intr_type(io, int_type);
        if (status != ESP_OK) {
            HOST_LOG_ERR("%s: set IO%d intr type fail(%d)\n", __func__, io, status);
            break;
        }

        status = gpio_intr_disable(io);
        if (status != ESP_OK) {
            HOST_LOG_ERR("%s: disable IO%d intr fail(%d)\n", __func__, io, status);
            break;
        }
    } while (0);

    return (status == ESP_OK) ? HOST_ERRCODE_SUCCESS : HOST_ERRCODE_IO_ERROR;
}

int host_io_irq_enable(uint32_t io, bool is_wkio)
{
    esp_err_t status = ESP_OK;

    if (is_wkio) {
        return HOST_ERRCODE_UNSUPPORT;
    } else {
        status = gpio_intr_enable(io);
    }

    return (status == ESP_OK) ? HOST_ERRCODE_SUCCESS : HOST_ERRCODE_IO_ERROR;
}

int host_io_irq_disable(uint32_t io, bool is_wkio)
{
    esp_err_t status = ESP_OK;

    if (is_wkio) {
        return HOST_ERRCODE_UNSUPPORT;
    } else {
        status = gpio_intr_disable(io);
    }

    return (status == ESP_OK) ? HOST_ERRCODE_SUCCESS : HOST_ERRCODE_IO_ERROR;
}

#endif  /* CFG_HOST_PORT_IO_EN == 1 */

/*
 **************************************************************************************************
 * (C) COPYRIGHT POSSUMIC Technology
 * END OF FILE
 */
