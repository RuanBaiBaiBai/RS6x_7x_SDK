/**
 **************************************************************************************************
 * @file    hal_os.c
 * @brief   HAL OS porting for ESP-IDF (FreeRTOS).
 * @attention
 *          Copyright (c) 2026 Possumic Technology. all rights reserved.
 **************************************************************************************************
 */

/* Includes.
 * ------------------------------------------------------------------------------------------------
 */
#include "host_port.h"

#include <stdlib.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_timer.h"
#include "esp_rom_sys.h"
#include "esp_heap_caps.h"

#if (CFG_HOST_PORT_OS_EN == 1)

/* PSRAM 分配阈值：申请大小超过此值时从 PSRAM 分配，否则从 SRAM 分配。
 * 100KB — 大帧缓冲（如点云数据）走 PSRAM，控制结构等小块走 SRAM。 */
#define HOST_OS_MALLOC_PSRAM_THRESHOLD  (100u * 1024u)

/* Types.
 * ------------------------------------------------------------------------------------------------
 */
/* Constants.
 * ------------------------------------------------------------------------------------------------
 */
/* Functions.
 * ------------------------------------------------------------------------------------------------
 */
host_os_critical_flag_t host_os_enter_critical(void)
{
    UBaseType_t saved = taskENTER_CRITICAL_FROM_ISR();
    return (host_os_critical_flag_t)saved;
}

void host_os_exit_critical(host_os_critical_flag_t flag)
{
    taskEXIT_CRITICAL_FROM_ISR((UBaseType_t)flag);
}

host_os_time_t host_os_timestamp_us(void)
{
    /* esp_timer_get_time() 返回 int64_t，截断为 uint32（约 71 分钟回绕），
     * host 侧按 32bit 差分包计算，符合使用场景 */
    return (host_os_time_t)esp_timer_get_time();
}

void * host_os_malloc(uint32_t size)
{
    /* 大块分配（>100KB）优先从 PSRAM 分配，PSRAM 不可用或已满时
     * 回退到 SRAM；小块分配走默认 malloc（内部 SRAM）。
     * free() 可正确释放 heap_caps_malloc 分配的内存（同一 heap 管理器）。 */
    if (size > HOST_OS_MALLOC_PSRAM_THRESHOLD) {
        void *p = heap_caps_malloc(size, MALLOC_CAP_SPIRAM);
        if (p != NULL) {
            return p;
        }
        /* PSRAM 分配失败（未开启 / 已满），回退到 SRAM */
    }
    /* ≤100KB：严格从内部 SRAM（DRAM）分配，不用裸 malloc——
     * CONFIG_SPIRAM_USE_MALLOC 下系统 malloc 对 >16KB（ALWAYSINTERNAL）
     * 的申请在 SRAM 不足时会落到 PSRAM，与"≤100KB 走 SRAM"语义不符。
     * 代价：SRAM 不足时返回 NULL（上层已有错误处理）。 */
    return heap_caps_malloc(size, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
}

void   host_os_free(void *pmem)
{
    free(pmem);
}

host_os_thread_handle_t host_os_thread_create(const char *pname,
                                              uint32_t stack_size,
                                              host_os_thread_entry_t entry,
                                              void *arg, int32_t prio)
{
    TaskHandle_t task = NULL;

    if (entry == NULL) {
        return NULL;
    }

    if (xTaskCreatePinnedToCore((TaskFunction_t)entry, pname, stack_size, arg,
                                (UBaseType_t)prio, &task, 1) != pdPASS) {
        return NULL;
    }
    return (host_os_thread_handle_t)task;
}

int host_os_thread_delete(host_os_thread_handle_t thread_hdl)
{
    if (thread_hdl != NULL) {
        vTaskDelete((TaskHandle_t)thread_hdl);
        return HOST_ERRCODE_SUCCESS;
    }
    return HOST_ERRCODE_INVALID_PARAM;
}

host_os_sem_t host_os_sem_create(uint32_t initial_count, uint32_t limit)
{
    if ((limit == 0) || (initial_count > limit)) {
        return NULL;
    }
    return (host_os_sem_t)xSemaphoreCreateCounting(limit, initial_count);
}

int host_os_sem_delete(host_os_sem_t psem)
{
    if (psem != NULL) {
        vSemaphoreDelete((SemaphoreHandle_t)psem);
        return HOST_ERRCODE_SUCCESS;
    }
    return HOST_ERRCODE_INVALID_PARAM;
}

int host_os_sem_is_valid(host_os_sem_t psem)
{
    return (psem != NULL) ? 1 : 0;
}

int host_os_sem_take(host_os_sem_t psem, host_os_timeout_t timeout)
{
    if (psem != NULL) {
        /* notify IO 回调可能在中断上下文调用（ISR 直接回调），
         * 先判断上下文再选对应 API：ISR 中无超时语义（立即尝试）。 */
        if (xPortInIsrContext()) {
            BaseType_t need_yield = pdFALSE;
            BaseType_t ret = xSemaphoreTakeFromISR((SemaphoreHandle_t)psem, &need_yield);
            if (ret == pdPASS) {
                portYIELD_FROM_ISR(need_yield);
                return HOST_ERRCODE_SUCCESS;
            }
            return HOST_ERRCODE_TIMEOUT;
        } else {
            TickType_t ticks;
            if (timeout == 0) {
                ticks = 0;
            } else if (timeout == HOST_OS_TIMEOUT_FOREVER) {
                ticks = portMAX_DELAY;
            } else {
                ticks = pdMS_TO_TICKS(timeout);
            }
            BaseType_t ret = xSemaphoreTake((SemaphoreHandle_t)psem, ticks);
            return (ret == pdPASS) ? HOST_ERRCODE_SUCCESS : HOST_ERRCODE_TIMEOUT;
        }
    } else {
        return HOST_ERRCODE_INVALID_HANDLE;
    }
}

int host_os_sem_give(host_os_sem_t psem)
{
    if (psem != NULL) {
        /* notify IO 回调可能在中断上下文调用（ISR 直接回调），
         * 中断上下文必须用 FromISR 版本并请求调度；任务上下文走普通版。 */
        if (xPortInIsrContext()) {
            BaseType_t need_yield = pdFALSE;
            BaseType_t ret = xSemaphoreGiveFromISR((SemaphoreHandle_t)psem, &need_yield);
            if (ret == pdPASS) {
                portYIELD_FROM_ISR(need_yield);
                return HOST_ERRCODE_SUCCESS;
            }
        } else {
            BaseType_t ret = xSemaphoreGive((SemaphoreHandle_t)psem);
            if (ret == pdPASS) {
                return HOST_ERRCODE_SUCCESS;
            }
        }
        return HOST_ERRCODE_IO_ERROR;
    } else {
        return HOST_ERRCODE_INVALID_HANDLE;
    }
}

int host_os_delayms(uint32_t ms)
{
    if (ms == 0) {
        taskYIELD();
    } else {
        uint32_t tick_ms = (uint32_t)portTICK_PERIOD_MS;
        uint32_t ticks = ms / tick_ms;          /* 整 tick 个数（vTaskDelay 部分） */
        uint32_t us    = (ms % tick_ms) * 1000; /* 不足一个 tick 的余数（精确忙等部分） */

        if (ticks > 0) {
            /* 整 tick 部分用 vTaskDelay 让出 CPU */
            vTaskDelay(ticks);
        }
        if (us > 0) {
            /* 余数部分用忙等精确补足，避免 pdMS_TO_TICKS 向下取整丢失
            * （如 CONFIG_FREERTOS_HZ=100 时 1ms -> 0 tick -> vTaskDelay(0) 仅 ~100us） */
            esp_rom_delay_us(us);
        }
    }
    return HOST_ERRCODE_SUCCESS;
}

int host_os_delayus(uint32_t us)
{
    if (us > 0) {
        if (us >= (uint32_t)portTICK_PERIOD_MS * 1000) {
            uint32_t ticks = us / 1000 / (uint32_t)portTICK_PERIOD_MS;
            us -= ticks * (uint32_t)portTICK_PERIOD_MS * 1000;
            vTaskDelay(ticks);
        }
        esp_rom_delay_us(us);
    }
    return HOST_ERRCODE_SUCCESS;
}

#endif  /* CFG_HOST_PORT_OS_EN == 1 */

/*
 **************************************************************************************************
 * (C) COPYRIGHT POSSUMIC Technology
 * END OF FILE
 */
