/**
 **************************************************************************************************
 * @file    hal_store.c
 * @brief   HAL store porting for ESP-IDF (image file access via stdio/VFS).
 * @note    通过标准 C 文件 API 访问烧录镜像。使用前需在应用中挂载
 *          文件系统（如 FATFS/SPIFFS）或使用已注册的 VFS 路径。
 * @attention
 *          Copyright (c) 2026 Possumic Technology. all rights reserved.
 **************************************************************************************************
 */

/* Includes.
 * ------------------------------------------------------------------------------------------------
 */
#include "host_port.h"

#include <stdio.h>

#if (CFG_HOST_PORT_STORE_EN == 1)

/* Functions.
 * ------------------------------------------------------------------------------------------------
 */
int host_store_open(void **hdl, void *path, uint32_t *len)
{
    FILE *fp;
    long fsize;

    if ((hdl == NULL) || (path == NULL) || (len == NULL)) {
        return HOST_ERRCODE_INVALID_PARAM;
    }

    fp = fopen((const char *)path, "rb");
    if (fp == NULL) {
        HOST_LOG_ERR("%s: open image(%s) fail\n", __func__, (const char *)path);
        return HOST_ERRCODE_NOT_FOUND;
    }

    if (fseek(fp, 0, SEEK_END) != 0) {
        fclose(fp);
        return HOST_ERRCODE_IO_ERROR;
    }
    fsize = ftell(fp);
    if (fsize < 0) {
        fclose(fp);
        HOST_LOG_ERR("%s: image too large or fseek fail\n", __func__);
        return HOST_ERRCODE_IO_ERROR;
    }
    if (fseek(fp, 0, SEEK_SET) != 0) {
        fclose(fp);
        return HOST_ERRCODE_IO_ERROR;
    }

    *hdl = fp;
    *len = (uint32_t)fsize;
    return HOST_ERRCODE_SUCCESS;
}

void host_store_close(void *hdl)
{
    if (hdl != NULL) {
        fclose((FILE *)hdl);
    }
}

int host_store_read(void *hdl, uint32_t offset, void *pbuff, uint32_t size)
{
    FILE *fp = (FILE *)hdl;
    size_t rd;

    if ((fp == NULL) || (pbuff == NULL)) {
        return HOST_ERRCODE_INVALID_PARAM;
    }

    if (fseek(fp, (long)offset, SEEK_SET) != 0) {
        return HOST_ERRCODE_IO_ERROR;
    }
    rd = fread(pbuff, 1, size, fp);
    if (rd != size) {
        return HOST_ERRCODE_IO_ERROR;
    }
    return HOST_ERRCODE_SUCCESS;
}

#endif  /* CFG_HOST_PORT_STORE_EN == 1 */

/*
 **************************************************************************************************
 * (C) COPYRIGHT POSSUMIC Technology
 * END OF FILE
 */
