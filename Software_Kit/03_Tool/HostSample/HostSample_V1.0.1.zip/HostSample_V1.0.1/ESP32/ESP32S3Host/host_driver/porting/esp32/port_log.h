/**
 **************************************************************************************************
 * @file    port_log.h
 * @brief   ESP-IDF log port for host_driver (PSIC port log).
 * @note    Referenced by hal_log.h via `#include CFG_HOST_PORT_LOG_FILE`.
 *          Default implementation redirects host_log_print() to the ESP-IDF
 *          console (vprintf). If timestamp/tag output is preferred, replace
 *          the body with ESP_LOG macros (requires the "log" component).
 * @attention
 *          Copyright (c) 2026 Possumic Technology. all rights reserved.
 **************************************************************************************************
 */

#ifndef _PORT_LOG_H_
#define _PORT_LOG_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>

#if (CFG_HOST_PORT_LOG_EN == 1)

/**
 * @brief Print a formatted log line (same semantics as printf).
 * @retval Number of characters printed, or a negative value on error.
 */
#define host_log_print printf

#endif /* CFG_HOST_PORT_LOG_EN == 1 */

#ifdef __cplusplus
}
#endif

#endif /* _PORT_LOG_H_ */
