/**
 **************************************************************************************************
 * @file    port.c
 * @brief   Host porting 统一入口：按总线类型把 ops 获取请求分发给各总线 HAL。
 * @note    各总线 HAL（hal_com_spi.c 等）只实现各自的 porting_get_<bus>_com_ops；
 *          LLC 层（host_llc.c）统一调用本文件的 porting_get_com_ops。
 *          新增总线时：在对应 hal 实现 porting_get_xxx_com_ops，并在本文件
 *          switch 中增加分发分支即可。
 * @attention
 *          Copyright (c) 2026 Possumic Technology. all rights reserved.
 **************************************************************************************************
 */

/* Includes.
 * ------------------------------------------------------------------------------------------------
 */
#include "host_port.h"
#include "host_llc_com_bus.h"

#if (CFG_HOST_PORT_COM_EN == 1)

/* 各总线 HAL 的 ops 获取函数声明（由对应 hal_*.c 提供） */
#if (CFG_HOST_PORT_COM_SPI_EN == 1)
extern host_com_ops_t *porting_get_spi_com_ops(host_bus_type_t type, uint8_t id);
#endif  /* CFG_HOST_PORT_COM_SPI_EN == 1 */
#if (CFG_HOST_PORT_COM_I2C_EN == 1)
extern host_com_ops_t *porting_get_i2c_com_ops(host_bus_type_t type, uint8_t id);
#endif  /* CFG_HOST_PORT_COM_I2C_EN == 1 */
#if (CFG_HOST_PORT_COM_UART_EN == 1)
extern host_com_ops_t *porting_get_uart_com_ops(host_bus_type_t type, uint8_t id);
#endif  /* CFG_HOST_PORT_COM_UART_EN == 1 */

/* 按总线类型获取操作集；对应总线 HAL 未实现时返回 NULL（LLC 注册该总线会失败） */
host_com_ops_t *porting_get_com_ops(host_bus_type_t type, uint8_t id)
{
    switch (type) {
#if (CFG_HOST_PORT_COM_SPI_EN == 1)
    case HOST_BUS_TYPE_SPI:
        return porting_get_spi_com_ops(type, id);
#endif  /* CFG_HOST_PORT_COM_SPI_EN == 1 */
#if (CFG_HOST_PORT_COM_I2C_EN == 1)
    case HOST_BUS_TYPE_I2C:
        return porting_get_i2c_com_ops(type, id);
#endif  /* CFG_HOST_PORT_COM_I2C_EN == 1 */
#if (CFG_HOST_PORT_COM_UART_EN == 1)
    case HOST_BUS_TYPE_UART:
        return porting_get_uart_com_ops(type, id);
#endif  /* CFG_HOST_PORT_COM_UART_EN == 1 */
    default:
        return NULL;
    }
}

#endif  /* CFG_HOST_PORT_COM_EN == 1 */

/*
 **************************************************************************************************
 * (C) COPYRIGHT POSSUMIC Technology
 * END OF FILE
 **************************************************************************************************
 */
