/**
 **************************************************************************************************
 * @file    user_config.h
 * @brief   user config files.
 * @attention
 *          Copyright (c) 2026 Possumic Technology. all rights reserved.
 **************************************************************************************************
 */

/* Define to prevent recursive inclusion.
 * ------------------------------------------------------------------------------------------------
 */
#ifndef __USER_CONFIG_H_
#define __USER_CONFIG_H_

#ifdef __cplusplus
extern "C" {
#endif


/* hal_log.h 通过 `#include CFG_HOST_PORT_LOG_FILE` 引用日志头文件：
 * 相对路径基于 hal_log.h 所在目录（porting/include/）解析，
 * "../esp32/port_log.h" 即 porting/esp32/port_log.h */
#define CFG_HOST_PORT_LOG_FILE                                      "../esp32/port_log.h"


#ifdef __cplusplus
}
#endif

#endif /* __USER_CONFIG_H_ */

