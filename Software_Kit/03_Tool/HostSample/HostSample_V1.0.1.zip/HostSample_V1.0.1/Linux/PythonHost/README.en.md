# Linux-PythonHost

[English](./README.en.md) | [中文](./README.md)

Radar data acquisition and visualization tool under Linux, written in Python, requiring Linux platform with Python 3.8 or above.

## I. Directory Overview

* res                                                                          Resources used by this README.md
* Scripts
  * MRS6240_mmWave_radar_spi_collect_data_linux-master        Data acquisition script
  - site-packages
    - gpio                                                   GPIO function library
    - PointCloudDisplay                          Point cloud visualization library
    - install.sh                                           Installation script for dependencies
    - requirements.txt                             Partial dependency list
- README.md                                                   This file

The data acquisition script calls `site-packages/gpio` and the Python library `spidev` for SPI data acquisition, and uses `site-packages/PointCloudDisplay` for data visualization.

## II. Installation and Porting

### 2.1 Check the Development Board Software Environment

First, check whether the development board has a Python environment. Enter the following command:

```
python -V
```

If you get a response similar to the following, Python is present:

```
Python 3.8.5
```

Note: Python version must be **3.8** or higher.

### 2.2 Check the Development Board Network Environment

Then check network connectivity to ensure that dependencies can be downloaded from the network. Enter the following command:

```
ping www.baidu.com -c 4
```

If you get a response similar to the following, the network connection is valid:

```
PING www.baidu.com (183.240.99.224): 56 data bytes
64 bytes from 183.240.99.224: seq=0 ttl=53 time=14.206 ms
64 bytes from 183.240.99.224: seq=1 ttl=53 time=14.335 ms
64 bytes from 183.240.99.224: seq=2 ttl=53 time=15.012 ms
64 bytes from 183.240.99.224: seq=3 ttl=53 time=14.564 ms
```

Next, check whether the device that will display real-time point clouds can ping the development board. Assume the development board IP is 192.168.137.100. On the device that will display the point clouds, ping the development board. If it is a Windows device, first press `Win+R` to open the Run window, type `cmd` and press Enter. In the opened command line window, enter:

```
ping 192.168.137.100
```

If you get a response similar to the following, the device can ping the development board:

```
正在 Ping 192.168.137.100 具有 32 字节的数据:
来自 192.168.137.100 的回复: 字节=32 时间<1ms TTL=64
来自 192.168.137.100 的回复: 字节=32 时间<1ms TTL=64
来自 192.168.137.100 的回复: 字节=32 时间<1ms TTL=64
来自 192.168.137.100 的回复: 字节=32 时间<1ms TTL=64

192.168.137.100 的 Ping 统计信息:
    数据包: 已发送 = 4，已接收 = 4，丢失 = 0 (0% 丢失)，
往返行程的估计时间(以毫秒为单位):
    最短 = 0ms，最长 = 0ms，平均 = 0ms
```

### 2.3 Check the Development Board SPI Configuration

Typically, the IOs used by SPI in the Linux device tree are configured with default and low‑power states. For easy porting, it is recommended to keep the pin configuration in the low‑power state to avoid IO level changes when the board enters low‑power mode, which could disrupt communication. For example, on the Zhengdian Atom STM32MP157‑Mini board, the default SPI pin low‑power configuration is as follows:

```
spi1_sleep_pins_a: spi1-sleep-0 {
    pins {
        pinmux = <STM32_PINMUX('Z', 0, ANALOG)>,  /* SPI1_SCK */
            <STM32_PINMUX('Z', 1, ANALOG)>,  /* SPI1_MISO */
            <STM32_PINMUX('Z', 2, ANALOG)>;  /* SPI1_MOSI */
    }
}
```

You need to modify the configuration of `SPI1_SCK` to:

```
<STM32_PINMUX('Z', 0, AF5)>
```

Also, set the slew‑rate of SCK and MOSI to 0 to reduce glitches that may affect communication.

Change:

```
spi1_pins_a: spi1-0 {
    pins1 {
        ...
        slew-rate = <1>
    }
    ...
}
```

to:

```
spi1_pins_a: spi1-0 {
    pins1 {
        ...
        slew-rate = <0>
    }
    ...
}
```

### 2.4 Check the Radar Base Board Hardware

#### 2.4.1 Solder Resistors R1, R4, R6, R8

These four 0Ω resistors connect the radar chip's SPI pins (PA0–PA3) to the 18‑pin header. They are not soldered by default; you need to solder them yourself (short with solder; 0Ω essentially acts as a wire).

#### 2.4.2 Solder a Header onto the 18‑pin Header Holes

To facilitate connecting signals via Dupont wires.

#### 2.4.3 Disconnect the CH347 USB Connection

The CH347 USB‑SPI bridge on the development board shares PA0–PA3 with the 18‑pin header. **The USB must be disconnected**, otherwise the CH347 and the host will contend for the SPI bus, causing MISO to read all 0xFF.

#### 2.4.4 Remove the VDD3V3 and VCC Jumpers

When using an external 3.3V supply, you need to disconnect the onboard LDO.

#### 2.4.5 Power the Radar from the Linux Development Board's 3.3V Pin

Linux development board 3.3V pin (Pin 1 or Pin 17) → radar 18‑pin header VCC (Pin 12).

### 2.5 Install Dependencies on the Development Board

Extract the compressed package and send it to the development board, then enter the extracted directory, where you can see the folder `Scripts` and the file `README.md`.

Enter the installation script directory:

```
cd Scripts/site-packages/
```

Install the dependencies:

```
./install.sh
```

### 2.6 Port the Data Acquisition Script to the Development Board

Go back to the extracted directory, where you can see the folder `Scripts` and the file `README.md`.

Enter the data acquisition script directory:

```
cd Scripts/MRS6240_mmWave_radar_spi_collect_data_linux-master/scripts/
```

In this directory, there is a file `collect_Tracking.py`. Modify the following content for porting:

```
# ═══════════════════════════════════════════════════════════════
# SPI / GPIO 硬件接口（STM32MP157）
# ═══════════════════════════════════════════════════════════════
GPIO_CHIP, INT_GPIO = 2, 0                      # gpiochip2, GPIO0 (中断引脚)
SPI_BUS, SPI_DEV, SPI_HZ = 0, 0, 10_000_000     # SPI1(devspi0), CS0, 10MHz
```

`GPIO_CHIP` and `INT_GPIO` select the GPIO connected to the radar's PA6. `GPIO_CHIP` is formatted in the `Radar` class `__init__` method as:

```
f"/dev/gpiochip{GPIO_CHIP}"
```

This string format follows the periphery library style.

`SPI_BUS`, `SPI_DEV`, and `SPI_HZ` set the SPI bus, SPI device number, and default SPI frequency, respectively.

The script starts a web server for data visualization. Modify the IP address in the following line to the development board's IP address:

```
ser = PCDServer('cartesian', '192.168.137.100', 5000)
```

## III. Using the Data Acquisition Script on the Development Board

Go back to the extracted directory, where you can see the folder `Scripts` and the file `README.md`.

Enter the data acquisition script directory:

```
cd Scripts/MRS6240_mmWave_radar_spi_collect_data_linux-master/scripts/
```

In this directory, there is a file `collect_Tracking.py`. Run the script:

```
python collect_Tracking.py --speed 10000000
```

The above command sets the SPI rate to 10 MHz. You can change the `10000000` value in the command to modify the SPI rate, provided that the development board and its firmware support the set rate.

After running the script, a web server starts and begins data acquisition. The web server is used for data visualization; currently, it only supports point cloud data (MsgID=0xC3). The script prints logs like the following:

```
  10.0 MHz  burst=256  按 Ctrl+C 停止

 * Serving Flask app 'PointCloudDisplay.server'
 * Debug mode: off
WARNING: This is a development server. Do not use it in a production deployment. Use a production WSGI server instead.
 * Running on http://192.168.137.100:5000
Press CTRL+C to quit
```

The URL in the log, `http://192.168.137.100:5000`, can be opened in a browser. Before opening, ensure that the device can ping the development board. After opening the URL, real‑time point cloud data will be displayed.

## IV. Visualization Interface

The computation and rendering of data visualization are entirely done on the Web Client; the development board only reports raw data in a specific format, so visualization does not significantly impact the development board.

The left side of the visualization interface is the function selection area, where you can enable SNR color display, show axis names, switch height axis, etc. The figure below shows a person standing and slightly swaying in front of the radar. Green represents lower SNR values, while red and yellow represent higher SNR values. The red/yellow areas are the point clouds corresponding to the human body.

![](./res/可视化界面.png)

SNR colors can be configured by clicking the `SNR Color Configuration` button at the lower left. The configuration window supports setting the number of color segments, maximum SNR value, colors for each segment, and SNR breakpoints. You can also export the SNR configuration and import it later.

![](./res/配置SNR颜色.png)

For example, to configure 6 SNR segments with a maximum SNR of 30, simply set the number of color segments to 6, set the maximum SNR value to 30, click `Equal Spacing`, which will automatically set the SNR breakpoints for each segment, and finally click `Apply`. If you need custom breakpoints, you can set them individually for each segment.

![](./res/配置SNR颜色6分段30dB.png)

## V. Data Publication Format

The script publishes data to the Web Client in the following format:

```
{
    "Type" : 4,
    "Flag" : ,
    "TotalLength" : ,
    "Point" : ,
}
```

`Type` is fixed to 4;

`Flag` 0 means polar coordinates, 1 means Cartesian coordinates;

`TotalLength` 0 means polar coordinates, 1 means Cartesian coordinates;

`Point` is a list of dictionaries, i.e., `[{}, {}, ...]`. Each dictionary has the following format:

```
{
    "range_or_x" : ,
    "azimath_or_y" : ,
    "elevation_or_z" : ,
    "velocity" : ,
    "snr" : ,
}
```

`range_or_x` x coordinate or range, in meters;

`azimath_or_y` y coordinate or azimuth, in meters or degrees;

`elevation_or_z` z coordinate or elevation, in meters or degrees;

`velocity` speed, can be in three formats: list, dictionary, or a single scalar, as follows:

```
List form:
[vx, vy, vz]

Dictionary form:
{
    "velocity_x" : vx ,
    "velocity_y" : vy ,
    "velocity_z" : vz ,
}

Scalar form:
v
```

`snr` SNR in dB.

## VI. Issues and Notes

### 6.1 Why does the visualization interface not show real‑time point clouds?

This can be affected by multiple factors. First, confirm whether the development board can use SPI correctly. You can connect a logic analyzer to observe if there is data exchange and if there are glitches. If there is no data exchange, first verify that the driver and device tree for the selected SPI bus and device are enabled. If there are glitches, you can reduce the SPI rate or the pin slew‑rate.

Another possibility is that the SPI clock source is only twice the set SPI rate; you can set the clock source to four times the set SPI rate.

If SPI communication is fine, confirm whether the script can acquire data. In the main function, change the call to `data_handle`:

```
data_handle(ser, frames)
```

to directly print:

```
print(frames)
```

After modification, observe whether the point cloud data printed during script execution looks normal.

Finally, ensure that the device opening the web URL can ping the development board.

## Open Source Code Declaration

| Open Source Code Directory                         | Author   |
| -------------------------------------------------- | -------- |
| MRS6240_mmWave_radar_spi_collect_data_linux-master | WinWin   |
| gpio                                               | nayooooo |
| PointCloudDisplay                                  | nayooooo |
