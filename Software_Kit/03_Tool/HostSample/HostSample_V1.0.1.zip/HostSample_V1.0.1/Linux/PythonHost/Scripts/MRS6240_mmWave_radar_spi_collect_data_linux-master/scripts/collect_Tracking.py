#!/usr/bin/env python3
"""
Tracking 固件 — SPI 雷达数据采集脚本

功能：在 Linux 上通过 SPI 采集正和微芯 MRS6240 毫米波雷达数据。
固件要求：雷达烧录 Tracking 固件。

用法：
    sudo python collect_Tracking.py [--speed 10000000] [--burst 256] [--timeout 0]
    按 Ctrl+C 停止采集。
"""

import time, sys, os, signal, struct, argparse
from datetime import datetime

from gpiolib import Edge, GPIO, Mode
import spidev

from PointCloudDisplay import Server as PCDServer

# ═══════════════════════════════════════════════════════════════
# HIF 协议常量与工具函数
# ═══════════════════════════════════════════════════════════════
MAGIC = 0xA5  # HIF 帧魔数

def parse_hif_header(raw6):
    """解析 6 字节 HIF 帧头。"""
    flags = raw6[2] & 0xFC
    return {
        'msg_id': raw6[3],                                # 消息 ID
        'length': raw6[4] | ((raw6[5] & 0x0F) << 8),      # payload 长度
        'more'  : (flags >> 5) & 1,                       # 还有更多帧标志
        'check' : (flags >> 4) & 1,                       # 是否有 Check32
        'frag'  : (raw6[5] >> 7) & 1,                     # 是否为消息层分片数据
    }

def hif_check8_ok(raw6):
    """验证 HIF 帧头 Check8 校验。"""
    s = raw6[0] + raw6[2] + raw6[3] + raw6[4] + raw6[5]
    return raw6[1] == ((~s) & 0xFF)

def hif_check32_ok(data, check32):
    total = 0
    if len(data) >= 4:
        for i in range(0, len(data) - 3, 4):
            total = (total + struct.unpack_from("<I", data, i)[0]) & 0xFFFFFFFF
    rem = len(data) % 4
    if rem:
        last = data[-rem:] + b"\x00" * (4 - rem)
        total = (total + struct.unpack("<I", last)[0]) & 0xFFFFFFFF
    calc = (~total) & 0xFFFFFFFF
    ck32 = struct.unpack("<I", check32)[0] & 0xFFFFFFFF
    return calc == ck32

def build_poll(poll_type=1, burst_period=256):
    """
    构造完整 HIF POLL 帧：6 字节头 + 4 字节 payload + 4 字节 Check32。
    """
    # ---- 6 字节帧头 ----
    h = bytearray(6)
    h[0] = MAGIC
    h[1] = 0               # Check8 占位，稍后计算
    h[2] = 0x15            # type=1 (主机→雷达), flags=5 (REQ|Check32)
    h[3] = 0x0C            # msg_id = HOST_READ (轮询命令)
    h[4] = 4               # payload 长度低字节
    h[5] = 0               # payload 长度高字节 + seq
    h[1] = (~(h[0] + h[2] + h[3] + h[4] + h[5])) & 0xFF

    # ---- 4 字节 payload：poll_type + err_num + burst_num (小端) ----
    pl = bytearray([poll_type, 0, burst_period & 0xFF, (burst_period >> 8) & 0xFF])

    # ---- Check32：反码累加 (hdr[2:6] + payload)，再取反 ----
    data = bytes(h[2:6]) + bytes(pl)
    total = 0
    for i in range(0, len(data) - 3, 4):
        total = (total + struct.unpack_from("<I", data, i)[0]) & 0xFFFFFFFF
    rem = len(data) % 4
    if rem:
        last = data[-rem:] + b"\x00" * (4 - rem)
        total = (total + struct.unpack("<I", last)[0]) & 0xFFFFFFFF

    ck = (~total & 0xFFFFFFFF).to_bytes(4, 'little')

    return bytes(h) + bytes(pl) + ck

# ═══════════════════════════════════════════════════════════════
# SPI / GPIO 硬件接口（STM32MP157）
# ═══════════════════════════════════════════════════════════════
GPIO_CHIP, INT_GPIO = 2, 0                      # gpiochip2, GPIO0 (中断引脚)
SPI_BUS, SPI_DEV, SPI_HZ = 0, 0, 10_000_000     # SPI1(devspi0), CS0, 10MHz

running = True
def _stop(sig, frame):
    global running; running = False; print("\n正在停止...")
signal.signal(signal.SIGINT, _stop)
signal.signal(signal.SIGTERM, _stop)

class Radar:
    """MRS6240 雷达 SPI 通信句柄。"""

    def __init__(self, speed=SPI_HZ):
        # GPIO 初始化：中断引脚（PA6 → STM32MP1 PC0）
        self.gh = GPIO(f"/dev/gpiochip{GPIO_CHIP}", INT_GPIO, mode=Mode.INPUT)
        self.gh.open()
        # SPI 初始化：Mode 0, 8bit
        self.spi = spidev.SpiDev()
        self.spi.open(SPI_BUS, SPI_DEV)
        self.spi.mode = 0b00
        self.spi.max_speed_hz = speed
        self.spi.bits_per_word = 8
        self.spi.cshigh = False

    def com_xfer2(self, data):
        return self.spi.xfer2(data)

    def int_level(self):
        return self.gh.read()

    def wait_int_high(self, ms=1000):
        """等待中断引脚拉高（雷达数据就绪），超时返回 False。"""
        deadline = time.monotonic() + ms / 1000.
        while time.monotonic() < deadline:
            if self.int_level():
                return True
            time.sleep(0.001)
        return False

    def wait_int_low(self, ms=1000):
        """等待中断引脚拉低。"""
        deadline = time.monotonic() + ms / 1000.
        while time.monotonic() < deadline:
            if not self.int_level():
                return True
            time.sleep(0.001)
        return False
    
    def error_correction(self):
        count = 0
        while count < 4096:
            recv = self.com_xfer2([0x00] * 1024)
            for i in range(0, 1024):
                if recv[i] in [0x00, 0xFF, 0x80]:
                    count = count + 1
                else:
                    count = 0

    def poll(self, burst=256, burst_delay=0):
        """
        发送 POLL 命令，读取所有 HIF 帧，返回 [{'hdr', 'payload'}, ...]。

        SPI 线格式（含 DMA 填充字节）：
          [magic 1B][check8 1B][msghdr 4B][payload N B][check32 4B]
          ←────────── 6 字节头 ───────────→
        """
        # 第一步：发送 POLL 命令
        self.com_xfer2(list(build_poll(poll_type=1, burst_period=burst)))
        # 第二步：等 INT 跳变（雷达处理命令）
        self.wait_int_low(2)
        self.wait_int_high(10)

        # 第三步：发送 dummy 时钟，读取 MISO 返回的 HIF 数据
        frames = []
        while True:
            # recv header
            chunk = bytes(self.com_xfer2([0x00] * 6))
            if chunk[0] != MAGIC:
                self.error_correction()
                break
            header = chunk[:]
            hdr = parse_hif_header(chunk)
            if not hif_check8_ok(chunk):
                self.error_correction()
                print("check8 error")
                break
            if (hdr['length'] < 0) or (hdr['length'] > 4095):
                self.error_correction()
                print("length error")
                break
            # recv payload
            left = hdr['length'] + 4 if hdr['check'] else 0
            if left > 0:
                chunk = bytes(self.com_xfer2([0x00] * left))
                payload = chunk[:-4] if hdr['check'] else chunk[:]
                if hdr['check']:
                    if not hif_check32_ok(header[2:] + payload[:], chunk[-4:]):
                        print("check32 error")
                        break
                # handle data
                frames.append({'hdr': hdr, 'payload': payload})
                self.err_cnt = 0
            if hdr['more'] == 0:
                break
            elif burst_delay > 0:
                time.sleep(burst_delay)
        return frames

    def close(self):
        self.spi.close()
        self.gh.close()


# ═══════════════════════════════════════════════════════════════
# 主循环
# ═══════════════════════════════════════════════════════════════

def data_handle(service, frames):
    for f in frames:
        hdr = f['hdr']
        payload = f['payload']
        if hdr['msg_id'] != 0xC3:    # 只处理 0xC3
            continue
        if hdr['frag']:              # 不处理消息层分片数据
            continue
        points_ori = payload[16:]
        points = []
        for idx in range(struct.unpack('<H', payload[14:16])[0] // 12):
            a_point = payload[(12 * idx + 16):(12 * (idx + 1) + 16)]
            if len(a_point) >= 12:
                points.append({
                    "range_or_x": struct.unpack('<H', a_point[0:2])[0] / 100,
                    "azimath_or_y": struct.unpack('<H', a_point[2:4])[0] / 100,
                    "elevation_or_z": struct.unpack('<H', a_point[4:6])[0] / 100,
                    "velocity": struct.unpack('<H', a_point[6:8])[0] / 100,
                    "snr": struct.unpack('<H', a_point[8:10])[0] / 100,
                })
        if len(points) > 0:
            service.push({
                "Type": payload[12],
                "Flag": payload[13],
                "TotalLength": struct.unpack('<H', payload[14:16])[0],
                "Point": points,
            })

def main():
    ap = argparse.ArgumentParser(description='MRS6240 Tracking SPI 数据采集')
    ap.add_argument('--speed', type=int, default=SPI_HZ,
                    help=f'SPI 时钟频率 Hz (默认 {SPI_HZ})')
    ap.add_argument('--burst', type=int, default=256,
                    help='POLL burst_period 参数')
    ap.add_argument('--timeout', type=int, default=0,
                    help='N 秒后自动停止 (0=无限)')
    ap.add_argument('--poll_delay', type=float, default=0,
                    help='N 秒延迟后再发送POLL指令')
    ap.add_argument('--burst_delay', type=float, default=0,
                    help='相邻 2 个 burst 之间的主动延迟时间，测试用')
    args = ap.parse_args()

    print(f"  {args.speed/1e6:.1f} MHz  burst={args.burst}  按 Ctrl+C 停止\n")

    radar = Radar(speed=args.speed)
    ser = PCDServer('cartesian', '192.168.137.100', 5000)
    ser.start()

    rounds = 0
    burst_delay = args.burst_delay if args.burst_delay > 0 else 0
    deadline = time.monotonic() + args.timeout if args.timeout > 0 else float('inf')

    try:
        while running and time.monotonic() < deadline:
            rounds += 1

            # 等待 INT 拉高（雷达有数据就绪）
            if not radar.wait_int_high(ms=5000 if rounds == 1 else 2000):
                print(f"[第{rounds}轮] INT 超时，等待中...")
                continue
            if args.poll_delay > 0:
                time.sleep(args.poll_delay)

            # 发送 POLL，读取数据帧
            frames = radar.poll(burst=args.burst, burst_delay=burst_delay)

            data_handle(ser, frames)

    finally:
        radar.close()

    print(f"\n完成。{rounds} 轮")


if __name__ == '__main__':
    main()
